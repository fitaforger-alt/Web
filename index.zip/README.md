# DriveVest

Investment-style rewards platform: a mobile-first customer app and a desktop
administrator console, both served by **one** Node API over **one** SQLite
database. Every peso on screen is read from the financial ledger — there is no
demo mode, no seeded balances, and no localStorage source of truth.

```
drivevest/
├─ src/                 React + TypeScript customer app and admin console (Vite)
└─ server/              Express API, SQLite schema, migrations, tests
```

---

## 1. Requirements

| Tool | Version |
|------|---------|
| Node.js | 20 or newer (tested on 24.20) |
| npm | 10 or newer |

SQLite is embedded through `better-sqlite3`, so there is nothing else to install
or run. PostgreSQL would work the same way if you want it: the schema lives in
one place (`server/db.js`) and every query is parameterised.

---

## 2. Install

```bash
# API
cd server
npm install

# Web app
cd ..
npm install
```

## 3. Configure

```bash
cp server/.env.example server/.env
cp .env.example .env.local      # optional, only needed for cross-origin setups
```

`server/.env` needs no secrets to run locally. Payment providers stay disabled
until you supply real credentials, which is deliberate — see §9.

## 4. Database

Migrations run automatically on first start and are recorded in
`schema_migrations`. To inspect or back up:

```bash
cd server
npm run migrate:status          # applied migrations and row counts
npm run backup                  # consistent online snapshot into server/backups/
```

**Upgrading an existing database.** The migration `000_legacy_upgrade` converts
the original peso-integer tables in place: balances and prices are converted to
integer centavos, synthetic email columns are dropped, and every account, wallet
balance, welcome reward, ledger row, plan and administrator is carried across
with its original IDs, references and timestamps. A table rebuild is used because
SQLite cannot alter column types, so the migration only runs when it detects the
old shape and is a no-op on an already-migrated database.

## 5. Provision the first administrator

There is no public administrator registration.

```bash
cd server
npm run setup:admin -- --username olivia --password 'choose-a-strong-one' --name 'Olivia'
# omit --password to have one generated and printed once
```

Sign in at `/admin/login`. Rotate the password from **Administrators** after the
first sign-in.

## 6. Run

```bash
# terminal 1 — API on :4000
cd server && npm start

# terminal 2 — web app on :5173 (proxies /api to :4000)
npm run dev
```

Customer app: <http://localhost:5173/> · Admin console: <http://localhost:5173/admin>

Production, single origin:

```bash
npm run build          # emits dist/
cd server && npm start # serves dist/ and /api from :4000
```

## 7. Tests

```bash
cd server
npm test
```

The suite runs against a real temporary SQLite database and a real listening HTTP
server. Cookies, CSRF headers and idempotency keys are carried exactly as a
browser sends them, so session handling, permission checks and financial
invariants are genuinely exercised. 40 tests cover registration, the one-time
₱50 welcome reward, referral linking, ledger immutability, plan versioning,
provider webhook verification, withdrawal holds, two-person approval, role
enforcement, empty states and audit redaction.

---

## 8. How the money works

**One ledger.** `server/lib/ledger.js` is the only code that changes a balance.
Every movement is one SQLite transaction that reads the wallet with a
compare-and-set guard, writes an immutable `ledger_entries` row carrying the
balance before and after, and updates the wallet. Amounts are integer centavos
throughout — no floating point touches money anywhere in the codebase.

**Balances cannot go negative.** `wallets` carries `CHECK (… >= 0)` constraints, so
an overdraw is a database error rather than a silent corruption.

**History is permanent.** Triggers reject `UPDATE` and `DELETE` on
`ledger_entries` and `audit_logs`. A correction is a linked reversing entry, never
an edit.

**Withdrawal holds.** Requesting a withdrawal raises `reserved_centavos` in the
same transaction that creates the request, so the money cannot back a second
withdrawal or a plan purchase. The hold clears when the payout is confirmed
(money leaves `earnings`) or released (money returns to spendable).

**One-time welcome reward.** Account creation, wallet creation and the ₱50 credit
are a single transaction, and `welcome_rewards.user_id` is a primary key. The
reward is structurally once-only; re-registering, refreshing or signing in again
cannot produce a second one. The congratulations modal only appears after the
server returns the committed ledger reference.

**Idempotency.** Financial endpoints accept `X-Idempotency-Key`. The customer app
mints one key per user intent, so a double tap or a retried request is recognised
by the server instead of booked twice.

### Daily plan income

A plan's stated daily income is a real credit, not an estimate. Every completed
24-hour period of a plan's term posts one ledger entry to the customer's
**earnings** wallet, so it counts toward what they can withdraw.

- The clock starts at the exact instant of purchase (`user_plans.activated_at`),
  not at midnight, so "24 hours after buying" means exactly that.
- One credit per day, dated to the end of the window it pays for — a catch-up
  sweep does not stamp every settled day with the sweep date.
- Each day is claimed by a `plan_settlements` row under
  `UNIQUE (user_plan_id, day_number)`. A repeated sweep, a restarted process or
  two workers racing all hit that constraint and skip the day. Exactly one
  payment, ever.
- `days_completed` is the authoritative counter and only advances inside the same
  transaction as the credit, so the customer's "next credit" time is exact.
- A plan marks itself `completed` once its full term has settled, and never
  accrues past it.

The sweep runs on `MAINTENANCE_INTERVAL_MINUTES` (default 5) and again on the
customer's own dashboard and plan reads, so income appears promptly without
depending on the timer. Neither path can pay twice.

Admins can force a sweep from **Administrators → Run settlement**, and read every
credit from **Plan settlements**. Both require `plans.manage`.

### Check-in

Check-in credits the withdrawable **earnings** wallet, configured as a peso
amount in `checkin_reward_centavos`. It is no longer points. Tasks, the rewards
wheel and redemption codes still pay points — that is a separate promotional
balance, deliberately kept separate from real money.

---

## 9. Payments

Two independent paths credit a deposit, and nothing else does:

1. **Provider webhook** — `POST /api/payments/webhook`, HMAC-signed with the
   provider secret. Provider event ids are unique, so a replayed callback cannot
   credit twice.
2. **Reconciliation** — the admin console's *Verify with provider* button calls
   the provider API for the deposit reference and credits only when the provider
   reports the payment settled with a matching amount.

There is deliberately **no approve button**. Screenshots never prove a payment.

Until `GCASH_CLIENT_KEY` / `GCASH_SECRET_KEY` (or the Maya equivalents) are set,
`/api/deposits/methods` reports the provider as disabled, the recharge screen
says so in plain language, and `POST /api/deposits` refuses to create a request.
No simulated payment can be presented as a real one.

Withdrawal completion is the mirror image: approval only moves a request to
`processing`. It reaches `completed` when an operator records a payout reference
and a confirmation note, and that payout is what debits the wallet.

---

## 10. Roles

| Role | Can |
|------|-----|
| `SUPER_ADMIN` | Everything, including administrator accounts |
| `FINANCE_ADMIN` | Ledger, adjustments, deposit and withdrawal review, reports |
| `SUPPORT_ADMIN` | Users, tickets, notifications — no balance or payout powers |
| `PLAN_MANAGER` | Product definitions and plan assignment |
| `AUDITOR` | Read-only across financial records and audit history |

Permissions are checked on the server for every admin endpoint. Hiding a button
is presentation; `server/lib/auth.js` is the gate.

---

## 11. Data integrity

- **Unique constraints** on usernames, referral codes, ledger references, provider
  event ids and the welcome-reward record.
- **Foreign keys** across users, wallets, ledger, deposits, withdrawals, plans,
  referrals and support.
- **Check constraints** preventing negative balances and over-reservation.
- **Append-only triggers** on the ledger and the audit trail.
- **Redaction** before anything reaches the audit log: any key matching
  password/token/secret/hash/otp/csrf/authorization is replaced with
  `[redacted]`, at any nesting depth.
- **Customer sign-in throttle**, counting failed attempts only, keyed on
  username+IP so one attacker cannot lock a real user out. Tunable with
  `LOGIN_MAX_FAILURES` / `LOGIN_IP_MAX_FAILURES` / `LOGIN_FAIL_WINDOW_MINUTES`.
- **Administrator sign-in throttle is off by default.** Set
  `ADMIN_LOGIN_MAX_FAILURES` to a positive number to enable it. With it off,
  `/admin/login` never answers "too many attempts" — a mistyped password always
  returns a plain rejection and never a timed lockout with no recovery path.
  When enabled it still counts failures only, never successes.

---

## 12. Operations

```bash
npm run backup                                  # consistent snapshot
npm run migrate:status                          # schema + row counts
npm run cleanup:test-accounts -- --prefix e2e_  # dry run, prints what it would remove
npm run cleanup:test-accounts -- --prefix e2e_ --confirm
```

The cleanup script backs up first, prints exactly which accounts and rows are
affected, and refuses to run without `--confirm`. It exists so automated test
accounts can be removed without touching genuine users or accounting history.

---

## 13. What is not included

- **Real payment processing.** GCash/Maya need live API credentials and a
  settlement account before deposits or payouts move real money. Until then the
  platform says so rather than pretending.
- **Regulatory, licensing or guarantee claims.** DriveVest does not represent
  any registration, licence or guaranteed return. Projected plan rewards are
  labelled estimates everywhere they appear, and the terms a customer accepted
  are stored with their plan and never rewritten.