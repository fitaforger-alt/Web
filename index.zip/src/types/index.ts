export type WalletName = 'recharge' | 'earnings' | 'points'

export interface Wallet {
  recharge_centavos: number
  earnings_centavos: number
  reserved_centavos: number
  available_centavos: number
  /** Legacy promotional balance. Not awarded anywhere any more; retained only
   *  so historical ledger rows still resolve. Never displayed. */
  points: number
  updated_at: string
}

export interface SessionUser {
  id: string
  username: string
  membership?: string
  status?: string
  referral_code: string
  created_at?: string
  last_login?: string | null
  referred_by?: string | null
}

export interface WelcomeReward {
  granted: boolean
  amount_centavos: number
  currency?: string
  wallet?: WalletName
  withdrawable?: boolean
  note?: string
  transaction_reference?: string
  issued_at?: string
  status?: string
}

export type LedgerDirection = 'credit' | 'debit'
export type LedgerStatus = 'completed' | 'pending' | 'reversed' | 'failed'

export interface LedgerEntry {
  id: string
  reference: string
  user_id: string
  kind: string
  wallet: WalletName
  direction: LedgerDirection
  amount_centavos: number
  balance_before_centavos: number | null
  balance_after_centavos: number | null
  status: LedgerStatus
  reason: string | null
  note: string | null
  reversal_of: string | null
  correlation_id: string | null
  actor_type: string
  actor_name: string | null
  created_at: string
  username?: string
}

export interface Product {
  id: string
  name: string
  category: 'daily' | 'vip'
  description: string | null
  terms: string | null
  eligibility: string | null
  image_url: string | null
  price_centavos: number
  duration_days: number
  projected_daily_centavos: number
  slots_total: number
  slots_taken: number
  slots_remaining: number | null
  active: number | boolean
  archived: number | boolean
  current_version: number
}

export type UserPlanStatus = 'active' | 'paused' | 'completed' | 'cancelled' | 'expired'

export interface UserPlan {
  id: string
  user_id?: string
  plan_id: string | null
  plan_name: string
  plan_version: number
  terms_snapshot: string
  amount_centavos: number
  projected_daily_centavos: number
  status: UserPlanStatus
  source: 'purchase' | 'admin'
  start_date: string
  end_date: string
  days_completed: number
  progress_percent: number
  created_at: string
  username?: string
}

export type DepositStatus = 'pending' | 'under_review' | 'approved' | 'rejected' | 'failed'
export type WithdrawalStatus = 'pending' | 'under_review' | 'processing' | 'completed' | 'rejected' | 'failed'

export interface Deposit {
  id: string
  reference: string
  user_id: string
  username?: string
  amount_centavos: number
  currency: string
  method: string
  provider_reference: string | null
  verification_state: 'unverified' | 'provider_webhook' | 'provider_api' | 'manual_reconciliation'
  verification_detail: string | null
  status: DepositStatus
  submitted_at: string
  reviewed_at: string | null
  reviewer_name: string | null
  review_reason: string | null
}

export interface Withdrawal {
  id: string
  reference: string
  user_id: string
  username?: string
  destination_masked: string
  amount_centavos: number
  fee_centavos: number
  net_centavos: number
  status: WithdrawalStatus
  requires_second_approval: number
  payout_reference: string | null
  payout_proof: string | null
  paid_at: string | null
  created_at: string
  reviews?: WithdrawalReview[]
}

export interface WithdrawalReview {
  id: string
  admin_name: string
  action: string
  reason: string
  created_at: string
}

export interface PayoutDestination {
  id: string
  holder_name: string
  provider: 'GCash' | 'Maya' | 'Bank'
  masked: string
  verified: number
  created_at: string
}

export interface Task {
  id: string
  title: string
  description: string | null
  reward_points: number
  action_url: string | null
  recurring: 'daily' | 'once'
  active: number
  claim_key: string
  claimed: boolean
  claimable: boolean
}

export interface Notification {
  id: string
  title: string
  body: string
  severity: string
  action_url: string | null
  read_at: string | null
  created_at: string
}

export interface NewsArticle {
  id: string
  title: string
  summary: string
  category: string
  image_url: string | null
  published_at: string
  pinned: number
  is_new?: boolean
}

export interface ReferralRow {
  id: string
  username?: string
  level: number
  reward_centavos: number
  status: string
  created_at: string
  code_used?: string
  referrer_username?: string
  referred_username?: string
}

export interface PublicSettings {
  platform_name: string
  platform_tagline: string
  maintenance_mode: boolean
  maintenance_message: string
  registration_open: boolean
  min_deposit_centavos: number
  min_withdrawal_centavos: number
  welcome_reward_centavos: number
  welcome_reward_withdrawable: boolean
  welcome_reward_note: string
  support_email: string
  support_hours: string
  currency: string
  terms_version: string
  notice: string
}

export interface PaymentMethod {
  id: string
  label: string
  enabled: boolean
  mode: 'live' | 'sandbox' | 'disabled'
  instructions: string
  reason: string | null
}

export interface AdminUser {
  id: string
  username: string
  display_name: string
  role: 'SUPER_ADMIN' | 'FINANCE_ADMIN' | 'SUPPORT_ADMIN' | 'PLAN_MANAGER' | 'AUDITOR'
  permissions: string[]
  status?: string
  created_at?: string
  last_login?: string | null
}

export interface AdminCustomer {
  id: string
  username: string
  status: string
  membership: string
  referral_code: string
  created_at: string
  last_login: string | null
  recharge_centavos: number
  earnings_centavos: number
  reserved_centavos: number
  points: number
  active_plans: number
  referrals: number
}

export interface AdminOverview {
  cards: {
    users: number
    active_users: number
    suspended_users: number
    pending_deposits: number
    pending_withdrawals: number
    active_plans: number
    total_deposits_centavos: number
    total_withdrawals_centavos: number
    welcome_rewards_issued: number
    welcome_rewards_value_centavos: number
    wallet_liabilities_centavos: number
    wallet_recharge_centavos: number
    wallet_earnings_centavos: number
    wallet_reserved_centavos: number
    failed_transactions: number
  }
  daily: { day: string; credits: number; debits: number; entries: number }[]
  recent_audit: AuditRow[]
  payment_providers: PaymentMethod[]
}

export interface AuditRow {
  id: string
  actor_type: string
  actor_id: string | null
  actor_name: string | null
  action: string
  target_type: string | null
  target_id: string | null
  reason: string | null
  before_json: unknown
  after_json: unknown
  transaction_reference: string | null
  correlation_id: string | null
  ip: string | null
  created_at: string
}

export interface AdminNote {
  id: string
  body: string
  author_name: string
  created_at: string
}

export interface ApprovalRequest {
  id: string
  kind: string
  subject_type: string
  subject_id: string
  requested_by_name: string
  requested_at: string
  decided_by_name: string | null
  decision: string | null
  decided_at: string | null
  note: string | null
  status: string
  payload: {
    userId: string
    wallet: WalletName
    direction: 'Credit' | 'Debit'
    amount_centavos: number
    reason: string
    note: string
  }
}

export interface RedemptionCode {
  code: string
  label: string | null
  wallet: WalletName
  value: number
  max_redemptions: number
  per_user_limit: number
  starts_at: string | null
  expires_at: string | null
  active: number
  redeemed: number
}

export interface SupportTicket {
  id: string
  reference: string
  user_id: string
  username?: string
  category: string
  subject: string
  status: string
  priority: string
  created_at: string
  updated_at: string
  message_count?: number
}

export interface SupportMessage {
  id: string
  author_type: string
  body: string
  created_at: string
}