export class ApiError extends Error {
  status: number
  code: string
  correlationId?: string
  constructor(status: number, code: string, message: string, correlationId?: string) {
    super(message)
    this.status = status
    this.code = code
    this.correlationId = correlationId
  }
}

/**
 * The API origin. In development the Vite dev server proxies /api to the
 * backend, so the app and API share an origin and the session cookie is
 * first-party. Set VITE_API_ORIGIN to point at a separately hosted API.
 */
export const API_ORIGIN: string = import.meta.env.VITE_API_ORIGIN || ''

let csrfToken: string | null = null

export const setCsrfToken = (token: string | null) => { csrfToken = token }
export const getCsrfToken = () => csrfToken

type RequestOptions = {
  method?: 'GET' | 'POST' | 'PATCH' | 'DELETE'
  body?: unknown
  idempotencyKey?: string
  signal?: AbortSignal
}

async function parseBody(res: Response) {
  const text = await res.text()
  if (!text) return null
  try {
    return JSON.parse(text)
  } catch {
    return { raw: text }
  }
}

export async function api<T = any>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, idempotencyKey, signal } = options
  const headers: Record<string, string> = { Accept: 'application/json' }
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (csrfToken) headers['X-CSRF-Token'] = csrfToken
  if (idempotencyKey) headers['X-Idempotency-Key'] = idempotencyKey

  let res: Response
  try {
    res = await fetch(`${API_ORIGIN}${path}`, {
      method,
      headers,
      credentials: 'include',
      body: body === undefined ? undefined : JSON.stringify(body),
      signal,
    })
  } catch {
    throw new ApiError(0, 'network_error', 'Could not reach the server. Check your connection and try again.')
  }

  const payload = await parseBody(res)
  if (!res.ok) {
    const error = payload?.error
    throw new ApiError(
      res.status,
      error?.code || 'request_failed',
      error?.message || 'That request could not be completed.',
      error?.correlation_id,
    )
  }
  return payload as T
}

/** A fresh idempotency key per user intent, so a double submit cannot duplicate work. */
export const newIdempotencyKey = () =>
  (globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`)