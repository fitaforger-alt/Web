/** Formatting helpers. Amounts arrive from the API as integer centavos. */

export const money = (centavos: number | null | undefined) =>
  `₱${((centavos ?? 0) / 100).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`

/** Accepts a peso string from a form field and converts it to centavos. */
export const toCentavos = (value: string) => {
  const raw = value.replace(/[,\s₱]/g, '')
  if (!/^\d*(\.\d{0,2})?$/.test(raw) || raw === '' || raw === '.') return NaN
  return Math.round(Number(raw) * 100)
}

export const dateStr = (value: string | Date) =>
  new Date(value).toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' })

export const dateTimeStr = (value: string | Date) =>
  new Date(value).toLocaleString('en-PH', {
    year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
  })

export const relativeDay = (value: string | Date) => {
  const then = new Date(value).getTime()
  const diff = Date.now() - then
  const minutes = Math.round(diff / 60000)
  if (minutes < 1) return 'just now'
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.round(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.round(hours / 24)
  if (days < 30) return `${days}d ago`
  return dateStr(value)
}

export const initials = (name: string) => (name || '?').trim().slice(0, 2).toUpperCase()