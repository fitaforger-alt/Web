import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { ApiError, api, newIdempotencyKey, setCsrfToken } from '../lib/api'
import type {
  LedgerEntry, NewsArticle, Notification, PayoutDestination, Product,
  PublicSettings, ReferralRow, SessionUser, Task, UserPlan, Wallet, WelcomeReward,
} from '../types'

interface DashboardStats {
  transactions: number
  active_plans: number
  referrals: number
  checkin_streak: number
  checked_in_today: boolean
}

interface Toast { id: string; msg: string; type: 'success' | 'error' | 'info' }
interface ConfirmState {
  open: boolean
  title: string
  message: string
  confirmLabel: string
  tone: 'default' | 'danger'
  onConfirm?: () => void | Promise<void>
}

type ConfirmOptions = Partial<Pick<ConfirmState, 'title' | 'message' | 'confirmLabel' | 'tone' | 'onConfirm'>>

interface AppState {
  ready: boolean
  authenticated: boolean
  user: SessionUser | null
  wallet: Wallet | null
  welcomeReward: WelcomeReward | null
  transactions: LedgerEntry[]
  transactionTotal: number
  plans: UserPlan[]
  products: Product[]
  destinations: PayoutDestination[]
  tasks: Task[]
  notifications: Notification[]
  unread: number
  news: NewsArticle[]
  referrals: { code: string; link: string; total: number; bonus_earned_centavos: number; terms: string; rows: ReferralRow[] } | null
  settings: PublicSettings | null
  stats: DashboardStats | null
  loading: boolean
  refreshing: boolean
  error: string | null
}

interface AppActions {
  login: (username: string, password: string) => Promise<void>
  register: (username: string, password: string, referralCode?: string) => Promise<void>
  logout: () => Promise<void>
  refresh: (options?: { silent?: boolean }) => Promise<void>
  loadProducts: () => Promise<void>
  loadNews: () => Promise<void>
  loadTasks: () => Promise<void>
  loadNotifications: () => Promise<void>
  loadReferrals: () => Promise<void>
  loadSettings: () => Promise<void>
  purchasePlan: (planId: string) => Promise<UserPlan>
  saveDestination: (input: { holderName: string; provider: string; accountNumber: string }) => Promise<void>
  removeDestination: (id: string) => Promise<void>
  requestDeposit: (amountCentavos: number, method: string, providerReference: string) => Promise<void>
  requestWithdrawal: (amountCentavos: number, destinationId: string) => Promise<void>
  checkIn: () => Promise<{ streak: number; reward_centavos: number; wallet: string }>
  claimTask: (taskId: string) => Promise<number>
  spinWheel: () => Promise<{ outcome: string; amountCentavos: number }>
  redeemCode: (code: string) => Promise<string>
  markNotificationRead: (id: string) => Promise<void>
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>
  consumeWelcomeReward: () => void
  toast: (msg: string, type?: Toast['type']) => void
  toasts: Toast[]
  dismissToast: (id: string) => void
  confirm: ConfirmState
  openConfirm: (options: ConfirmOptions) => void
  closeConfirm: () => void
}

const AppContext = createContext<(AppState & AppActions) | null>(null)

const emptyConfirm: ConfirmState = { open: false, title: '', message: '', confirmLabel: 'Confirm', tone: 'default' }

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false)
  const [authenticated, setAuthenticated] = useState(false)
  const [user, setUser] = useState<SessionUser | null>(null)
  const [wallet, setWallet] = useState<Wallet | null>(null)
  const [welcomeReward, setWelcomeReward] = useState<WelcomeReward | null>(null)
  const [transactions, setTransactions] = useState<LedgerEntry[]>([])
  const [transactionTotal, setTransactionTotal] = useState(0)
  const [plans, setPlans] = useState<UserPlan[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [destinations, setDestinations] = useState<PayoutDestination[]>([])
  const [tasks, setTasks] = useState<Task[]>([])
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unread, setUnread] = useState(0)
  const [news, setNews] = useState<NewsArticle[]>([])
  const [referrals, setReferrals] = useState<AppState['referrals']>(null)
  const [settings, setSettings] = useState<PublicSettings | null>(null)
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [loading, setLoading] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [toasts, setToasts] = useState<Toast[]>([])
  const [confirm, setConfirm] = useState<ConfirmState>(emptyConfirm)
  const pendingIntents = useRef<Map<string, string>>(new Map())

  const toast = useCallback((msg: string, type: Toast['type'] = 'info') => {
    const id = newIdempotencyKey()
    setToasts((prev) => [...prev, { id, msg, type }])
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4000)
  }, [])

  const dismissToast = useCallback((id: string) => setToasts((prev) => prev.filter((t) => t.id !== id)), [])

  const openConfirm = useCallback((options: ConfirmOptions) => {
    setConfirm({
      title: options.title ?? 'Please confirm',
      message: options.message ?? '',
      confirmLabel: options.confirmLabel ?? 'Confirm',
      tone: options.tone ?? 'default',
      onConfirm: options.onConfirm,
      open: true,
    })
  }, [])
  const closeConfirm = useCallback(() => setConfirm(emptyConfirm), [])

  /**
   * One idempotency key per user intent. A double tap reuses the same key, so the
   * server recognises the retry instead of booking the movement twice.
   */
  const intentKey = useCallback((intent: string) => {
    if (!pendingIntents.current.has(intent)) pendingIntents.current.set(intent, newIdempotencyKey())
    return pendingIntents.current.get(intent)!
  }, [])

  const clearIntent = useCallback((intent: string) => { pendingIntents.current.delete(intent) }, [])

  const clearSession = useCallback(() => {
    setCsrfToken(null)
    setAuthenticated(false)
    setUser(null)
    setWallet(null)
    setWelcomeReward(null)
    setTransactions([])
    setTransactionTotal(0)
    setPlans([])
    setDestinations([])
    setTasks([])
    setNotifications([])
    setUnread(0)
    setReferrals(null)
    setStats(null)
  }, [])

  const refresh = useCallback(async (options?: { silent?: boolean }) => {
    if (options?.silent) setRefreshing(true)
    else setLoading(true)
    try {
      const [me, walletRes, txRes, planRes, destRes, dashboard, notificationRes] = await Promise.all([
        api<{ user: SessionUser; wallet: Wallet; welcomeReward: WelcomeReward; unread: number }>('/api/me'),
        api<Wallet>('/api/wallet'),
        api<{ total: number; rows: LedgerEntry[] }>('/api/transactions?limit=100'),
        api<UserPlan[]>('/api/user-plans'),
        api<PayoutDestination[]>('/api/payout-destinations'),
        api<{ wallet: Wallet; stats: DashboardStats; unread: number }>('/api/dashboard'),
        api<{ unread: number; rows: Notification[] }>('/api/notifications'),
      ])
      setAuthenticated(true)
      setUser(me.user)
      setWallet(walletRes)
      setTransactions(txRes.rows)
      setTransactionTotal(txRes.total)
      setPlans(planRes)
      setDestinations(destRes)
      setStats(dashboard.stats)
      setUnread(notificationRes.unread ?? me.unread)
      setNotifications(notificationRes.rows)
      setError(null)
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        clearSession()
      } else {
        setError(err instanceof Error ? err.message : 'Could not load your account.')
      }
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [clearSession])

  const loadProducts = useCallback(async () => {
    try {
      setProducts(await api<Product[]>('/api/plans'))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load products.')
    }
  }, [])

  const loadNews = useCallback(async () => {
    try {
      setNews(await api<NewsArticle[]>('/api/news'))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load news.')
    }
  }, [])

  const loadTasks = useCallback(async () => {
    try {
      setTasks(await api<Task[]>('/api/tasks'))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load tasks.')
    }
  }, [])

  const loadNotifications = useCallback(async () => {
    try {
      const res = await api<{ unread: number; rows: Notification[] }>('/api/notifications')
      setUnread(res.unread)
      setNotifications(res.rows)
    } catch {
      setError('Could not load notifications.')
    }
  }, [])

  const loadReferrals = useCallback(async () => {
    try {
      setReferrals(await api('/api/referrals'))
    } catch {
      setError('Could not load referral details.')
    }
  }, [])

  const loadSettings = useCallback(async () => {
    try {
      setSettings(await api<PublicSettings>('/api/settings/public'))
    } catch {
      setError('Could not load platform settings.')
    }
  }, [])

  const register = useCallback(async (username: string, password: string, referralCode?: string) => {
    const res = await api<{ user: SessionUser; wallet: Wallet; welcomeReward: WelcomeReward; csrfToken: string }>(
      '/api/auth/register',
      { method: 'POST', body: { username, password, referralCode: referralCode?.trim() || undefined } },
    )
    setCsrfToken(res.csrfToken)
    setAuthenticated(true)
    setUser(res.user)
    setWallet(res.wallet)
    // The popup appears only after the server confirmed the ledger entry.
    setWelcomeReward(res.welcomeReward.granted ? res.welcomeReward : null)
    await refresh({ silent: true })
  }, [refresh])

  const login = useCallback(async (username: string, password: string) => {
    const res = await api<{ user: SessionUser; csrfToken: string; welcomeRewardIssued: boolean }>(
      '/api/auth/login',
      { method: 'POST', body: { username, password } },
    )
    setCsrfToken(res.csrfToken)
    setAuthenticated(true)
    setUser(res.user)
    // A login must never re-trigger the welcome reward popup.
    setWelcomeReward(null)
    await refresh({ silent: true })
  }, [refresh])

  const logout = useCallback(async () => {
    try {
      await api('/api/auth/logout', { method: 'POST', body: {} })
    } finally {
      clearSession()
    }
  }, [clearSession])

  const purchasePlan = useCallback(async (planId: string) => {
    const intent = `plan:${planId}`
    const res = await api<{ userPlan: UserPlan }>('/api/user-plans/purchase', {
      method: 'POST',
      body: { planId },
      idempotencyKey: intentKey(intent),
    })
    clearIntent(intent)
    await refresh({ silent: true })
    return res.userPlan
  }, [clearIntent, intentKey, refresh])

  const saveDestination = useCallback(async (input: { holderName: string; provider: string; accountNumber: string }) => {
    await api('/api/payout-destinations', { method: 'POST', body: input })
    setDestinations(await api<PayoutDestination[]>('/api/payout-destinations'))
  }, [])

  const removeDestination = useCallback(async (id: string) => {
    await api(`/api/payout-destinations/${id}`, { method: 'DELETE' })
    setDestinations(await api<PayoutDestination[]>('/api/payout-destinations'))
  }, [])

  const requestDeposit = useCallback(async (amountCentavos: number, method: string, providerReference: string) => {
    const intent = `deposit:${amountCentavos}:${method}`
    await api('/api/deposits', {
      method: 'POST',
      body: { amount: (amountCentavos / 100).toFixed(2), method, providerReference },
      idempotencyKey: intentKey(intent),
    })
    clearIntent(intent)
    await refresh({ silent: true })
  }, [clearIntent, intentKey, refresh])

  const requestWithdrawal = useCallback(async (amountCentavos: number, destinationId: string) => {
    const intent = `withdrawal:${amountCentavos}:${destinationId}`
    await api('/api/withdrawals', {
      method: 'POST',
      body: { amount: (amountCentavos / 100).toFixed(2), destinationId },
      idempotencyKey: intentKey(intent),
    })
    clearIntent(intent)
    await refresh({ silent: true })
  }, [clearIntent, intentKey, refresh])

  const checkIn = useCallback(async () => {
    const res = await api<{ streak: number; reward_centavos: number; wallet: string }>('/api/checkin', { method: 'POST', body: {} })
    await refresh({ silent: true })
    return res
  }, [refresh])

  const claimTask = useCallback(async (taskId: string) => {
    const res = await api<{ task: Task }>(`/api/tasks/${taskId}/claim`, { method: 'POST', body: {} })
    await Promise.all([loadTasks(), refresh({ silent: true })])
    return res.task.reward_points
  }, [loadTasks, refresh])

  const spinWheel = useCallback(async () => {
    const res = await api<{ outcome: { label: string; amountCentavos: number } }>('/api/wheel/spin', { method: 'POST', body: {} })
    await refresh({ silent: true })
    return { outcome: res.outcome.label, amountCentavos: res.outcome.amountCentavos }
  }, [refresh])

  const redeemCode = useCallback(async (code: string) => {
    const res = await api<{ code: string }>('/api/redemptions', { method: 'POST', body: { code } })
    await refresh({ silent: true })
    return res.code
  }, [refresh])

  const markNotificationRead = useCallback(async (id: string) => {
    const res = await api<{ unread: number }>(`/api/notifications/${id}/read`, { method: 'POST', body: {} })
    setUnread(res.unread)
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read_at: new Date().toISOString() } : n)))
  }, [])

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    await api('/api/auth/password', { method: 'POST', body: { currentPassword, newPassword } })
  }, [])

  const consumeWelcomeReward = useCallback(() => setWelcomeReward(null), [])

  // Boot: restore a cookie session if one exists, otherwise show the signed-out site.
  useEffect(() => {
    let cancelled = false
    const boot = async () => {
      try {
        const session = await api<{ user: SessionUser; csrfToken: string }>('/api/auth/session')
        if (cancelled) return
        setCsrfToken(session.csrfToken)
        setAuthenticated(true)
        setUser(session.user)
      } catch {
        if (!cancelled) setAuthenticated(false)
      } finally {
        if (!cancelled) setReady(true)
      }
    }
    void boot()
    return () => { cancelled = true }
  }, [])

  useEffect(() => {
    if (!ready) return
    void refresh({ silent: true })
    void loadSettings()
    void loadProducts()
    void loadNews()
  }, [ready, refresh, loadSettings, loadProducts, loadNews])

  useEffect(() => {
    if (authenticated) void loadTasks()
  }, [authenticated, loadTasks])

  const value = useMemo<AppState & AppActions>(() => ({
    ready, authenticated, user, wallet, welcomeReward, transactions, transactionTotal,
    plans, products, destinations, tasks, notifications, unread, news, referrals, settings,
    stats, loading, refreshing, error,
    login, register, logout, refresh, loadProducts, loadNews, loadTasks, loadNotifications,
    loadReferrals, loadSettings, purchasePlan, saveDestination, removeDestination,
    requestDeposit, requestWithdrawal, checkIn, claimTask, spinWheel, redeemCode,
    markNotificationRead, changePassword, consumeWelcomeReward,
    toast, toasts, dismissToast, confirm, openConfirm, closeConfirm,
  }), [
    ready, authenticated, user, wallet, welcomeReward, transactions, transactionTotal, plans,
    products, destinations, tasks, notifications, unread, news, referrals, settings, stats,
    loading, refreshing, error, login, register, logout, refresh, loadProducts, loadNews,
    loadTasks, loadNotifications, loadReferrals, loadSettings, purchasePlan, saveDestination,
    removeDestination, requestDeposit, requestWithdrawal, checkIn, claimTask, spinWheel,
    redeemCode, markNotificationRead, changePassword, consumeWelcomeReward, toast, toasts,
    dismissToast, confirm, openConfirm, closeConfirm,
  ])

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppStateProvider')
  return ctx
}