import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { CheckCircle2, ListChecks } from 'lucide-react'
import { useApp } from '../context/AppState'
import { ApiError } from '../lib/api'
import { money } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'

export default function Tasks() {
  const app = useApp()
  const nav = useNavigate()

  useEffect(() => { void app.loadTasks() }, [app.loadTasks])

  const claim = async (taskId: string, title: string) => {
    try {
      const reward = await app.claimTask(taskId)
      app.toast(`${title}: +${money(reward)}`, 'success')
    } catch (err) {
      app.toast(err instanceof ApiError ? err.message : 'That task could not be claimed.', 'error')
    }
  }

  if (!app.authenticated) return null

  const done = app.tasks.filter((t) => t.claimed).length

  return (
    <div>
      <PageHeader title="Tasks" subtitle={`${done}/${app.tasks.length} completed`} />

      <div className="px-4 py-4 grid grid-cols-2 gap-2">
        <Card className="p-3">
          <p className="text-[10px] text-muted">Withdrawable</p>
          <p className="font-extrabold text-text text-lg">{money(app.wallet?.available_centavos ?? 0)}</p>
        </Card>
        <Card className="p-3">
          <p className="text-[10px] text-muted">Claimable now</p>
          <p className="font-extrabold text-text text-lg">{app.tasks.filter((t) => t.claimable).length}</p>
        </Card>
      </div>

      <div className="px-4 space-y-2.5 pb-4">
        {app.tasks.length === 0 ? (
          <EmptyState
            icon={<ListChecks size={22} />}
            title="No tasks available"
            description="Daily tasks are published by DriveVest. Check back tomorrow."
          />
        ) : (
          app.tasks.map((task) => (
            <Card key={task.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-bold text-text text-sm">{task.title}</p>
                  {task.description && <p className="text-[11px] text-muted mt-0.5">{task.description}</p>}
                  <div className="flex items-center gap-1.5 mt-2">
                    <Badge color="violet">+{money(task.reward_points)}</Badge>
                    <Badge color="gray">{task.recurring === 'daily' ? 'daily' : 'one-time'}</Badge>
                  </div>
                </div>
                {task.claimed ? (
                  <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 shrink-0">
                    <CheckCircle2 size={14} /> Claimed
                  </span>
                ) : (
                  <Button
                    size="sm"
                    className="shrink-0"
                    onClick={() => (task.action_url ? nav(task.action_url) : claim(task.id, task.title))}
                  >
                    {task.action_url ? 'Open' : 'Claim'}
                  </Button>
                )}
              </div>
            </Card>
          ))
        )}

        <p className="text-[11px] text-muted text-center pt-2 leading-relaxed">
          Points are promotional credits, separate from withdrawable funds.
        </p>
      </div>
    </div>
  )
}