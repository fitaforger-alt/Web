import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Copy, Share2, Users } from 'lucide-react'
import { useApp } from '../context/AppState'
import { money } from '../utils/format'
import { relativeDay } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'

export default function Share() {
  const app = useApp()
  const nav = useNavigate()
  const [link, setLink] = useState('')

  useEffect(() => {
    if (!app.authenticated) return
    void app.loadReferrals()
  }, [app.authenticated, app.loadReferrals])

  const code = app.referrals?.code ?? app.user?.referral_code ?? ''
  const shareLink = `${window.location.origin}${app.referrals?.link ?? `/register?ref=${code}`}`
  useEffect(() => { setLink(shareLink) }, [shareLink])

  if (!app.authenticated) return null

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(shareLink)
      app.toast('Referral link copied.', 'success')
    } catch {
      app.toast('Could not copy automatically. Select the link and copy it manually.', 'error')
    }
  }

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join me on DriveVest',
          text: `Use my referral code ${code} when you register.`,
          url: shareLink,
        })
        return
      } catch {
        return
      }
    }
    void copy()
  }

  return (
    <div>
      <PageHeader title="Invite & referral" />

      <div className="px-4 py-4 space-y-4 pb-4">
        <Card className="p-5 text-center">
          <p className="text-xs text-muted">Your referral code</p>
          <p className="font-extrabold text-text text-2xl mt-1 tracking-wide">{code}</p>
          <p className="text-[11px] text-muted mt-2 break-all px-2">{link}</p>
          <div className="flex gap-2 mt-4">
            <Button className="flex-1" variant="secondary" onClick={copy} icon={<Copy size={16} />}>Copy link</Button>
            <Button className="flex-1" onClick={share} icon={<Share2 size={16} />}>Share</Button>
          </div>
        </Card>

        <div className="grid grid-cols-2 gap-2">
          <Card className="p-4 text-center">
            <p className="text-[10px] text-muted">People invited</p>
            <p className="font-extrabold text-text text-2xl">{app.referrals?.total ?? 0}</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-[10px] text-muted">Bonus earned</p>
            <p className="font-extrabold text-text text-2xl">{money(app.referrals?.bonus_earned_centavos ?? 0)}</p>
          </Card>
        </div>

        <Card className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Users size={15} className="text-muted" />
            <p className="font-bold text-text text-sm">Your invites</p>
          </div>
          {(app.referrals?.rows.length ?? 0) === 0 ? (
            <EmptyState title="No referrals yet" description="Share your link. When someone registers with your code, they appear here." />
          ) : (
            app.referrals!.rows.map((row) => (
              <div key={row.id} className="flex items-center justify-between py-2.5 border-b border-gray-50 last:border-0">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-text truncate">{row.username}</p>
                  <p className="text-[10px] text-muted">{relativeDay(row.created_at)}</p>
                </div>
                <span className="text-[11px] font-bold text-brand">
                  {row.reward_centavos > 0 ? `+${money(row.reward_centavos)}` : 'joined'}
                </span>
              </div>
            ))
          )}
        </Card>

        <Card className="p-4 bg-amber-50/50 border-amber-100">
          <p className="text-[11px] text-amber-900 leading-relaxed">
            {app.referrals?.terms ?? 'A one-time bonus is credited when someone registers with your code. Referral activity is not guaranteed income.'}
          </p>
        </Card>

        {app.user?.referred_by && (
          <Card className="p-4">
            <p className="text-xs text-muted">You joined with the referral code of</p>
            <p className="font-bold text-text text-sm mt-0.5">{app.user.referred_by}</p>
          </Card>
        )}

        <button onClick={() => nav('/team')} className="w-full text-[11px] text-brand font-bold py-2">
          View your referral network →
        </button>
      </div>
    </div>
  )
}