import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { dateStr } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, Skeleton } from '../components/ui/Card'
import type { NewsArticle } from '../types'

export default function Article() {
  const { id } = useParams()
  const nav = useNavigate()
  const app = useApp()
  const [article, setArticle] = useState<NewsArticle & { body: string } | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return
    let cancelled = false
    setArticle(null)
    api<NewsArticle & { body: string }>(`/api/news/${id}`)
      .then((res) => { if (!cancelled) setArticle(res) })
      .catch((err) => { if (!cancelled) setError(err instanceof ApiError ? err.message : 'Could not load this article.') })
    return () => { cancelled = true }
  }, [id])

  if (error) {
    return (
      <div>
        <PageHeader title="Article" />
        <div className="px-6 py-12 text-center">
          <p className="text-sm font-semibold text-text">Article not found</p>
          <button onClick={() => nav('/news')} className="text-xs font-bold text-brand mt-3">Back to news</button>
        </div>
      </div>
    )
  }

  if (!article) {
    return (
      <div className="p-4 space-y-3">
        <Skeleton className="h-52" />
        <Skeleton className="h-32" />
      </div>
    )
  }

  return (
    <div>
      <PageHeader title={article.category} />
      <div className="px-4 py-4 pb-4">
        <Card className="overflow-hidden">
          {article.image_url && <img src={article.image_url} alt="" className="w-full h-48 object-cover" />}
          <div className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Badge color="gray">{article.category}</Badge>
              <span className="text-[10px] text-muted">{dateStr(article.published_at)}</span>
            </div>
            <h1 className="font-extrabold text-text text-lg leading-snug">{article.title}</h1>
            <p className="text-sm text-muted mt-2 leading-relaxed">{article.summary}</p>
            <p className="text-sm text-text mt-4 leading-relaxed whitespace-pre-line">{article.body}</p>
          </div>
        </Card>

        {app.authenticated && (
          <p className="text-[11px] text-muted text-center mt-4">
            Reading articles completes a daily task. Check your{' '}
            <button onClick={() => nav('/tasks')} className="font-bold text-brand">tasks</button>.
          </p>
        )}
      </div>
    </div>
  )
}