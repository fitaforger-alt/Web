import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Users } from 'lucide-react'
import { useApp } from '../context/AppState'
import Card, { EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'

export default function Team() {
  const app = useApp()
  const nav = useNavigate()

  useEffect(() => {
    if (app.authenticated) void app.loadReferrals()
  }, [app.authenticated, app.loadReferrals])

  if (!app.authenticated) return null

  const rows = app.referrals?.rows ?? []
  const direct = rows.length
  const secondLevel = rows.filter((r) => r.level === 2).length
  const thirdLevel = rows.filter((r) => r.level === 3).length

  return (
    <div>
      <PageHeaderShim />
      <div className="px-4 py-4 space-y-4 pb-4">
        <div className="px-4 -mt-4 grid grid-cols-3 gap-2">
          <Card className="p-3 text-center">
            <p className="text-[10px] text-muted">Direct</p>
            <p className="font-extrabold text-text text-lg">{direct}</p>
          </Card>
          <Card className="p-3 text-center">
            <p className="text-[10px] text-muted">Level 2</p>
            <p className="font-extrabold text-text text-lg">{secondLevel}</p>
          </Card>
          <Card className="p-3 text-center">
            <p className="text-[10px] text-muted">Level 3</p>
            <p className="font-extrabold text-text text-lg">{thirdLevel}</p>
          </Card>
        </div>

        <Card className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Users size={15} className="text-muted" />
            <p className="font-bold text-text text-sm">Your network</p>
          </div>
          {rows.length === 0 ? (
            <EmptyState title="No referrals yet" description="Invite friends with your referral link to build your network." />
          ) : (
            <div className="space-y-2.5">
              {rows.map((row) => (
                <div key={row.id} className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-brand/10 text-brand flex items-center justify-center text-xs font-extrabold shrink-0">
                    L{row.level}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-text truncate">{row.username}</p>
                    <p className="text-[10px] text-muted">Joined via your code</p>
                  </div>
                  <span className="text-[11px] font-bold text-brand">
                    {row.reward_centavos > 0 ? `+${money(row.reward_centavos)}` : '—'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Button block variant="secondary" onClick={() => nav('/share')}>Invite more people</Button>
      </div>
    </div>
  )
}

function PageHeaderShim() {
  const nav = useNavigate()
  return (
    <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100 sticky top-0 z-30">
      <button onClick={() => nav(-1)} className="p-2 -ml-2 rounded-full hover:bg-gray-100">‹</button>
      <h1 className="text-base font-extrabold text-text">My network</h1>
      <div className="w-9" />
    </div>
  )
}