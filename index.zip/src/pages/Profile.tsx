import { useNavigate } from 'react-router-dom'
import {
  ArrowDownToLine, ArrowRightLeft, CalendarCheck, Car, CreditCard, Gift, HelpCircle,
  History, ListChecks, Lock, LogOut, MessageSquare, Newspaper, Receipt, Share2, Ticket, UserCog,
} from 'lucide-react'
import { useApp } from '../context/AppState'
import { money, dateStr } from '../utils/format'
import Card, { Badge, Row } from '../components/ui/Card'
import Button from '../components/ui/Button'

const SHORTCUTS = [
  { label: 'My plans', to: '/plans', Icon: Car },
  { label: 'Records', to: '/records', Icon: Receipt },
  { label: 'Withdrawals', to: '/withdrawals', Icon: ArrowDownToLine },
  { label: 'Destinations', to: '/bank-card', Icon: CreditCard },
  { label: 'Check-in', to: '/checkin', Icon: CalendarCheck },
  { label: 'Tasks', to: '/tasks', Icon: ListChecks },
  { label: 'Invite', to: '/share', Icon: Share2 },
  { label: 'Network', to: '/team', Icon: Share2 },
  { label: 'Redeem', to: '/redeem', Icon: Gift },
  { label: 'Wheel', to: '/wheel', Icon: Gift },
  { label: 'Inbox', to: '/messages', Icon: MessageSquare },
  { label: 'Support', to: '/help', Icon: HelpCircle },
  { label: 'Security', to: '/security', Icon: Lock },
  { label: 'FAQ', to: '/faq', Icon: HelpCircle },
]

export default function Profile() {
  const app = useApp()
  const nav = useNavigate()
  const user = app.user
  const wallet = app.wallet

  if (!app.authenticated || !user) {
    return (
      <div className="px-4 py-12 text-center">
        <p className="text-sm font-bold text-text">Sign in to view your profile</p>
        <div className="flex gap-2 justify-center mt-4">
          <Button onClick={() => nav('/login', { state: { from: '/profile' } })}>Sign in</Button>
          <Button variant="secondary" onClick={() => nav('/register')}>Register</Button>
        </div>
      </div>
    )
  }

  const activePlans = app.plans.filter((p) => p.status === 'active')
  const dailyIncome = activePlans.reduce((s, p) => s + p.projected_daily_centavos, 0)

  const logout = () => {
    app.openConfirm({
      title: 'Log out',
      message: 'You will need your username and password to sign back in.',
      confirmLabel: 'Log out',
      tone: 'danger',
      onConfirm: async () => {
        await app.logout()
        nav('/', { replace: true })
      },
    })
  }

  return (
    <div>
      <div className="px-4 pt-4 pb-3 bg-white flex items-center justify-between border-b border-gray-100">
        <h1 className="text-base font-extrabold text-text">Profile</h1>
        <button onClick={logout} className="flex items-center gap-1 text-[11px] font-bold text-brand">
          <LogOut size={13} /> Log out
        </button>
      </div>

      <div className="px-4 py-4 space-y-4">
        <Card className="p-4 flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-brand text-white flex items-center justify-center font-extrabold text-xl">
            {user.username.slice(0, 2).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-extrabold text-text truncate">{user.username}</p>
            <p className="text-[10px] text-muted break-all">ID: {user.id}</p>
            <div className="flex gap-1.5 mt-1.5">
              <Badge color={user.status === 'Active' ? 'green' : 'amber'}>{user.status ?? 'Active'}</Badge>
              <Badge color="blue">{user.membership ?? 'Bronze'}</Badge>
            </div>
          </div>
        </Card>

        <div className="grid grid-cols-2 gap-2">
          <Card className="p-3.5">
            <p className="text-[10px] text-muted">Withdrawable</p>
            <p className="font-extrabold text-text text-sm mt-0.5">{money(wallet?.available_centavos ?? 0)}</p>
          </Card>
          <Card className="p-3.5">
            <p className="text-[10px] text-muted">Recharge</p>
            <p className="font-extrabold text-text text-sm mt-0.5">{money(wallet?.recharge_centavos ?? 0)}</p>
          </Card>
          <Card className="p-3.5">
            <p className="text-[10px] text-muted">Active plans</p>
            <p className="font-extrabold text-text text-sm mt-0.5">{activePlans.length}</p>
          </Card>
        </div>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <p className="font-bold text-text text-sm">Wallet</p>
            {wallet && wallet.reserved_centavos > 0 && <Badge color="amber">{money(wallet.reserved_centavos)} held</Badge>}
          </div>
          <div className="mt-1">
            <Row label="Earnings total" value={money(wallet?.earnings_centavos ?? 0)} />
            <Row label="Available now" value={money(wallet?.available_centavos ?? 0)} />
            <Row label="Daily income from active plans" value={money(dailyIncome)} />
          </div>
          <div className="flex gap-2 mt-3">
            <Button className="flex-1" onClick={() => nav('/recharge')}>Recharge</Button>
            <Button className="flex-1" variant="secondary" onClick={() => nav('/withdraw')}>Withdraw</Button>
          </div>
        </Card>

        <Card className="p-4">
          <p className="font-bold text-text text-sm mb-2">Account</p>
          <Row label="Username" value={user.username} />
          <Row label="Referral code" value={user.referral_code} />
          <Row label="Registered" value={user.created_at ? dateStr(user.created_at) : '—'} />
          <Row label="Last sign-in" value={user.last_login ? dateStr(user.last_login) : 'This session'} />
          <Row label="Transactions" value={app.transactionTotal} />
        </Card>

        <div>
          <p className="font-bold text-text text-sm mb-2 px-1">Quick links</p>
          <div className="grid grid-cols-4 gap-2">
            {SHORTCUTS.map(({ label, to, Icon }) => (
              <button key={label} onClick={() => nav(to)} className="flex flex-col items-center gap-1.5 py-2">
                <div className="w-10 h-10 rounded-xl bg-white border border-gray-100 flex items-center justify-center text-text">
                  <Icon size={17} />
                </div>
                <span className="text-[9px] text-muted text-center leading-tight">{label}</span>
              </button>
            ))}
          </div>
        </div>

        <Card className="p-4 space-y-2">
          <button onClick={() => nav('/news')} className="w-full flex items-center justify-between text-sm">
            <span className="flex items-center gap-2 font-semibold text-text"><Newspaper size={16} className="text-muted" /> News</span>
            <ArrowRightLeft size={14} className="text-muted" />
          </button>
          <button onClick={() => nav('/about')} className="w-full flex items-center justify-between text-sm border-t border-gray-50 pt-2">
            <span className="flex items-center gap-2 font-semibold text-text"><UserCog size={16} className="text-muted" /> About DriveVest</span>
            <ArrowRightLeft size={14} className="text-muted" />
          </button>
          <button onClick={() => nav('/help')} className="w-full flex items-center justify-between text-sm border-t border-gray-50 pt-2">
            <span className="flex items-center gap-2 font-semibold text-text"><Ticket size={16} className="text-muted" /> Open a support ticket</span>
            <ArrowRightLeft size={14} className="text-muted" />
          </button>
          <button onClick={() => nav('/records')} className="w-full flex items-center justify-between text-sm border-t border-gray-50 pt-2">
            <span className="flex items-center gap-2 font-semibold text-text"><History size={16} className="text-muted" /> Full transaction history</span>
            <ArrowRightLeft size={14} className="text-muted" />
          </button>
        </Card>
      </div>
    </div>
  )
}