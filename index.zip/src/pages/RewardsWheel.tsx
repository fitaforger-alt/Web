import { useEffect, useState } from 'react'
import { Info } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { money } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Row } from '../components/ui/Card'
import Button from '../components/ui/Button'

interface WheelOutcome { label: string; amountCentavos?: number; amount_centavos?: number; probability: number }
interface WheelState {
  rules: { currency_note: string; cost: string; outcomes: WheelOutcome[] }
  spun_today: boolean
  today_result: { outcome: string; points?: number } | null
  history: { outcome: string; points?: number; created_at: string }[]
}

const SEGMENT_COLORS = ['#ED1725', '#F59E0B', '#16A34A', '#3B82F6', '#8B5CF6']

export default function RewardsWheel() {
  const app = useApp()
  const [state, setState] = useState<WheelState | null>(null)
  const [rotation, setRotation] = useState(0)
  const [spinning, setSpinning] = useState(false)
  const [result, setResult] = useState<{ outcome: string; amountCentavos: number } | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!app.authenticated) return
    api<WheelState>('/api/wheel').then(setState).catch(() => setError('Could not load the wheel.'))
  }, [app.authenticated])

  const spin = async () => {
    if (spinning || state?.spun_today) return
    setSpinning(true)
    setResult(null)
    setError(null)
    setRotation((r) => r + 1440 + Math.floor(Math.random() * 360))
    try {
      const res = await app.spinWheel()
      setResult({ outcome: res.outcome, amountCentavos: res.amountCentavos })
      const next = await api<WheelState>('/api/wheel')
      setState(next)
      app.toast(
        res.amountCentavos > 0 ? `Won ${money(res.amountCentavos)}` : 'No prize this time',
        res.amountCentavos > 0 ? 'success' : 'info',
      )
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'The spin could not be completed.')
    } finally {
      setSpinning(false)
    }
  }

  if (!app.authenticated) return null

  const outcomes = state?.rules.outcomes ?? []
  const background = outcomes.length > 0
    ? `conic-gradient(${outcomes.map((_, i) => `${SEGMENT_COLORS[i % SEGMENT_COLORS.length]} ${(i * 360) / outcomes.length}deg ${((i + 1) * 360) / outcomes.length}deg`).join(', ')})`
    : 'conic-gradient(#9096A5 0deg 360deg)'

  return (
    <div>
      <PageHeader title="Rewards wheel" />

      <div className="px-4 py-6 flex flex-col items-center gap-5">
        <Card className="p-4 w-full text-center">
          <p className="text-xs font-bold text-text">Spin to earn cash</p>
          <p className="text-[11px] text-muted mt-1">{state?.rules.cost}</p>
        </Card>

        <div className="relative w-64 h-64">
          <div className="absolute -top-2 left-1/2 -translate-x-1/2 z-10 w-0 h-0 border-l-7 border-r-7 border-t-[16px] border-l-transparent border-r-transparent border-t-brand" />
          <div
            className="w-64 h-64 rounded-full shadow-lg border-4 border-white"
            style={{
              background,
              transform: `rotate(${rotation}deg)`,
              transition: spinning ? 'transform 4s cubic-bezier(0.17,0.67,0.12,0.99)' : 'none',
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-16 h-16 rounded-full bg-white shadow-md flex items-center justify-center font-extrabold text-brand text-xs">
              SPIN
            </div>
          </div>
        </div>

        <Button
          size="lg"
          onClick={spin}
          loading={spinning}
          disabled={state?.spun_today}
          className="w-44"
        >
          {state?.spun_today ? 'Spun today' : 'Spin'}
        </Button>

        {error && <p className="text-xs text-red-500">{error}</p>}
        {result && (
          <Card className="p-4 w-full text-center">
            <p className="text-xs text-muted">Result</p>
            <p className="font-extrabold text-text mt-1">{result.outcome}</p>
            <p className="text-[11px] text-muted mt-1">Credited to your withdrawable balance.</p>
          </Card>
        )}

        <Card className="p-4 w-full">
          <div className="flex items-center gap-1.5 mb-2">
            <Info size={14} className="text-brand" />
            <p className="font-bold text-text text-sm">Published odds</p>
          </div>
          {outcomes.map((o) => (
            <Row key={o.label} label={o.label} value={`${o.probability}%`} />
          ))}
          <p className="text-[11px] text-muted mt-3 leading-relaxed">{state?.rules.currency_note}</p>
        </Card>

        <Card className="p-4 w-full">
          <p className="font-bold text-text text-sm mb-2">Your recent spins</p>
          {(state?.history.length ?? 0) === 0 ? (
            <p className="text-xs text-muted">No spins yet.</p>
          ) : (
            state!.history.map((h, index) => (
              <Row key={index} label={h.outcome} value={(h.points ?? 0) > 0 ? `+${money(h.points as number)}` : '—'} />
            ))
          )}
        </Card>
      </div>
    </div>
  )
}