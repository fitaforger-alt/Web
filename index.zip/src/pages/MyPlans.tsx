import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Car, Pause, ShieldCheck } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { money, dateStr, dateTimeStr } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState, Row } from '../components/ui/Card'
import Button from '../components/ui/Button'
import type { UserPlan } from '../types'

export default function MyPlans() {
  const nav = useNavigate()
  const app = useApp()
  const plans = app.plans
  const active = plans.filter((p) => p.status === 'active')

  return (
    <div>
      <PageHeader title="My Plans" subtitle={`${plans.length} total`} />

      <div className="px-4 py-4 grid grid-cols-3 gap-2">
        <Card className="p-3 text-center">
          <p className="text-[10px] text-muted">Active</p>
          <p className="font-extrabold text-text text-lg">{active.length}</p>
        </Card>
        <Card className="p-3 text-center">
          <p className="text-[10px] text-muted">Daily income</p>
          <p className="font-extrabold text-text text-sm">
            {money(active.reduce((sum, p) => sum + p.projected_daily_centavos, 0))}
          </p>
        </Card>
        <Card className="p-3 text-center">
          <p className="text-[10px] text-muted">Invested</p>
          <p className="font-extrabold text-text text-sm">{money(plans.reduce((s, p) => s + p.amount_centavos, 0))}</p>
        </Card>
      </div>

      <div className="px-4 space-y-3 pb-4">
        {plans.length === 0 ? (
          <EmptyState
            icon={<Car size={22} />}
            title="No plans yet"
            description="Activate a product plan and it will appear here with its terms and daily income."
            action={<Button size="sm" onClick={() => nav('/products')}>Browse products</Button>}
          />
        ) : (
          plans.map((plan) => <PlanCard key={plan.id} plan={plan} onOpen={() => nav(`/plans/${plan.id}`)} />)
        )}
      </div>
    </div>
  )
}

export function PlanCard({ plan, onOpen }: { plan: UserPlan; onOpen: () => void }) {
  const statusColor = plan.status === 'active' ? 'green' : plan.status === 'paused' ? 'amber' : plan.status === 'cancelled' ? 'red' : 'gray'
  return (
    <Card className="p-4 cursor-pointer hover:shadow-md transition" onClick={onOpen}>
      <div className="flex gap-3">
        <div className="w-12 h-12 rounded-xl bg-brand/10 text-brand flex items-center justify-center font-extrabold shrink-0">
          {plan.plan_name.slice(0, 2).toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <p className="font-bold text-text text-sm truncate">{plan.plan_name}</p>
            <Badge color={statusColor}>{plan.status}</Badge>
          </div>
          <p className="text-[11px] text-muted mt-1">
            {money(plan.amount_centavos)} · {dateStr(plan.start_date)} → {dateStr(plan.end_date)}
          </p>
          <p className="text-[11px] font-semibold text-brand mt-0.5">
            {money(plan.projected_daily_centavos)} credited every 24 hours
          </p>
          <p className="text-[10px] text-muted mt-0.5">
            {plan.source === 'admin' ? 'Assigned by DriveVest' : `Purchased · terms v${plan.plan_version}`}
          </p>
          {plan.status === 'active' && (
            <div className="mt-2">
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-brand rounded-full transition-all" style={{ width: `${plan.progress_percent}%` }} />
              </div>
              <p className="text-[10px] text-muted mt-1">{plan.progress_percent}% of the term elapsed</p>
            </div>
          )}
        </div>
      </div>
    </Card>
  )
}

interface SettlementRow {
  day_number: number
  amount_centavos: number
  settled_at: string
  reference: string
  balance_after_centavos: number | null
}

interface PlanSettlements {
  plan: UserPlan
  duration_days: number
  days_completed: number
  daily_income_centavos: number
  total_income_centavos: number
  next_settlement_at: string | null
  rows: SettlementRow[]
}

export function PlanDetailPanel({ planId }: { planId: string }) {
  const app = useApp()
  const [data, setData] = useState<PlanSettlements | null>(null)
  const [error, setError] = useState<string | null>(null)

  const plan = data?.plan ?? app.plans.find((p) => p.id === planId) ?? null

  useEffect(() => {
    let cancelled = false
    api<PlanSettlements>(`/api/user-plans/${planId}/settlements`)
      .then((res) => { if (!cancelled) setData(res) })
      .catch((err) => { if (!cancelled) setError(err instanceof ApiError ? err.message : 'Could not load plan income.') })
    return () => { cancelled = true }
  }, [planId, app.plans])

  if (!plan) {
    return (
      <div className="px-6 py-12 text-center">
        <p className="text-sm font-semibold text-text">Plan not found</p>
        <p className="text-xs text-muted mt-1">This plan is not on your account.</p>
      </div>
    )
  }

  let terms: { terms?: string; eligibility?: string } = {}
  try { terms = JSON.parse(plan.terms_snapshot) } catch { terms = {} }

  const duration = data?.duration_days ?? 0
  const daysCompleted = data?.days_completed ?? plan.days_completed ?? 0
  const totalIncome = data?.total_income_centavos ?? daysCompleted * plan.projected_daily_centavos

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-extrabold text-text">{plan.plan_name}</h2>
          <Badge color={plan.status === 'active' ? 'green' : plan.status === 'cancelled' ? 'red' : 'gray'}>{plan.status}</Badge>
        </div>
        <div className="mt-3">
          <Row label="Amount allocated" value={money(plan.amount_centavos)} />
          <Row label="Daily income" value={<span className="text-brand">{money(plan.projected_daily_centavos)}</span>} />
          <Row label="Start date" value={dateStr(plan.start_date)} />
          <Row label="End date" value={dateStr(plan.end_date)} />
          <Row label="Terms version" value={`v${plan.plan_version}`} />
          <Row label="Source" value={plan.source === 'admin' ? 'Assigned by DriveVest' : 'Purchased'} />
        </div>
      </Card>

      <Card className="p-4">
        <p className="font-bold text-text text-sm mb-2">Daily income credited</p>
        <Row label="Days completed" value={duration > 0 ? `${daysCompleted} of ${duration}` : String(daysCompleted)} />
        <Row label="Income per day" value={money(plan.projected_daily_centavos)} />
        <Row label="Total credited to date" value={<span className="text-brand font-extrabold">{money(totalIncome)}</span>} />
        <Row
          label="Next credit"
          value={
            plan.status !== 'active'
              ? 'Plan is not running'
              : data?.next_settlement_at
                ? dateTimeStr(data.next_settlement_at)
                : 'Term complete'
          }
        />

        {duration > 0 && (
          <div className="mt-3">
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-brand rounded-full transition-all"
                style={{ width: `${Math.min(100, Math.round((daysCompleted / duration) * 100))}%` }}
              />
            </div>
            <p className="text-[10px] text-muted mt-1">
              {Math.round((daysCompleted / duration) * 100)}% of the term settled
            </p>
          </div>
        )}

        <p className="text-[11px] text-muted mt-3 leading-relaxed">
          Income is credited to your earnings wallet once every completed 24-hour period, so it counts toward what you
          can withdraw. The first credit lands 24 hours after activation, then once a day. Each credit appears in your
          records with its own reference.
        </p>
      </Card>

      {error && <p className="text-xs text-red-500">{error}</p>}

      <Card className="p-4">
        <p className="font-bold text-text text-sm mb-2">Credit history</p>
        {(data?.rows.length ?? 0) === 0 ? (
          <p className="text-xs text-muted py-3 text-center">
            No income credited yet. The first credit lands 24 hours after activation.
          </p>
        ) : (
          data!.rows.map((row) => (
            <div key={row.day_number} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-text">Day {row.day_number}</p>
                <p className="text-[10px] text-muted">{dateTimeStr(row.settled_at)}</p>
              </div>
              <span className="text-xs font-bold text-emerald-600">+{money(row.amount_centavos)}</span>
            </div>
          ))
        )}
      </Card>

      <Card className="p-4">
        <h3 className="font-bold text-text text-sm mb-2">Terms you accepted</h3>
        <p className="text-xs text-muted leading-relaxed">{terms.terms ?? 'Terms unavailable for this record.'}</p>
        <h3 className="font-bold text-text text-sm mt-3">Eligibility</h3>
        <p className="text-xs text-muted leading-relaxed">{terms.eligibility ?? 'Not recorded.'}</p>
        <div className="flex items-start gap-2 mt-3 text-[11px] text-muted">
          <ShieldCheck size={14} className="text-brand shrink-0 mt-0.5" />
          This is the copy stored when the plan started. Later changes to the product do not rewrite it.
        </div>
      </Card>

      {plan.status === 'paused' && (
        <Card className="p-3 flex items-center gap-2 text-xs text-amber-700 bg-amber-50/60 border-amber-100">
          <Pause size={14} /> This plan is paused by DriveVest. Contact support if that is unexpected.
        </Card>
      )}
    </div>
  )
}