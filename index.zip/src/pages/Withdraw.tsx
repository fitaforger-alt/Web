import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlertTriangle, Clock } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { money, toCentavos, relativeDay } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState, Row } from '../components/ui/Card'
import Button from '../components/ui/Button'
import Input, { Select } from '../components/ui/Input'
import type { Withdrawal } from '../types'

interface Limits {
  min_centavos: number
  fee_centavos: number
  fee_percent: number
  daily_limit_centavos: number
}

export default function Withdraw() {
  const nav = useNavigate()
  const app = useApp()
  const [limits, setLimits] = useState<Limits | null>(null)
  const [history, setHistory] = useState<Withdrawal[]>([])
  const [amount, setAmount] = useState('')
  const [destinationId, setDestinationId] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const available = app.wallet?.available_centavos ?? 0
  const destinations = app.destinations

  useEffect(() => {
    if (!app.authenticated) return
    api<{ limits: Limits; rows: Withdrawal[] }>('/api/withdrawals').then((res) => {
      setLimits(res.limits)
      setHistory(res.rows)
    }).catch(() => setError('Could not load withdrawal settings.'))
  }, [app.authenticated])

  useEffect(() => {
    if (!destinationId && destinations.length > 0) setDestinationId(destinations[0].id)
  }, [destinations, destinationId])

  const amountCentavos = toCentavos(amount)
  const fee = limits ? limits.fee_centavos + Math.floor((amountCentavos * limits.fee_percent) / 10000) : 0
  const net = amountCentavos - fee

  const valid = Number.isFinite(amountCentavos)
    && amountCentavos >= (limits?.min_centavos ?? 0)
    && amountCentavos <= available
    && destinationId !== ''

  const submit = () => {
    if (!valid) {
      setError(`Enter an amount between ${money(limits?.min_centavos ?? 0)} and ${money(available)}.`)
      return
    }
    const destination = destinations.find((d) => d.id === destinationId)
    app.openConfirm({
      title: 'Confirm withdrawal',
      message:
        `Amount: ${money(amountCentavos)}\n` +
        `Fee: ${money(fee)}\n` +
        `Net payout: ${money(net)}\n` +
        `To: ${destination?.masked}\n\n` +
        `The amount is held immediately so it cannot be spent twice. It leaves your wallet only once the payout is confirmed.`,
      confirmLabel: 'Request withdrawal',
      onConfirm: async () => {
        setBusy(true)
        setError(null)
        try {
          await app.requestWithdrawal(amountCentavos, destinationId)
          app.toast('Withdrawal requested. The amount is now held.', 'success')
          setAmount('')
          const res = await api<{ rows: Withdrawal[] }>('/api/withdrawals')
          setHistory(res.rows)
        } catch (err) {
          setError(err instanceof ApiError ? err.message : 'The withdrawal request failed.')
        } finally {
          setBusy(false)
        }
      },
    })
  }

  return (
    <div>
      <PageHeader title="Withdraw" subtitle="Held until payout is confirmed" />

      <div className="px-4 py-4 space-y-4 pb-24">
        {error && (
          <Card className="p-3 bg-red-50/60 border-red-100 flex items-start gap-2">
            <AlertTriangle size={15} className="text-red-600 shrink-0 mt-0.5" />
            <p className="text-xs text-red-700 leading-relaxed">{error}</p>
          </Card>
        )}

        <Card className="p-4">
          <Row label="Available to withdraw" value={<span className="text-lg">{money(available)}</span>} />
          {!!app.wallet?.reserved_centavos && (
            <Row label="Held for pending payouts" value={money(app.wallet.reserved_centavos)} />
          )}
          <Row label="Minimum" value={money(limits?.min_centavos ?? 0)} />
          <Row label="Fee" value={money(limits?.fee_centavos ?? 0) + ` (+${(limits?.fee_percent ?? 0) / 100}%)`} />
        </Card>

        {destinations.length === 0 ? (
          <EmptyState
            title="No payout destination saved"
            description="Add the account that should receive your payout before requesting a withdrawal."
            action={<Button size="sm" onClick={() => nav('/bank-card')}>Add destination</Button>}
          />
        ) : (
          <Card className="p-4 space-y-3">
            <Input
              label="Amount (PHP)"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              error={amount !== '' && !Number.isFinite(amountCentavos) ? 'Enter a valid amount.' : undefined}
            />
            <Select label="Payout destination" value={destinationId} onChange={(e) => setDestinationId(e.target.value)}>
              {destinations.map((d) => <option key={d.id} value={d.id}>{d.holder_name} · {d.masked}</option>)}
            </Select>
            <div className="rounded-xl bg-gray-50 p-3 space-y-1.5">
              <Row label="Amount" value={money(Math.max(0, amountCentavos || 0))} />
              <Row label="Fee" value={money(fee)} />
              <Row label="Net payout" value={<span className="text-brand font-extrabold">{money(Math.max(0, net))}</span>} />
            </div>
            <Button block size="lg" loading={busy} disabled={!valid} onClick={submit}>Request withdrawal</Button>
          </Card>
        )}

        <Card className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock size={15} className="text-muted" />
            <p className="font-bold text-text text-sm">Your requests</p>
          </div>
          {history.length === 0 ? (
            <p className="text-xs text-muted py-3 text-center">No withdrawal requests yet.</p>
          ) : (
            history.map((w) => (
              <div key={w.id} className="py-2.5 border-b border-gray-50 last:border-0">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-text">{money(w.net_centavos)}</span>
                  <Badge color={w.status === 'completed' ? 'green' : w.status === 'rejected' || w.status === 'failed' ? 'red' : 'amber'}>
                    {w.status.replace('_', ' ')}
                  </Badge>
                </div>
                <p className="text-[10px] text-muted mt-0.5">
                  {w.reference} · {w.destination_masked} · {relativeDay(w.created_at)}
                </p>
                {w.payout_reference && <p className="text-[10px] text-emerald-700 mt-0.5">Payout ref {w.payout_reference}</p>}
              </div>
            ))
          )}
        </Card>
      </div>
    </div>
  )
}