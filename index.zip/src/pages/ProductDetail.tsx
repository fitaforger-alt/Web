import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { CheckCircle2, Info, ShieldCheck } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { money } from '../utils/format'
import Card, { Badge, Row, Skeleton } from '../components/ui/Card'
import Button from '../components/ui/Button'
import type { Product } from '../types'

interface PlanDetail extends Product {
  versions: { version: number; created_at: string; change_reason: string }[]
}

export default function ProductDetail() {
  const { id } = useParams()
  const nav = useNavigate()
  const app = useApp()
  const [plan, setPlan] = useState<PlanDetail | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!id) return
    let cancelled = false
    setPlan(null)
    setError(null)
    api<PlanDetail>(`/api/plans/${id}`)
      .then((res) => { if (!cancelled) setPlan(res) })
      .catch((err) => { if (!cancelled) setError(err instanceof ApiError ? err.message : 'Could not load this product.') })
    return () => { cancelled = true }
  }, [id])

  if (error) {
    return (
      <div className="px-4 py-10 text-center">
        <p className="text-sm font-semibold text-text">Product unavailable</p>
        <p className="text-xs text-muted mt-1">{error}</p>
        <Button className="mt-4" variant="secondary" onClick={() => nav('/products')}>Back to products</Button>
      </div>
    )
  }

  if (!plan) {
    return (
      <div className="p-4 space-y-3">
        <Skeleton className="h-52" />
        <Skeleton className="h-40" />
      </div>
    )
  }

  const soldOut = plan.slots_remaining !== null && plan.slots_remaining === 0
  const balance = app.wallet?.recharge_centavos ?? 0
  const affordable = balance >= plan.price_centavos

  const handleBuy = () => {
    if (!app.authenticated) {
      nav('/login', { state: { from: `/products/${plan.id}` } })
      return
    }
    app.openConfirm({
      title: `Activate ${plan.name}?`,
      message:
        `${money(plan.price_centavos)} will be taken from your recharge wallet.\n\n` +
        `${plan.duration_days} day term from today.\n` +
        `${money(plan.projected_daily_centavos)} is credited to your earnings wallet once every completed 24-hour period, for ${plan.duration_days} days.\n` +
        `That is ${money(plan.projected_daily_centavos * plan.duration_days)} in total.\n\n` +
        `After activation: ${money(balance - plan.price_centavos)} recharge balance.`,
      confirmLabel: 'Activate plan',
      onConfirm: async () => {
        setBusy(true)
        try {
          await app.purchasePlan(plan.id)
          app.toast('Plan activated. It is now in My Plans.', 'success')
          nav('/plans')
        } catch (err) {
          app.toast(err instanceof ApiError ? err.message : 'The plan could not be activated.', 'error')
        } finally {
          setBusy(false)
        }
      },
    })
  }

  return (
    <div>
      <div className="px-4 py-3 bg-white border-b border-gray-100 flex items-center">
        <button onClick={() => nav(-1)} className="p-2 -ml-2 rounded-full hover:bg-gray-100">‹</button>
        <h1 className="flex-1 text-center text-base font-extrabold text-text truncate px-2">{plan.name}</h1>
        <div className="w-9" />
      </div>

      <div className="px-4 py-4 space-y-4">
        {plan.image_url && (
          <Card className="overflow-hidden">
            <img src={plan.image_url} alt="" className="w-full h-48 object-cover" />
          </Card>
        )}

        <Card className="p-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="font-extrabold text-text text-lg">{plan.name}</h2>
            <Badge color={plan.category === 'vip' ? 'violet' : 'blue'}>{plan.category}</Badge>
          </div>
          <p className="text-xs text-muted mt-1.5">{plan.description}</p>
          <div className="mt-4">
            <Row label="Price" value={<span className="font-extrabold text-brand">{money(plan.price_centavos)}</span>} />
            <Row label="Duration" value={`${plan.duration_days} days`} />
            <Row label="Daily income (credited every 24h)" value={<span className="text-brand">{money(plan.projected_daily_centavos)}</span>} />
            <Row label="Fees" value="None" />
            <Row
              label="Availability"
              value={plan.slots_total > 0 ? `${plan.slots_remaining} of ${plan.slots_total} slots left` : 'Open'}
            />
            <Row label="Terms version" value={`v${plan.current_version}`} />
          </div>
        </Card>

        <Card className="p-4 space-y-2">
          <h3 className="font-bold text-text text-sm flex items-center gap-1.5"><Info size={14} className="text-brand" /> Published terms</h3>
          <p className="text-xs text-muted leading-relaxed">{plan.terms}</p>
          <h3 className="font-bold text-text text-sm pt-2">Eligibility</h3>
          <p className="text-xs text-muted leading-relaxed">{plan.eligibility}</p>
          <div className="flex items-start gap-2 pt-2 text-[11px] text-muted">
            <ShieldCheck size={14} className="text-brand shrink-0 mt-0.5" />
            <span className="leading-relaxed">
              These terms are stored with your plan when you activate it. If DriveVest updates the terms later, the copy
              you accepted stays on your record.
            </span>
          </div>
        </Card>

        {app.authenticated && (
          <Card className="p-4 flex items-center justify-between">
            <span className="text-xs text-muted">Recharge balance</span>
            <span className="font-bold text-text text-sm">{money(balance)}</span>
          </Card>
        )}

        {plan.versions.length > 0 && (
          <Card className="p-4">
            <h3 className="font-bold text-text text-sm mb-2">Terms history</h3>
            {plan.versions.map((v) => (
              <div key={v.version} className="flex items-start gap-2 py-1.5 text-[11px]">
                <CheckCircle2 size={13} className="text-emerald-500 shrink-0 mt-0.5" />
                <span className="text-muted">
                  <strong className="text-text">v{v.version}</strong> — {v.change_reason}
                </span>
              </div>
            ))}
          </Card>
        )}

        <Button block size="lg" loading={busy} disabled={soldOut} onClick={handleBuy}>
          {!app.authenticated ? 'Sign in to activate' : soldOut ? 'No slots remaining' : affordable ? 'Activate plan' : 'Insufficient recharge balance'}
        </Button>
      </div>
    </div>
  )
}