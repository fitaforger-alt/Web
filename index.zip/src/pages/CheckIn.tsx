import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CalendarCheck, Flame } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { money } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Row } from '../components/ui/Card'
import Button from '../components/ui/Button'

interface CheckinState {
  streak: number
  last_checkin: string | null
  checked_in_today: boolean
  reward_centavos: number
  wallet: string
}

export default function CheckIn() {
  const app = useApp()
  const nav = useNavigate()
  const [state, setState] = useState<CheckinState | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!app.authenticated) return
    api<CheckinState>('/api/checkin').then(setState).catch(() => setError('Could not load your check-in status.'))
  }, [app.authenticated])

  const handle = async () => {
    setBusy(true)
    setError(null)
    try {
      const res = await app.checkIn()
      setState({
        streak: res.streak,
        last_checkin: new Date().toISOString().slice(0, 10),
        checked_in_today: true,
        reward_centavos: res.reward_centavos,
        wallet: res.wallet,
      })
      app.toast(`Checked in. ${money(res.reward_centavos)} added to your earnings`, 'success')
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Check-in failed.')
    } finally {
      setBusy(false)
    }
  }

  if (!app.authenticated) return null

  return (
    <div>
      <PageHeader title="Daily check-in" />

      <div className="px-4 py-4 space-y-4">
        <Card className="p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-brand/10 flex items-center justify-center mx-auto mb-3">
            <CalendarCheck size={30} className="text-brand" />
          </div>
          <p className="text-3xl font-extrabold text-text">{state?.streak ?? 0}</p>
          <p className="text-xs text-muted mt-1">day check-in streak</p>

          <div className="mt-5">
            {state?.checked_in_today ? (
              <p className="text-sm font-bold text-emerald-600">Checked in today</p>
            ) : (
              <Button block loading={busy} onClick={handle} icon={<Flame size={16} />}>
                Check in for {money(state?.reward_centavos ?? 0)}
              </Button>
            )}
          </div>
        </Card>

        {error && <p className="text-xs text-red-500 text-center">{error}</p>}

        <Card className="p-4">
          <p className="font-bold text-text text-sm mb-1">Your reward</p>
          <Row
            label="Credited to"
            value={<span className="text-brand">Earnings wallet (withdrawable)</span>}
          />
          <Row label="Per check-in" value={money(state?.reward_centavos ?? 0)} />
          <Row label="Withdrawable balance" value={money(app.wallet?.available_centavos ?? 0)} />
          <Row label="Last check-in" value={state?.last_checkin ?? 'None yet'} />
          <p className="text-[11px] text-muted mt-2 leading-relaxed">
            Check-in pays straight into your withdrawable balance. There are no points — what you earn here is real
            money you can cash out.
          </p>
        </Card>

        <Card className="p-4">
          <p className="font-bold text-text text-sm mb-2">This week</p>
          <div className="grid grid-cols-7 gap-1.5">
            {Array.from({ length: 7 }).map((_, i) => {
              const active = (state?.streak ?? 0) > i
              return (
                <div key={i} className={`h-9 rounded-lg flex items-center justify-center text-[10px] font-bold ${active ? 'bg-brand text-white' : 'bg-gray-100 text-muted'}`}>
                  D{i + 1}
                </div>
              )
            })}
          </div>
        </Card>

        <button onClick={() => nav('/tasks')} className="w-full text-[11px] text-brand font-bold py-2">
          See other ways to earn →
        </button>
      </div>
    </div>
  )
}