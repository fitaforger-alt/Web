import { useEffect, useState } from 'react'
import { Gift } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { money, relativeDay } from '../utils/format'
import Card, { Badge, EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'

interface Redemption {
  id: string
  code: string
  wallet: string
  value: number
  created_at: string
}

export default function Redeem() {
  const app = useApp()
  const [code, setCode] = useState('')
  const [history, setHistory] = useState<Redemption[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!app.authenticated) return
    api<Redemption[]>('/api/redemptions').then(setHistory).catch(() => setHistory([]))
  }, [app.authenticated])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!code.trim()) return
    setBusy(true)
    setError(null)
    try {
      const used = await app.redeemCode(code.trim())
      app.toast(`Redeemed ${used}`, 'success')
      setCode('')
      setHistory(await api<Redemption[]>('/api/redemptions'))
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'That code could not be redeemed.')
    } finally {
      setBusy(false)
    }
  }

  if (!app.authenticated) return null

  return (
    <div>
      <div className="bg-gradient-to-br from-brand to-brand-dark text-white px-4 py-6">
        <h1 className="text-xl font-extrabold">Redeem</h1>
        <p className="text-xs opacity-85 mt-1">Codes are validated on the server, with expiry and use limits</p>
      </div>

      <div className="px-4 -mt-4 space-y-4 pb-4">
        <Card className="p-5">
          <div className="w-16 h-16 rounded-2xl bg-brand/10 flex items-center justify-center mx-auto mb-3">
            <Gift size={28} className="text-brand" />
          </div>
          <form onSubmit={submit} className="space-y-3">
            <Input
              label="Redemption code"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="ENTER-CODE"
              autoComplete="off"
              error={error ?? undefined}
            />
            <Button type="submit" block loading={busy} disabled={!code.trim()}>Redeem</Button>
          </form>
        </Card>

        <div className="grid grid-cols-3 gap-2">
          <Card className="p-3 text-center">
            <p className="text-[10px] text-muted">Codes used</p>
            <p className="font-extrabold text-text">{history.length}</p>
          </Card>
          <Card className="p-3 text-center">
            <p className="text-[10px] text-muted">Total redeemed</p>
            <p className="font-extrabold text-text text-sm">
              {money(history.filter((h) => h.wallet !== 'points').reduce((s, h) => s + h.value, 0))}
            </p>
          </Card>
        </div>

        <Card className="p-4">
          <p className="font-bold text-text text-sm mb-2">Redemption history</p>
          {history.length === 0 ? (
            <EmptyState title="No redemptions yet" description="Redeemed codes are recorded here with their value." />
          ) : (
            history.map((h) => (
              <div key={h.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-text truncate">{h.code}</p>
                  <p className="text-[10px] text-muted">{relativeDay(h.created_at)}</p>
                </div>
                <Badge color={h.wallet === 'recharge' ? 'blue' : 'green'}>
                  +{money(h.value)}
                </Badge>
              </div>
            ))
          )}
        </Card>
      </div>
    </div>
  )
}