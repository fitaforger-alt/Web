import { useNavigate } from 'react-router-dom'
import { ArrowDownToLine } from 'lucide-react'
import { useApp } from '../context/AppState'
import { money, relativeDay } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'

export default function Withdrawals() {
  const nav = useNavigate()
  const app = useApp()
  const rows = app.transactions.filter((t) => t.kind.startsWith('withdrawal'))

  return (
    <div>
      <PageHeader title="Withdrawal log" />

      <div className="px-4 py-4 space-y-2 pb-4">
        {rows.length === 0 ? (
          <EmptyState
            icon={<ArrowDownToLine size={22} />}
            title="No withdrawals"
            description="Requested payouts appear here with their status and payout reference."
            action={<Button size="sm" onClick={() => nav('/withdraw')}>Request a withdrawal</Button>}
          />
        ) : (
          rows.map((entry) => (
            <Card key={entry.id} className="p-3.5 flex items-center justify-between">
              <div className="min-w-0">
                <p className="font-semibold text-text text-sm">
                  {entry.kind === 'withdrawal_payout' ? 'Withdrawal paid out'
                    : entry.kind === 'withdrawal_release' ? 'Withdrawal released'
                      : 'Withdrawal requested'}
                </p>
                <p className="text-[10px] text-muted truncate">{entry.reference}</p>
                <p className="text-[10px] text-muted">{relativeDay(entry.created_at)}</p>
                {entry.note && <p className="text-[10px] text-muted mt-0.5">{entry.note}</p>}
              </div>
              <div className="text-right ml-3 shrink-0">
                <p className="font-bold text-text text-sm">{money(entry.amount_centavos)}</p>
                <Badge
                  color={
                    entry.status === 'completed' ? 'green'
                      : entry.status === 'pending' ? 'amber'
                        : entry.kind === 'withdrawal_release' ? 'blue' : 'gray'
                  }
                >
                  {entry.kind === 'withdrawal_release' ? 'returned' : entry.status}
                </Badge>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}