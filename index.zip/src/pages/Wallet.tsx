import { useNavigate } from 'react-router-dom'
import { ArrowDownToLine, CreditCard, Gift, History, Plus, Receipt, Trash2 } from 'lucide-react'
import { useApp } from '../context/AppState'
import { money, relativeDay } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState, Row } from '../components/ui/Card'
import Button from '../components/ui/Button'

const LEDE_LABELS: Record<string, string> = {
  welcome_reward: 'Welcome reward',
  referral_bonus: 'Referral bonus',
  deposit: 'Deposit credited',
  withdrawal_hold: 'Withdrawal requested',
  withdrawal_release: 'Withdrawal released',
  withdrawal_payout: 'Withdrawal paid out',
  plan_purchase: 'Plan purchase',
  plan_assignment: 'Plan assignment',
  plan_grant: 'Plan granted by DriveVest',
  manual_adjustment: 'Adjustment',
  manual_adjustment_reversal: 'Adjustment reversed',
  checkin: 'Daily check-in',
  task_reward: 'Task reward',
  wheel_prize: 'Wheel prize',
  redemption: 'Redemption',
}

const LINKS = [
  { label: 'Balance record', to: '/records', icon: Receipt },
  { label: 'Withdrawal history', to: '/withdrawals', icon: ArrowDownToLine },
  { label: 'Payout destinations', to: '/bank-card', icon: CreditCard },
  { label: 'All transactions', to: '/records?wallet=all', icon: History },
]

export default function Wallet() {
  const nav = useNavigate()
  const app = useApp()
  const wallet = app.wallet

  const welcome = app.transactions.find((t) => t.kind === 'welcome_reward')
  const recent = app.transactions.slice(0, 6)

  return (
    <div>
      <PageHeader title="Wallet" />

      <div className="px-4 mt-4">
        <div className="rounded-2xl p-5 bg-gradient-to-br from-brand to-brand-dark text-white shadow-lg">
          <p className="text-xs opacity-85">Withdrawable balance</p>
          <p className="text-3xl font-extrabold tracking-tight mt-1">{money(wallet?.available_centavos ?? 0)}</p>
          <div className="flex gap-4 mt-3 text-[11px] opacity-90">
            <span>Earnings {money(wallet?.earnings_centavos ?? 0)}</span>
            {!!wallet?.reserved_centavos && <span>Held {money(wallet.reserved_centavos)}</span>}
          </div>
          <div className="flex gap-2 mt-4">
            <Button size="sm" className="bg-white text-brand hover:bg-white/90" onClick={() => nav('/withdraw')}>Withdraw</Button>
            <Button size="sm" className="bg-white/15 text-white hover:bg-white/25" onClick={() => nav('/recharge')}>Recharge</Button>
          </div>
        </div>
      </div>

      <div className="px-4 mt-4 space-y-3">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <p className="font-bold text-text text-sm">Recharge wallet</p>
            <Badge color="blue">For plans</Badge>
          </div>
          <p className="text-2xl font-extrabold text-text mt-2">{money(wallet?.recharge_centavos ?? 0)}</p>
          <p className="text-[11px] text-muted mt-1">Credited only when a payment provider confirms your deposit.</p>
          <Button size="sm" className="mt-3" onClick={() => nav('/recharge')} icon={<Plus size={14} />}>Recharge</Button>
        </Card>

        {welcome && (
          <Card className="p-4">
            <div className="flex items-center gap-2">
              <Gift size={16} className="text-brand" />
              <p className="font-bold text-text text-sm">Welcome reward</p>
            </div>
            <p className="text-lg font-extrabold text-brand mt-2">{money(welcome.amount_centavos)}</p>
            <Row label="Issued" value={relativeDay(welcome.created_at)} />
            <Row label="Reference" value={<span className="text-[11px] break-all">{welcome.reference}</span>} />
            <p className="text-[11px] text-muted mt-2 leading-relaxed">
              {app.settings?.welcome_reward_withdrawable
                ? 'This reward is withdrawable and counts toward your available balance.'
                : 'This reward is promotional and is not withdrawable cash.'}
            </p>
          </Card>
        )}

        <Card className="p-4">
          <p className="font-bold text-text text-sm mb-2">Income history</p>
          {recent.length === 0 ? (
            <p className="text-xs text-muted py-2">No transactions available.</p>
          ) : (
            recent.map((entry) => (
              <div key={entry.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-text">{LEDE_LABELS[entry.kind] ?? entry.kind}</p>
                  <p className="text-[10px] text-muted">{relativeDay(entry.created_at)}</p>
                </div>
                <span className={`text-xs font-bold ${entry.direction === 'credit' ? 'text-emerald-600' : 'text-text'}`}>
                  {entry.direction === 'credit' ? '+' : '−'}{money(entry.amount_centavos)}
                </span>
              </div>
            ))
          )}
          <button onClick={() => nav('/records')} className="text-[11px] font-bold text-brand mt-2">View all →</button>
        </Card>

        {LINKS.map(({ label, to, icon: Icon }) => (
          <Card key={label} className="p-4 flex items-center justify-between cursor-pointer hover:shadow-md transition" onClick={() => nav(to)}>
            <span className="flex items-center gap-2 font-semibold text-text text-sm">
              <Icon size={16} className="text-muted" /> {label}
            </span>
            <span className="text-muted">›</span>
          </Card>
        ))}

        {app.destinations.length === 0 && (
          <EmptyState
            icon={<Trash2 size={20} />}
            title="No payout destination saved"
            description="Add a destination before requesting a withdrawal."
            action={<Button size="sm" variant="secondary" onClick={() => nav('/bank-card')}>Add destination</Button>}
          />
        )}
      </div>
      <div className="h-4" />
    </div>
  )
}