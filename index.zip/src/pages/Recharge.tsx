import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlertTriangle, CheckCircle2, Clock, CreditCard } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { money, toCentavos } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'
import type { Deposit, PaymentMethod } from '../types'

interface MethodsResponse {
  methods: PaymentMethod[]
  presets: number[]
  min_centavos: number
  max_centavos: number
  note: string
}

export default function Recharge() {
  const nav = useNavigate()
  const app = useApp()
  const [data, setData] = useState<MethodsResponse | null>(null)
  const [deposits, setDeposits] = useState<Deposit[]>([])
  const [method, setMethod] = useState('')
  const [amount, setAmount] = useState('')
  const [reference, setReference] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!app.authenticated) return
    api<MethodsResponse>('/api/deposits/methods').then((res) => {
      setData(res)
      const firstEnabled = res.methods.find((m) => m.enabled)
      if (firstEnabled) setMethod(firstEnabled.id)
    }).catch(() => setError('Could not load deposit options.'))
    api<{ rows: Deposit[] }>('/api/deposits').then((res) => setDeposits(res.rows)).catch(() => setDeposits([]))
  }, [app.authenticated])

  const enabledMethods = data?.methods.filter((m) => m.enabled) ?? []
  const amountCentavos = toCentavos(amount)
  const valid = Number.isFinite(amountCentavos)
    && amountCentavos >= (data?.min_centavos ?? 0)
    && amountCentavos <= (data?.max_centavos ?? 0)
    && method !== ''
    && reference.trim().length >= 4

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!valid) {
      setError(`Enter an amount between ${money(data?.min_centavos ?? 0)} and ${money(data?.max_centavos ?? 0)} and your payment reference.`)
      return
    }
    setError(null)
    setBusy(true)
    try {
      await app.requestDeposit(amountCentavos, method, reference.trim())
      app.toast('Deposit submitted. It credits once the provider confirms your payment.', 'success')
      setAmount('')
      setReference('')
      const res = await api<{ rows: Deposit[] }>('/api/deposits')
      setDeposits(res.rows)
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'The deposit request could not be submitted.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <PageHeader title="Recharge" subtitle="Provider-confirmed deposits" />

      <div className="px-4 py-4 space-y-4 pb-24">
        {error && (
          <Card className="p-3 bg-red-50/60 border-red-100 flex items-start gap-2">
            <AlertTriangle size={15} className="text-red-600 shrink-0 mt-0.5" />
            <p className="text-xs text-red-700 leading-relaxed">{error}</p>
          </Card>
        )}

        <Card className="p-4">
          <div className="flex items-center gap-2">
            <CreditCard size={16} className="text-brand" />
            <p className="font-bold text-text text-sm">Payment method</p>
          </div>
          {!data && <p className="text-xs text-muted mt-2">Loading payment options…</p>}
          {data && enabledMethods.length === 0 && (
            <p className="text-xs text-muted mt-2 leading-relaxed">{data.note}</p>
          )}
          {enabledMethods.length > 0 && (
            <div className="grid grid-cols-2 gap-2 mt-3">
              {data!.methods.map((m) => (
                <button
                  key={m.id}
                  disabled={!m.enabled}
                  onClick={() => setMethod(m.id)}
                  className={`py-2.5 rounded-xl text-sm font-bold border transition disabled:opacity-40 disabled:cursor-not-allowed ${
                    method === m.id ? 'bg-brand text-white border-brand' : 'bg-white text-muted border-gray-200'
                  }`}
                >
                  {m.label}
                  {!m.enabled && <span className="block text-[9px] font-medium">Not connected</span>}
                </button>
              ))}
            </div>
          )}
          {enabledMethods.length > 0 && (
            <div className="mt-3 p-3 rounded-xl bg-gray-50">
              <p className="text-[11px] text-muted leading-relaxed">
                {data!.methods.find((m) => m.id === method)?.instructions}
              </p>
            </div>
          )}
        </Card>

        {enabledMethods.length > 0 && (
          <Card className="p-4 space-y-3">
            <div>
              <p className="text-xs font-semibold text-muted mb-2">Preset amounts</p>
              <div className="grid grid-cols-4 gap-2">
                {(data?.presets ?? []).map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setAmount(String(preset / 100))}
                    className={`py-2 rounded-xl text-xs font-bold border transition ${
                      amountCentavos === preset ? 'bg-brand text-white border-brand' : 'bg-white text-text border-gray-200'
                    }`}
                  >
                    {money(preset)}
                  </button>
                ))}
              </div>
            </div>
            <Input
              label="Amount (PHP)"
              type="text"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
            />
            <Input
              label="Payment reference"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              placeholder="Reference from your payment receipt"
            />
            <p className="text-[11px] text-muted">
              Minimum {money(data?.min_centavos ?? 0)} · maximum {money(data?.max_centavos ?? 0)}. Your wallet is
              credited only after the provider confirms the payment.
            </p>
            <form onSubmit={submit}>
              <Button type="submit" block loading={busy} disabled={!valid}>Submit deposit request</Button>
            </form>
          </Card>
        )}

        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Clock size={15} className="text-muted" />
            <p className="font-bold text-text text-sm">Deposit requests</p>
          </div>
          {deposits.length === 0 ? (
            <EmptyState title="No deposit requests" description="Submitted requests appear here with their status." />
          ) : (
            deposits.map((d) => (
              <div key={d.id} className="py-2.5 border-b border-gray-50 last:border-0">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-text">{money(d.amount_centavos)}</span>
                  <Badge color={d.status === 'approved' ? 'green' : d.status === 'pending' || d.status === 'under_review' ? 'amber' : d.status === 'rejected' ? 'red' : 'gray'}>
                    {d.status.replace('_', ' ')}
                  </Badge>
                </div>
                <p className="text-[10px] text-muted mt-0.5">{d.reference} · {d.method}</p>
                {d.verification_state === 'unverified' ? (
                  <p className="text-[10px] text-amber-700 mt-1">Awaiting provider confirmation</p>
                ) : (
                  <p className="text-[10px] text-emerald-700 mt-1 flex items-center gap-1">
                    <CheckCircle2 size={11} /> Verified via {d.verification_state.replace('_', ' ')}
                  </p>
                )}
                {d.review_reason && <p className="text-[10px] text-muted mt-0.5">{d.review_reason}</p>}
              </div>
            ))
          )}
        </Card>

        {app.error && <p className="text-[11px] text-muted text-center">{app.error}</p>}
        <button onClick={() => nav('/help')} className="w-full text-[11px] text-brand font-bold py-2">
          Need help with a deposit?
        </button>
      </div>
    </div>
  )
}