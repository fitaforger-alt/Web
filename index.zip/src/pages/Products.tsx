import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Info } from 'lucide-react'
import { useApp } from '../context/AppState'
import { money } from '../utils/format'
import Card, { Badge, EmptyState, Skeleton } from '../components/ui/Card'
import Button from '../components/ui/Button'
import type { Product } from '../types'

export default function Products() {
  const nav = useNavigate()
  const app = useApp()
  const [tab, setTab] = useState<'daily' | 'vip'>('daily')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    void app.loadProducts().finally(() => setLoading(false))
  }, [app.loadProducts])

  const list = app.products.filter((p) => p.category === tab)
  const boughtIds = new Set(app.plans.filter((p) => p.status === 'active' && p.plan_id).map((p) => p.plan_id as string))

  return (
    <div>
      <div className="px-4 py-3 bg-white border-b border-gray-100 flex items-center justify-between">
        <Link to="/" className="w-9 h-9 rounded-xl bg-brand text-white flex items-center justify-center font-black">D</Link>
        <h1 className="text-base font-extrabold text-text">Products</h1>
        <div className="w-9" />
      </div>

      <div className="px-4 mt-4 flex gap-2">
        {(['daily', 'vip'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition ${
              tab === t ? 'bg-brand text-white shadow-sm' : 'bg-white text-muted border border-gray-200'
            }`}
          >
            {t === 'daily' ? 'Daily Products' : 'VIP Products'}
          </button>
        ))}
      </div>

      <div className="px-4 mt-4 space-y-3 pb-4">
        {loading && <><Skeleton className="h-28" /><Skeleton className="h-28" /></>}
        {!loading && list.length === 0 && (
          <EmptyState
            icon={<Info size={22} />}
            title={app.products.length === 0 ? 'No products published' : 'Nothing in this category'}
            description={app.products.length === 0 ? 'Products have not been released yet.' : 'Try the other tab.'}
          />
        )}
        {!loading && list.map((p) => <ProductCard key={p.id} plan={p} owned={boughtIds.has(p.id)} onOpen={() => nav(`/products/${p.id}`)} />)}
      </div>
    </div>
  )
}

function ProductCard({ plan, owned, onOpen }: { plan: Product; owned: boolean; onOpen: () => void }) {
  const slotsLeft = plan.slots_total > 0 ? Math.max(0, plan.slots_total - plan.slots_taken) : null
  const soldOut = slotsLeft !== null && slotsLeft === 0

  return (
    <Card className="p-3 flex gap-3">
      {plan.image_url && <img src={plan.image_url} alt="" className="w-24 h-20 rounded-xl object-cover flex-shrink-0" loading="lazy" />}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <p className="font-bold text-text text-sm truncate">{plan.name}</p>
          <Badge color={plan.category === 'vip' ? 'violet' : 'blue'}>{plan.category}</Badge>
        </div>
        <p className="text-xs text-muted mt-1">
          Price <span className="font-bold text-text">{money(plan.price_centavos)}</span> · {plan.duration_days} days
        </p>
        <p className="text-[11px] font-semibold text-brand">
          {money(plan.projected_daily_centavos)} credited every 24 hours
        </p>
        <p className="text-[11px] text-muted">
          {soldOut ? 'No slots remaining' : slotsLeft !== null ? `${slotsLeft} of ${plan.slots_total} slots left` : 'Slots available'}
        </p>
        <div className="flex gap-2 mt-2.5">
          <Button size="sm" variant="secondary" className="flex-1" onClick={onOpen} icon={<Info size={13} />}>Details</Button>
          <Button size="sm" className="flex-1" onClick={onOpen} disabled={soldOut}>
            {soldOut ? 'Sold out' : owned ? 'Buy again' : 'Activate'}
          </Button>
        </div>
      </div>
    </Card>
  )
}

