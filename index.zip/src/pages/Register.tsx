import { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import { ShieldCheck, Sparkles } from 'lucide-react'
import { useApp } from '../context/AppState'
import { ApiError } from '../lib/api'
import { money } from '../utils/format'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'

export default function Register() {
  const app = useApp()
  const nav = useNavigate()
  const location = useLocation()
  const [params] = useSearchParams()

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [referralCode, setReferralCode] = useState(params.get('ref') ?? '')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (app.authenticated) nav('/', { replace: true })
  }, [app.authenticated, nav])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    const next: Record<string, string> = {}
    if (username.trim().length < 3) next.username = 'Username must be at least 3 characters.'
    if (password.length < 8) next.password = 'Password must be at least 8 characters.'
    else if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) next.password = 'Use at least one letter and one number.'
    setErrors(next)
    if (Object.keys(next).length > 0) return

    setBusy(true)
    try {
      await app.register(username.trim(), password, referralCode)
      nav('/', { replace: true })
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.code === 'invalid_referral_code') setErrors({ referralCode: err.message })
        else if (err.code === 'username_taken') setErrors({ username: err.message })
        else if (err.code === 'invalid_username') setErrors({ username: err.message })
        else if (err.code === 'invalid_password') setErrors({ password: err.message })
        else app.toast(err.message, 'error')
      } else {
        app.toast('Registration failed. Nothing was created.', 'error')
      }
    } finally {
      setBusy(false)
    }
  }

  const welcomeAmount = app.settings?.welcome_reward_centavos ?? 5000

  return (
    <div className="min-h-screen bg-bg flex flex-col">
      <div className="bg-gradient-to-br from-brand to-brand-dark px-6 pt-12 pb-10 text-white">
        <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center mb-4">
          <span className="font-black text-xl">D</span>
        </div>
        <h1 className="text-2xl font-extrabold leading-tight">Create your DriveVest account</h1>
        <p className="text-sm opacity-90 mt-2">Three fields. One welcome reward. No email or phone required.</p>
      </div>

      <div className="flex-1 px-4 -mt-6 pb-10">
        <Card className="p-6 max-w-md mx-auto">
          <form onSubmit={submit} className="space-y-4" noValidate>
            <Input
              label="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              error={errors.username}
              placeholder="Choose a username"
              autoComplete="username"
              maxLength={24}
              required
            />
            <Input
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              error={errors.password}
              hint="At least 8 characters, including a letter and a number. Use the eye icon to check what you typed."
              autoComplete="new-password"
              required
            />
            <Input
              label="Referral code (optional)"
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
              error={errors.referralCode}
              placeholder="DV-XXXXXX"
              autoComplete="off"
            />

            <Button type="submit" block loading={busy} icon={<Sparkles size={16} />}>
              Register and claim {money(welcomeAmount)}
            </Button>
          </form>

          <p className="text-xs text-center text-muted mt-4">
            Already have an account?{' '}
            <Link to="/login" state={location.state} className="text-brand font-bold">Sign in</Link>
          </p>
        </Card>

        <Card className="p-4 max-w-md mx-auto mt-4 flex items-start gap-3">
          <ShieldCheck size={18} className="text-brand shrink-0 mt-0.5" />
          <p className="text-[11px] text-muted leading-relaxed">
            Your password is hashed on the server and never stored or emailed. Balances, plans and rewards are
            recorded in DriveVest&apos;s ledger, so you can see every movement with its reference.
          </p>
        </Card>
      </div>
    </div>
  )
}