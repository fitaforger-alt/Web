import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  ArrowDownToLine, CalendarCheck, Car, ChevronRight, Gift, History, Share2,
  Wallet as WalletIcon,
} from 'lucide-react'
import { useApp } from '../context/AppState'
import { money, relativeDay } from '../utils/format'
import Card, { Badge, EmptyState, Skeleton } from '../components/ui/Card'
import Button from '../components/ui/Button'

const SHORTCUTS = [
  { label: 'Recharge', icon: WalletIcon, to: '/recharge', tone: 'bg-red-50 text-brand' },
  { label: 'Withdraw', icon: ArrowDownToLine, to: '/withdraw', tone: 'bg-amber-50 text-amber-600' },
  { label: 'Invite', icon: Share2, to: '/share', tone: 'bg-blue-50 text-blue-600' },
  { label: 'Rewards', icon: Gift, to: '/wheel', tone: 'bg-emerald-50 text-emerald-600' },
]

const LEDE_LABELS: Record<string, string> = {
  welcome_reward: 'Welcome reward',
  referral_bonus: 'Referral bonus',
  deposit: 'Deposit',
  withdrawal_hold: 'Withdrawal requested',
  withdrawal_release: 'Withdrawal released',
  withdrawal_payout: 'Withdrawal paid',
  plan_purchase: 'Plan purchase',
  plan_assignment: 'Plan assignment',
  plan_grant: 'Plan granted',
  manual_adjustment: 'Adjustment',
  checkin: 'Daily check-in',
  task_reward: 'Task reward',
  wheel_prize: 'Wheel prize',
  redemption: 'Redemption',
}

export default function Home() {
  const nav = useNavigate()
  const app = useApp()
  const wallet = app.wallet

  useEffect(() => {
    void app.loadProducts()
    void app.loadNews()
  }, [app.loadProducts, app.loadNews])

  const claimableTasks = app.tasks.filter((t) => t.claimable)
  const completedTasks = app.tasks.filter((t) => t.claimed)
  const featuredPlans = app.products.slice(0, 2)
  const recent = app.transactions.slice(0, 3)

  return (
    <div>
      {/* Header */}
      <div className="bg-gradient-to-br from-brand to-brand-dark px-4 pt-5 pb-16 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center font-black text-lg">D</div>
            <div>
              <div className="font-extrabold leading-none">{app.settings?.platform_name ?? 'DriveVest'}</div>
              <div className="text-[10px] opacity-80">{app.settings?.platform_tagline ?? 'Drive Forward'}</div>
            </div>
          </div>
          {app.authenticated && (
            <button onClick={() => nav('/messages')} className="text-[11px] font-semibold bg-white/15 hover:bg-white/25 px-3 py-1.5 rounded-full transition">
              Inbox
            </button>
          )}
        </div>

        <div className="mt-6">
          <p className="text-xs opacity-80">{app.authenticated ? `Hi, ${app.user?.username}` : 'Your wallet'}</p>
          <p className="text-3xl font-extrabold tracking-tight mt-1">
            {app.loading && !wallet ? '—' : money(wallet?.available_centavos ?? 0)}
          </p>
          <p className="text-[11px] opacity-80 mt-1">Withdrawable balance</p>
        </div>
      </div>

      {/* Wallet cards */}
      <div className="px-4 -mt-10 grid grid-cols-2 gap-2">
        <Card className="p-3">
          <p className="text-[10px] text-muted">Recharge</p>
          <p className="font-extrabold text-text text-sm mt-0.5">{money(wallet?.recharge_centavos ?? 0)}</p>
        </Card>
        <Card className="p-3">
          <p className="text-[10px] text-muted">Withdrawable</p>
          <p className="font-extrabold text-text text-sm mt-0.5">{money(wallet?.available_centavos ?? 0)}</p>
        </Card>
      </div>

      {wallet && wallet.reserved_centavos > 0 && (
        <div className="px-4 mt-3">
          <Card className="p-3 bg-amber-50/60 border-amber-100">
            <p className="text-[11px] text-amber-800">
              <strong>{money(wallet.reserved_centavos)}</strong> is held for a pending withdrawal and cannot be spent again.
            </p>
          </Card>
        </div>
      )}

      {/* Shortcuts */}
      <div className="px-4 mt-5 grid grid-cols-4 gap-2">
        {SHORTCUTS.map(({ label, icon: Icon, to, tone }) => (
          <button key={label} onClick={() => nav(to)} className="flex flex-col items-center gap-1.5 group">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${tone} group-active:scale-95 transition`}>
              <Icon size={21} />
            </div>
            <span className="text-[11px] font-semibold text-text">{label}</span>
          </button>
        ))}
      </div>

      {!app.authenticated && (
        <div className="px-4 mt-5">
          <Card className="p-5 text-center">
            <h3 className="font-extrabold text-text">Create your account</h3>
            <p className="text-xs text-muted mt-1.5">
              Register with a username, a password and an optional referral code. New accounts receive a one-time
              welcome reward of {money(app.settings?.welcome_reward_centavos ?? 5000)}.
            </p>
            <div className="flex gap-2 mt-4">
              <Button className="flex-1" onClick={() => nav('/register')}>Register</Button>
              <Button className="flex-1" variant="secondary" onClick={() => nav('/login')}>Sign in</Button>
            </div>
          </Card>
        </div>
      )}

      {/* Daily activity */}
      <div className="px-4 mt-6">
        <SectionTitle title="Daily activity" to="/tasks" />
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-bold text-text text-sm">Check-in streak</p>
              <p className="text-xs text-muted mt-0.5">
                {app.stats?.checkin_streak ?? 0} day streak · {completedTasks.length}/{app.tasks.length} tasks done
              </p>
            </div>
            <Button
              size="sm"
              disabled={app.stats?.checked_in_today}
              onClick={() => nav('/checkin')}
              icon={<CalendarCheck size={14} />}
            >
              {app.stats?.checked_in_today ? 'Done' : 'Check in'}
            </Button>
          </div>
          {claimableTasks.length > 0 && (
            <div className="mt-3 pt-3 border-t border-gray-100">
              <p className="text-[11px] font-bold text-text mb-2">Ready to claim</p>
              {claimableTasks.slice(0, 3).map((task) => (
                <button
                  key={task.id}
                  onClick={() => nav('/tasks')}
                  className="w-full flex items-center justify-between py-1.5 text-left"
                >
                  <span className="text-xs text-text">{task.title}</span>
                  <span className="text-[11px] font-bold text-brand">+{money(task.reward_points)}</span>
                </button>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Latest news */}
      <div className="px-4 mt-6">
        <SectionTitle title="Latest news" to="/news" />
        <div className="space-y-2.5">
          {app.news.length === 0 && <Skeleton className="h-20" />}
          {app.news.slice(0, 3).map((article) => (
            <Card key={article.id} className="p-3 flex gap-3 cursor-pointer hover:shadow-md transition" onClick={() => nav(`/news/${article.id}`)}>
              {article.image_url && <img src={article.image_url} alt="" className="w-16 h-16 rounded-xl object-cover flex-shrink-0" loading="lazy" />}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-1">
                  {article.is_new && <Badge color="red">New</Badge>}
                  <span className="text-[10px] text-muted">{relativeDay(article.published_at)}</span>
                </div>
                <p className="font-semibold text-sm text-text line-clamp-1">{article.title}</p>
                <p className="text-xs text-muted line-clamp-2 mt-0.5">{article.summary}</p>
              </div>
            </Card>
          ))}
          {app.news.length > 0 && app.news.length === 0 && <p className="text-xs text-muted">No news published yet.</p>}
        </div>
      </div>

      {/* Recommended products */}
      <div className="px-4 mt-6">
        <SectionTitle title="Recommended products" to="/products" />
        <div className="space-y-2.5">
          {featuredPlans.length === 0 && <Skeleton className="h-24" />}
          {featuredPlans.map((plan) => (
            <Card key={plan.id} className="p-3 flex gap-3 cursor-pointer hover:shadow-md transition" onClick={() => nav(`/products/${plan.id}`)}>
              {plan.image_url && <img src={plan.image_url} alt="" className="w-20 h-16 rounded-xl object-cover flex-shrink-0" loading="lazy" />}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-text text-sm truncate">{plan.name}</p>
                  <Badge color={plan.category === 'vip' ? 'violet' : 'blue'}>{plan.category}</Badge>
                </div>
                <p className="text-xs text-muted mt-1">
                  <span className="font-semibold text-text">{money(plan.price_centavos)}</span> · {plan.duration_days} days
                </p>
                <p className="text-[10px] text-muted mt-0.5">Projected daily {money(plan.projected_daily_centavos)} (estimate)</p>
              </div>
            </Card>
          ))}
          {app.products.length === 0 && app.news.length > 0 && (
            <EmptyState icon={<Car size={22} />} title="No products published" description="Check back soon." />
          )}
        </div>
      </div>

      {/* Recent activity */}
      <div className="px-4 mt-6 mb-4">
        <SectionTitle title="Recent activity" to={app.authenticated ? '/records' : '/login'} />
        <Card className="divide-y divide-gray-50">
          {recent.length === 0 ? (
            <EmptyState
              icon={<History size={22} />}
              title={app.authenticated ? 'No transactions yet' : 'Sign in to see your activity'}
              description={app.authenticated ? 'Every wallet movement appears here with its reference.' : undefined}
            />
          ) : (
            recent.map((entry) => (
              <div key={entry.id} className="px-4 py-3 flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-text">{LEDE_LABELS[entry.kind] ?? entry.kind}</p>
                  <p className="text-[10px] text-muted truncate">{entry.reference}</p>
                </div>
                <span className={`text-xs font-bold ${entry.direction === 'credit' ? 'text-emerald-600' : 'text-text'}`}>
                  {entry.direction === 'credit' ? '+' : '−'}{money(entry.amount_centavos)}
                </span>
              </div>
            ))
          )}
        </Card>

        {app.settings?.notice && (
          <p className="text-[10px] text-muted mt-4 leading-relaxed text-center">{app.settings.notice}</p>
        )}
      </div>
    </div>
  )
}

function SectionTitle({ title, to }: { title: string; to: string }) {
  const nav = useNavigate()
  return (
    <div className="flex items-center justify-between mb-2.5">
      <h3 className="font-extrabold text-text text-sm">{title}</h3>
      <button onClick={() => nav(to)} className="text-[11px] text-brand font-bold flex items-center gap-0.5">
        See all <ChevronRight size={13} />
      </button>
    </div>
  )
}