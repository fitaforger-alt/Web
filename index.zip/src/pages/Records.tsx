import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { History } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api } from '../lib/api'
import { money, dateTimeStr } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState } from '../components/ui/Card'
import { Select } from '../components/ui/Input'
import Button from '../components/ui/Button'

const LEDE_LABELS: Record<string, string> = {
  welcome_reward: 'Welcome reward',
  referral_bonus: 'Referral bonus',
  deposit: 'Deposit',
  withdrawal_hold: 'Withdrawal hold',
  withdrawal_release: 'Withdrawal released',
  withdrawal_payout: 'Withdrawal payout',
  plan_purchase: 'Plan purchase',
  plan_assignment: 'Plan assignment',
  plan_grant: 'Plan granted',
  manual_adjustment: 'Manual adjustment',
  checkin: 'Check-in',
  task_reward: 'Task reward',
  wheel_prize: 'Wheel prize',
  redemption: 'Redemption',
}

const PAGE_SIZE = 25

export default function Records() {
  const app = useApp()
  const [params] = useSearchParams()
  const [wallet, setWallet] = useState(params.get('wallet') ?? 'all')
  const [kind, setKind] = useState('')
  const [page, setPage] = useState(1)
  const [rows, setRows] = useState(app.transactions)
  const [total, setTotal] = useState(app.transactionTotal)

  const query = useMemo(() => {
    const q = new URLSearchParams({ limit: '200' })
    if (wallet !== 'all') q.set('wallet', wallet)
    if (kind) q.set('kind', kind)
    return q.toString()
  }, [wallet, kind])

  const load = async (signal?: AbortSignal) => {
    if (!app.authenticated) return
    const res = await api<{ total: number; rows: typeof rows }>(`/api/transactions?${query}`, { signal })
    setRows(res.rows)
    setTotal(res.total)
  }

  // Refetch whenever the filter changes so the list always matches the query.
  useEffect(() => {
    if (!app.authenticated) return
    const controller = new AbortController()
    void load(controller.signal)
    return () => controller.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, app.authenticated])

  const kinds = [...new Set(app.transactions.map((t) => t.kind))]
  const pageRows = rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)
  const pageCount = Math.max(1, Math.ceil(rows.length / PAGE_SIZE))

  return (
    <div>
      <PageHeader title="Records" subtitle={`${total} entries`} />

      <div className="px-4 py-3 space-y-2">
        <div className="flex gap-2">
          <Select value={wallet} onChange={(e) => { setWallet(e.target.value); setPage(1) }} className="flex-1">
            <option value="all">All wallets</option>
            <option value="recharge">Recharge</option>
            <option value="earnings">Earnings</option>
          </Select>
          <Select value={kind} onChange={(e) => { setKind(e.target.value); setPage(1) }} className="flex-1">
            <option value="">All types</option>
            {kinds.map((k) => <option key={k} value={k}>{LEDE_LABELS[k] ?? k}</option>)}
          </Select>
        </div>
      </div>

      <div className="px-4 py-1 space-y-2 pb-4">
        {rows.length === 0 ? (
          <EmptyState icon={<History size={22} />} title="No transactions available" description="Every wallet movement will appear here with its reference." />
        ) : (
          <>
            {pageRows.map((entry) => (
              <Card key={entry.id} className="p-3.5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-text text-sm">{LEDE_LABELS[entry.kind] ?? entry.kind}</p>
                      <Badge color={entry.wallet === 'points' ? 'violet' : entry.wallet === 'recharge' ? 'blue' : 'green'}>{entry.wallet}</Badge>
                    </div>
                    <p className="text-[10px] text-muted mt-0.5 break-all">{entry.reference}</p>
                    <p className="text-[10px] text-muted">{dateTimeStr(entry.created_at)}</p>
                    {entry.reason && <p className="text-[11px] text-muted mt-1">{entry.reason}</p>}
                  </div>
                  <div className="text-right shrink-0">
                    <p className={`font-extrabold text-sm ${entry.direction === 'credit' ? 'text-emerald-600' : 'text-text'}`}>
                      {entry.direction === 'credit' ? '+' : '−'}{entry.wallet === 'points' ? entry.amount_centavos : money(entry.amount_centavos)}
                    </p>
                    <Badge color={entry.status === 'completed' ? 'green' : entry.status === 'pending' ? 'amber' : 'gray'}>
                      {entry.status}
                    </Badge>
                  </div>
                </div>
                {entry.status === 'pending' && (
                  <p className="text-[10px] text-amber-700 mt-2">Held pending confirmation. This amount is not spendable yet.</p>
                )}
              </Card>
            ))}

            {pageCount > 1 && (
              <div className="flex items-center justify-between pt-2">
                <Button size="sm" variant="secondary" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>Previous</Button>
                <span className="text-[11px] text-muted">Page {page} of {pageCount}</span>
                <Button size="sm" variant="secondary" disabled={page === pageCount} onClick={() => setPage((p) => p + 1)}>Next</Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}