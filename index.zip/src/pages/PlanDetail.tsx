import { useParams } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import { PlanDetailPanel } from './MyPlans'

export default function PlanDetail() {
  const { id } = useParams()
  if (!id) return null

  return (
    <div>
      <PageHeader title="Plan income" />
      <div className="px-4 py-4 pb-4">
        <PlanDetailPanel planId={id} />
      </div>
    </div>
  )
}