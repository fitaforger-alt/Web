import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { KeyRound, LogOut, ShieldCheck } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { relativeDay } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge } from '../components/ui/Card'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'

interface SessionRow {
  id: string
  created_at: string
  last_seen_at: string
  expires_at: string
  ip: string | null
  user_agent: string | null
  revoked_at: string | null
  current: boolean
}

export default function Security() {
  const app = useApp()
  const nav = useNavigate()
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [sessions, setSessions] = useState<SessionRow[]>([])

  const loadSessions = async () => {
    try {
      setSessions(await api<SessionRow[]>('/api/auth/sessions'))
    } catch {
      setSessions([])
    }
  }

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    setError(null)
    if (newPassword.length < 8) { setError('New password must be at least 8 characters.'); return }
    if (!/[A-Za-z]/.test(newPassword) || !/[0-9]/.test(newPassword)) { setError('Use at least one letter and one number.'); return }
    if (newPassword !== confirmPassword) { setError('Passwords do not match.'); return }

    setBusy(true)
    try {
      await app.changePassword(currentPassword, newPassword)
      app.toast('Password updated. Other sessions were signed out.', 'success')
      setCurrentPassword(''); setNewPassword(''); setConfirmPassword('')
      await loadSessions()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not update your password.')
    } finally {
      setBusy(false)
    }
  }

  if (!app.authenticated) return null

  return (
    <div>
      <PageHeader title="Security" />

      <div className="px-4 py-4 space-y-4 pb-4">
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <KeyRound size={16} className="text-brand" />
            <p className="font-bold text-text text-sm">Change password</p>
          </div>
          <form onSubmit={submit} className="space-y-3">
            <Input
              label="Current password"
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              autoComplete="current-password"
            />
            <Input
              label="New password"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              hint="At least 8 characters, including a letter and a number."
              autoComplete="new-password"
            />
            <Input
              label="Confirm new password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              error={error ?? undefined}
              autoComplete="new-password"
            />
            <Button type="submit" block loading={busy}>Update password</Button>
          </form>
        </Card>

        <Card className="p-4">
          <p className="font-bold text-text text-sm mb-1">Active sessions</p>
          <button onClick={loadSessions} className="text-[11px] font-bold text-brand mb-2">Refresh</button>
          {sessions.length === 0 ? (
            <p className="text-xs text-muted">No session history available.</p>
          ) : (
            sessions.map((s) => (
              <div key={s.id} className="py-2 border-b border-gray-50 last:border-0">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-text">
                    {(s.user_agent || 'Unknown device').slice(0, 46)}
                  </span>
                  {s.current ? <Badge color="green">This device</Badge> : s.revoked_at ? <Badge color="gray">Ended</Badge> : <Badge color="amber">Active</Badge>}
                </div>
                <p className="text-[10px] text-muted">
                  {s.ip ?? 'unknown ip'} · started {relativeDay(s.created_at)}
                </p>
              </div>
            ))
          )}
        </Card>

        <Card className="p-4 flex items-start gap-3">
          <ShieldCheck size={18} className="text-brand shrink-0 mt-0.5" />
          <div className="text-[11px] text-muted leading-relaxed space-y-1.5">
            <p className="font-bold text-text text-xs">Keeping your account safe</p>
            <p>DriveVest staff never ask for your password, one-time codes or payout PINs.</p>
            <p>Use a password you do not reuse on other sites, and sign out of devices you no longer use.</p>
            <p>Sessions expire automatically after 12 hours of inactivity.</p>
          </div>
        </Card>

        <Button
          block
          variant="secondary"
          icon={<LogOut size={15} />}
          onClick={() => {
            app.openConfirm({
              title: 'Log out',
              message: 'You will need your username and password to sign back in.',
              confirmLabel: 'Log out',
              onConfirm: async () => { await app.logout(); nav('/', { replace: true }) },
            })
          }}
        >
          Log out of this device
        </Button>
      </div>
    </div>
  )
}