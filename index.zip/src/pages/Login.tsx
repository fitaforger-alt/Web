import { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Lock } from 'lucide-react'
import { useApp } from '../context/AppState'
import { ApiError } from '../lib/api'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'

export default function Login() {
  const app = useApp()
  const nav = useNavigate()
  const location = useLocation()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const from = (location.state as { from?: string } | null)?.from ?? '/'

  useEffect(() => {
    if (app.authenticated) nav(from, { replace: true })
  }, [app.authenticated, from, nav])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    setError('')
    setBusy(true)
    try {
      await app.login(username.trim(), password)
      nav(from, { replace: true })
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not sign in. Try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-brand text-white flex items-center justify-center font-black text-2xl mx-auto">D</div>
          <h1 className="font-extrabold text-text text-xl mt-3">Welcome back</h1>
          <p className="text-xs text-muted mt-1">Sign in to your DriveVest account</p>
        </div>

        <Card className="p-6">
          <form onSubmit={submit} className="space-y-4" noValidate>
            <Input
              label="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              required
            />
            <Input
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              error={error}
              autoComplete="current-password"
              required
            />
            <Button type="submit" block loading={busy} icon={<Lock size={16} />}>Sign in</Button>
          </form>

          <p className="text-xs text-center text-muted mt-4">
            No account?{' '}
            <Link to="/register" className="text-brand font-bold">Register</Link>
          </p>
        </Card>

        <p className="text-[11px] text-muted text-center mt-4">
          DriveVest never asks for your password, one-time codes or payout PINs.
        </p>
      </div>
    </div>
  )
}