import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { LifeBuoy, Send } from 'lucide-react'
import { useApp } from '../context/AppState'
import { api, ApiError } from '../lib/api'
import { relativeDay } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'
import Input, { Select, TextArea } from '../components/ui/Input'
import type { SupportTicket } from '../types'

export default function Help() {
  const app = useApp()
  const nav = useNavigate()
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [category, setCategory] = useState('general')
  const [subject, setSubject] = useState('')
  const [body, setBody] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!app.authenticated) return
    api<SupportTicket[]>('/api/tickets').then(setTickets).catch(() => setTickets([]))
  }, [app.authenticated])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    setError(null)
    setBusy(true)
    try {
      await api('/api/tickets', { method: 'POST', body: { category, subject: subject.trim(), body: body.trim() } })
      app.toast('Ticket submitted. Support will reply in your inbox.', 'success')
      setSubject(''); setBody('')
      setTickets(await api<SupportTicket[]>('/api/tickets'))
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not submit your ticket.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <PageHeader title="Help & support" />

      <div className="px-4 py-4 space-y-4 pb-4">
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <LifeBuoy size={16} className="text-brand" />
            <p className="font-bold text-text text-sm">Contact</p>
          </div>
          <p className="text-sm text-muted">{app.settings?.support_email ?? 'support@drivevest.example'}</p>
          {app.settings?.support_hours && <p className="text-xs text-muted mt-0.5">{app.settings.support_hours}</p>}
          <p className="text-[11px] text-muted mt-2 leading-relaxed">
            DriveVest will never ask for your password, one-time codes or payout PINs.
          </p>
        </Card>

        {!app.authenticated ? (
          <EmptyState
            title="Sign in to open a ticket"
            description="Support tickets are tied to your account so we can check its ledger."
            action={<Button size="sm" onClick={() => nav('/login', { state: { from: '/help' } })}>Sign in</Button>}
          />
        ) : (
          <Card className="p-4">
            <p className="font-bold text-text text-sm mb-3">Open a support ticket</p>
            <form onSubmit={submit} className="space-y-3">
              <Select label="Category" value={category} onChange={(e) => setCategory(e.target.value)}>
                <option value="general">General</option>
                <option value="deposit">Deposit</option>
                <option value="withdrawal">Withdrawal</option>
                <option value="plan">Plan</option>
                <option value="account">Account</option>
              </Select>
              <Input label="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Short summary" maxLength={120} />
              <TextArea label="Details" value={body} onChange={(e) => setBody(e.target.value)} placeholder="Tell us what happened, including any reference numbers." />
              {error && <p className="text-xs text-red-500">{error}</p>}
              <Button type="submit" block loading={busy} icon={<Send size={15} />}>Submit ticket</Button>
            </form>
          </Card>
        )}

        {app.authenticated && (
          <Card className="p-4">
            <p className="font-bold text-text text-sm mb-2">Your tickets</p>
            {tickets.length === 0 ? (
              <p className="text-xs text-muted py-3 text-center">No support tickets yet.</p>
            ) : (
              tickets.map((t) => (
                <div key={t.id} className="py-2.5 border-b border-gray-50 last:border-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-semibold text-text truncate">{t.subject}</p>
                    <Badge color={t.status === 'resolved' || t.status === 'closed' ? 'green' : t.status === 'open' ? 'amber' : 'blue'}>
                      {t.status}
                    </Badge>
                  </div>
                  <p className="text-[10px] text-muted mt-0.5">{t.reference} · {relativeDay(t.updated_at)}</p>
                </div>
              ))
            )}
          </Card>
        )}

        <Card className="p-4">
          <p className="font-bold text-text text-sm mb-2">Common questions</p>
          <ul className="text-xs text-muted space-y-1.5 list-disc pl-4 leading-relaxed">
            <li>A deposit stays pending until the payment provider confirms it.</li>
            <li>A withdrawal holds your funds immediately and completes only after payout confirmation.</li>
            <li>Projected plan rewards are estimates, not guaranteed returns.</li>
            <li>Points are promotional credits and are not withdrawable cash.</li>
          </ul>
          <button onClick={() => nav('/faq')} className="text-[11px] font-bold text-brand mt-3">See all FAQs →</button>
        </Card>
      </div>
    </div>
  )
}