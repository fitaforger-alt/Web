import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Newspaper } from 'lucide-react'
import { useApp } from '../context/AppState'
import { dateStr } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { Badge, EmptyState, Skeleton } from '../components/ui/Card'

export default function News() {
  const nav = useNavigate()
  const app = useApp()

  useEffect(() => {
    if (app.news.length === 0) void app.loadNews()
  }, [app.news.length, app.loadNews])

  return (
    <div>
      <PageHeader title="News" subtitle="Published by DriveVest" back={false} />

      <div className="px-4 py-4 space-y-3 pb-4">
        {app.news.length === 0 ? (
          <>
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </>
        ) : (
          app.news.map((n) => (
            <Card key={n.id} className="p-3 flex gap-3 cursor-pointer hover:shadow-md transition" onClick={() => nav(`/news/${n.id}`)}>
              {n.image_url && <img src={n.image_url} alt="" className="w-20 h-20 rounded-xl object-cover flex-shrink-0" loading="lazy" />}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-1">
                  <Badge color="gray">{n.category}</Badge>
                  {n.is_new && <Badge color="red">New</Badge>}
                </div>
                <p className="font-semibold text-sm text-text line-clamp-2">{n.title}</p>
                <p className="text-xs text-muted line-clamp-2 mt-0.5">{n.summary}</p>
                <p className="text-[10px] text-muted mt-1">{dateStr(n.published_at)}</p>
              </div>
            </Card>
          ))
        )}

        {app.news.length === 0 && app.loading === false && (
          <EmptyState icon={<Newspaper size={22} />} title="No news yet" description="Check back for platform updates." />
        )}
      </div>
    </div>
  )
}