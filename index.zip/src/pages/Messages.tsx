import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Inbox } from 'lucide-react'
import { useApp } from '../context/AppState'
import { relativeDay } from '../utils/format'
import PageHeader from '../components/layout/PageHeader'
import Card, { EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'

export default function Messages() {
  const app = useApp()
  const nav = useNavigate()

  useEffect(() => {
    if (app.authenticated) void app.loadNotifications()
  }, [app.authenticated, app.loadNotifications])

  return (
    <div>
      <PageHeader title="Inbox" subtitle={app.unread > 0 ? `${app.unread} unread` : undefined} />

      <div className="px-4 py-4 pb-4">
        {!app.authenticated ? (
          <EmptyState
            icon={<Inbox size={22} />}
            title="Sign in to see messages"
            description="DriveVest messages about deposits, withdrawals and plans appear here."
            action={<Button size="sm" onClick={() => nav('/login', { state: { from: '/messages' } })}>Sign in</Button>}
          />
        ) : app.notifications.length === 0 ? (
          <EmptyState icon={<Inbox size={22} />} title="No messages" description="Updates from DriveVest will appear here." />
        ) : (
          <div className="space-y-2">
            {app.notifications.map((n) => (
              <Card
                key={n.id}
                className={`p-3.5 cursor-pointer ${n.read_at ? '' : 'bg-red-50/30 border-red-100'}`}
                onClick={() => {
                  void app.markNotificationRead(n.id)
                  if (n.action_url) nav(n.action_url)
                }}
              >
                <div className="flex items-center gap-2">
                  {!n.read_at && <span className="w-2 h-2 rounded-full bg-brand shrink-0" />}
                  <p className="font-bold text-text text-sm flex-1">{n.title}</p>
                  <span className="text-[10px] text-muted">{relativeDay(n.created_at)}</span>
                </div>
                <p className="text-xs text-muted mt-1 leading-relaxed">{n.body}</p>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}