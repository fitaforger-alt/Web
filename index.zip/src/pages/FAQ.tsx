import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import PageHeader from '../components/layout/PageHeader'
import Card from '../components/ui/Card'

const FAQS = [
  {
    q: 'How do I register?',
    a: 'A username, a password and — optionally — a referral code. There is no email or phone step. Every new account receives one ₱50.00 welcome reward, credited to your wallet immediately.',
  },
  {
    q: 'Do I need an email address?',
    a: 'No. DriveVest identifies accounts by username. Signing in uses your username and password only.',
  },
  {
    q: 'Where did my ₱50 welcome reward go?',
    a: 'It was credited to your earnings wallet and appears in your records as "Welcome reward" with its own reference. It is issued exactly once per account — refreshing, signing in again or revisiting the wallet will not issue another.',
  },
  {
    q: 'Why has my deposit not been credited?',
    a: 'A deposit is only credited after the payment provider confirms the payment, either through a signed provider callback or a reconciliation check. Until then the request stays pending and no money has moved.',
  },
  {
    q: 'Can I withdraw my balance?',
    a: 'You can request a withdrawal up to your available balance. The amount is held immediately so it cannot be spent twice, then a DriveVest operator reviews it. The request only completes once a payout reference is recorded.',
  },
  {
    q: 'Are the plan rewards guaranteed?',
    a: 'No. The daily figure on a product is a projection based on platform activity, not a promise of return. The exact terms you accepted are stored with your plan and shown on the plan detail page.',
  },
  {
    q: 'What is the difference between my wallets?',
    a: 'Recharge wallet holds money you have paid in and is used to activate plans. Earnings wallet holds rewards and plan income and is what you can withdraw. Points are promotional credits and are not cash.',
  },
  {
    q: 'What happens if a plan I bought changes terms?',
    a: 'Your plan keeps the terms you accepted. New terms only apply to plans started after the change, and each change is stored as a new version so history is never rewritten.',
  },
  {
    q: 'Can I close my account?',
    a: 'Open a support ticket from the Help page. An operator will confirm the request and handle it, including settling any pending withdrawals first.',
  },
  {
    q: 'Someone is asking for my password. Is that DriveVest?',
    a: 'No. DriveVest never asks for your password, one-time codes or payout PINs. Report it through the Help page immediately.',
  },
]

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0)

  return (
    <div>
      <PageHeader title="Frequently asked" />
      <div className="px-4 py-4 space-y-2 pb-4">
        {FAQS.map((f, i) => (
          <Card key={i} className="p-4 cursor-pointer" onClick={() => setOpen(open === i ? null : i)}>
            <div className="flex items-center justify-between gap-3">
              <p className="font-semibold text-text text-sm">{f.q}</p>
              <ChevronDown size={16} className={`text-muted shrink-0 transition ${open === i ? 'rotate-180' : ''}`} />
            </div>
            {open === i && <p className="text-xs text-muted mt-2 leading-relaxed">{f.a}</p>}
          </Card>
        ))}
      </div>
    </div>
  )
}