import PageHeader from '../components/layout/PageHeader'
import Card from '../components/ui/Card'
import { useApp } from '../context/AppState'

export default function About() {
  const app = useApp()
  const settings = app.settings

  return (
    <div>
      <PageHeader title="About DriveVest" />

      <div className="px-4 py-4 space-y-3 pb-4">
        <Card className="p-4">
          <h3 className="font-bold text-text mb-2">What DriveVest is</h3>
          <p className="text-sm text-muted leading-relaxed">
            DriveVest is a rewards and product-plan platform. You keep a wallet, activate published product plans, and
            track every movement of money through a permanent ledger.
          </p>
        </Card>

        <Card className="p-4">
          <h3 className="font-bold text-text mb-2">How your balance works</h3>
          <p className="text-sm text-muted leading-relaxed">
            Every peso that enters or leaves your wallet is written as a ledger entry with a unique reference, the
            resulting balance, and the reason for the movement. Completed entries are never edited or deleted — a
            correction is posted as a linked reversal so the history stays intact.
          </p>
        </Card>

        <Card className="p-4">
          <h3 className="font-bold text-text mb-2">About projected rewards</h3>
          <p className="text-sm text-muted leading-relaxed">
            The daily figure shown on a product is a projection of platform activity, not a guaranteed return and not a
            risk-free investment product. Actual earnings can be lower. The terms shown on each product are the terms
            that apply.
          </p>
        </Card>

        <Card className="p-4">
          <h3 className="font-bold text-text mb-2">Deposits and withdrawals</h3>
          <p className="text-sm text-muted leading-relaxed">
            Deposits are credited only after a payment provider confirms the payment. Withdrawal requests hold your
            funds immediately, are reviewed by an operator, and complete only once the payout is confirmed with a
            reference.
          </p>
        </Card>

        <Card className="p-4">
          <h3 className="font-bold text-text mb-2">Support</h3>
          <p className="text-sm text-muted leading-relaxed">
            {settings?.support_email ?? 'support@drivevest.example'}
            {settings?.support_hours ? ` · ${settings.support_hours}` : ''}
          </p>
          <p className="text-[11px] text-muted mt-2">
            Terms version {settings?.terms_version ?? '1.0'}. DriveVest does not represent any regulatory registration,
            licence or guarantee.
          </p>
        </Card>
      </div>
    </div>
  )
}