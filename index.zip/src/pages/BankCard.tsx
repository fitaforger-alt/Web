import { useState } from 'react'
import { Trash2, CreditCard } from 'lucide-react'
import { useApp } from '../context/AppState'
import { ApiError } from '../lib/api'
import PageHeader from '../components/layout/PageHeader'
import Card, { EmptyState } from '../components/ui/Card'
import Button from '../components/ui/Button'
import Input, { Select } from '../components/ui/Input'

export default function BankCard() {
  const app = useApp()
  const [holder, setHolder] = useState('')
  const [provider, setProvider] = useState<'GCash' | 'Maya' | 'Bank'>('GCash')
  const [account, setAccount] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    setError(null)
    const digits = account.replace(/\D/g, '')
    if (holder.trim().length < 2) { setError('Enter the account holder name as it appears on the account.'); return }
    if (!/^\d{10,16}$/.test(digits)) { setError('Enter a valid account number (10 to 16 digits).'); return }

    setBusy(true)
    try {
      await app.saveDestination({ holderName: holder.trim(), provider, accountNumber: digits })
      app.toast('Payout destination saved.', 'success')
      setHolder('')
      setAccount('')
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not save that destination.')
    } finally {
      setBusy(false)
    }
  }

  const remove = (id: string, label: string) => {
    app.openConfirm({
      title: 'Remove destination',
      message: `Remove ${label}? Existing withdrawal requests keep their recorded destination.`,
      confirmLabel: 'Remove',
      tone: 'danger',
      onConfirm: async () => {
        try {
          await app.removeDestination(id)
          app.toast('Destination removed.', 'info')
        } catch (err) {
          app.toast(err instanceof ApiError ? err.message : 'Could not remove that destination.', 'error')
        }
      },
    })
  }

  return (
    <div>
      <PageHeader title="Payout destinations" />

      <div className="px-4 py-4 space-y-4 pb-4">
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <CreditCard size={16} className="text-brand" />
            <p className="font-bold text-text text-sm">Add a destination</p>
          </div>
          <form onSubmit={submit} className="space-y-3">
            <Input
              label="Account holder name"
              value={holder}
              onChange={(e) => setHolder(e.target.value)}
              placeholder="Name on the account"
              maxLength={80}
            />
            <Select label="Provider" value={provider} onChange={(e) => setProvider(e.target.value as typeof provider)}>
              <option>GCash</option>
              <option>Maya</option>
              <option>Bank</option>
            </Select>
            <Input
              label="Account number"
              inputMode="numeric"
              value={account}
              onChange={(e) => setAccount(e.target.value.replace(/\D/g, '').slice(0, 16))}
              placeholder="10 to 16 digits"
            />
            {error && <p className="text-xs text-red-500">{error}</p>}
            <Button type="submit" block loading={busy}>Save destination</Button>
          </form>
          <p className="text-[11px] text-muted mt-3 leading-relaxed">
            DriveVest stores the destination so payouts can be sent. Your account number is never shown in full — in the
            admin panel it appears masked.
          </p>
        </Card>

        <div>
          <p className="font-bold text-text text-sm mb-2 px-1">Saved destinations</p>
          {app.destinations.length === 0 ? (
            <EmptyState title="No saved destinations" description="Add one to request a withdrawal." />
          ) : (
            app.destinations.map((d) => (
              <Card key={d.id} className="p-4 flex items-center justify-between mb-2">
                <div className="min-w-0">
                  <p className="font-semibold text-text text-sm truncate">{d.holder_name}</p>
                  <p className="text-xs text-muted">{d.masked}</p>
                </div>
                <button
                  onClick={() => remove(d.id, d.masked)}
                  className="p-2.5 rounded-full hover:bg-red-50 text-red-500 transition"
                  aria-label={`Remove ${d.masked}`}
                >
                  <Trash2 size={16} />
                </button>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}