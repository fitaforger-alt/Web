import { useState } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { Loader2, ShieldCheck } from 'lucide-react'
import { useAdmin } from './AdminContext'
import { ApiError } from '../lib/api'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'

export default function AdminLogin() {
  const { login, authenticated, ready } = useAdmin()
  const nav = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  if (ready && authenticated) return <Navigate to="/admin" replace />

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    setError('')
    setBusy(true)
    try {
      await login(username.trim(), password)
      nav('/admin', { replace: true })
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not sign in.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#171D2B] grid place-items-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-brand text-white flex items-center justify-center font-black text-2xl mx-auto">D</div>
          <h1 className="font-extrabold text-white text-xl mt-3">DriveVest Admin</h1>
          <p className="text-xs text-white/50 mt-1">Staff access only</p>
        </div>

        <form onSubmit={submit} className="bg-white rounded-2xl p-6 space-y-4">
          <Input
            label="Administrator username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
            required
          />
          <Input
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            error={error}
            autoComplete="current-password"
            required
          />
          <Button type="submit" block loading={busy} icon={<ShieldCheck size={16} />}>Sign in</Button>
          <p className="text-[11px] text-muted leading-relaxed">
            Administrator accounts are provisioned on the server. There is no public sign-up for staff.
          </p>
        </form>

        <Link to="/" className="block text-center text-[11px] text-white/50 mt-5 hover:text-white/80">
          ← Back to the customer site
        </Link>
      </div>
    </div>
  )
}

export function AdminLoading() {
  return (
    <div className="grid place-items-center py-20">
      <Loader2 className="animate-spin text-brand" size={24} />
    </div>
  )
}