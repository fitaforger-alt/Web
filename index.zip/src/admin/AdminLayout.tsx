import { useState } from 'react'
import { Link, Outlet, useLocation } from 'react-router-dom'
import {
  AlertTriangle, ArrowDownToLine, ArrowUpFromLine, BarChart3, Bell, CalendarClock, CheckSquare, ClipboardList,
  Gift, LayoutDashboard, LifeBuoy, Loader2, LogOut, Menu, Package, Receipt, ScrollText,
  Settings, Shield, Users, Users2, Wallet,
} from 'lucide-react'
import { useAdmin } from './AdminContext'

const NAV = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true, permission: 'users.read' },
  { to: '/admin/users', label: 'Users', icon: Users, permission: 'users.read' },
  { to: '/admin/deposits', label: 'Deposits', icon: ArrowDownToLine, permission: 'deposits.review' },
  { to: '/admin/withdrawals', label: 'Withdrawals', icon: ArrowUpFromLine, permission: 'withdrawals.review' },
  { to: '/admin/transactions', label: 'Transactions', icon: Receipt, permission: 'ledger.read' },
  { to: '/admin/adjustments', label: 'Wallet adjustments', icon: Wallet, permission: 'ledger.adjust' },
  { to: '/admin/approvals', label: 'Approvals', icon: CheckSquare, permission: 'ledger.adjust' },
  { to: '/admin/plans', label: 'Products', icon: Package, permission: 'plans.manage' },
  { to: '/admin/plan-assignments', label: 'Plan assignments', icon: ClipboardList, permission: 'plans.manage' },
  { to: '/admin/plan-settlements', label: 'Plan settlements', icon: CalendarClock, permission: 'plans.manage' },
  { to: '/admin/rewards', label: 'Rewards & tasks', icon: Gift, permission: 'rewards.manage' },
  { to: '/admin/referrals', label: 'Referrals', icon: Users2, permission: 'ledger.read' },
  { to: '/admin/notifications', label: 'Notifications', icon: Bell, permission: 'support.manage' },
  { to: '/admin/support', label: 'Support tickets', icon: LifeBuoy, permission: 'support.manage' },
  { to: '/admin/reports', label: 'Reports', icon: BarChart3, permission: 'ledger.read' },
  { to: '/admin/audit', label: 'Audit logs', icon: ScrollText, permission: 'audit.read' },
  { to: '/admin/admins', label: 'Administrators', icon: Shield, permission: 'admin.manage' },
  { to: '/admin/settings', label: 'Settings', icon: Settings, permission: 'users.read' },
]

export default function AdminLayout() {
  const { admin, authenticated, ready, logout, can, overview } = useAdmin()
  const location = useLocation()
  const [open, setOpen] = useState(false)

  if (!ready) {
    return (
      <div className="min-h-screen grid place-items-center bg-bg">
        <Loader2 className="animate-spin text-brand" size={28} />
      </div>
    )
  }

  if (!authenticated || !admin) {
    window.location.replace('/admin/login')
    return null
  }

  const items = NAV.filter((item) => can(item.permission))
  const pendingCount =
    (overview?.cards.pending_deposits ?? 0) + (overview?.cards.pending_withdrawals ?? 0)

  const sidebar = (
    <div className="flex flex-col h-full">
      <div className="px-5 py-4 border-b border-white/10">
        <div className="font-extrabold text-lg text-white">DriveVest</div>
        <div className="text-[11px] text-white/50">Administrator console</div>
      </div>
      <nav className="flex-1 overflow-y-auto py-3">
        {items.map((item) => {
          const active = item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setOpen(false)}
              className={`flex items-center gap-3 px-5 py-2.5 text-sm transition ${
                active ? 'bg-brand text-white font-semibold' : 'text-white/75 hover:bg-white/5'
              }`}
            >
              <item.icon size={16} /> {item.label}
              {item.to === '/admin' && pendingCount > 0 && (
                <span className="ml-auto text-[10px] bg-white/20 rounded-full px-1.5 py-0.5">{pendingCount}</span>
              )}
            </Link>
          )
        })}
      </nav>
      <div className="px-5 py-4 border-t border-white/10">
        <div className="text-xs text-white/80 truncate">{admin.display_name}</div>
        <div className="text-[10px] text-white/50">{admin.role.replace('_', ' ')}</div>
        <button
          onClick={async () => { await logout(); window.location.replace('/admin/login') }}
          className="mt-2 text-xs text-red-300 flex items-center gap-1"
        >
          <LogOut size={12} /> Sign out
        </button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-bg flex">
      <aside className="hidden md:flex w-64 shrink-0 bg-[#171D2B] h-screen sticky top-0">{sidebar}</aside>

      {open && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div className="w-64 bg-[#171D2B] h-full">{sidebar}</div>
          <div className="flex-1 bg-black/50" onClick={() => setOpen(false)} />
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3 min-w-0">
            <button onClick={() => setOpen(true)} className="md:hidden p-2 -ml-2" aria-label="Open navigation">
              <Menu size={20} className="text-text" />
            </button>
            <div className="min-w-0">
              <p className="font-bold text-text text-sm truncate">DriveVest Admin</p>
              <p className="text-[10px] text-muted truncate">
                {admin.display_name} · {admin.role.replace('_', ' ')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {pendingCount > 0 && (
              <span className="hidden sm:flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 border border-amber-200 rounded-full px-2.5 py-1">
                <AlertTriangle size={12} /> {pendingCount} pending
              </span>
            )}
            <Link to="/" className="text-[11px] font-bold text-brand px-2 py-1 hover:bg-red-50 rounded">Customer site</Link>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

export function PageHeading({ title, description, actions }: { title: string; description?: string; actions?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
      <div>
        <h1 className="text-xl font-extrabold text-text">{title}</h1>
        {description && <p className="text-xs text-muted mt-0.5">{description}</p>}
      </div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </div>
  )
}

export function PermissionNotice({ permission }: { permission: string }) {
  const { can } = useAdmin()
  if (can(permission)) return null
  return (
    <div className="flex items-start gap-2 p-4 rounded-xl bg-amber-50 border border-amber-200 mb-4">
      <AlertTriangle size={16} className="text-amber-600 shrink-0 mt-0.5" />
      <p className="text-xs text-amber-800">
        Your role does not include <code className="font-mono">{permission}</code>. The server refuses this action
        regardless of what the interface shows.
      </p>
    </div>
  )
}