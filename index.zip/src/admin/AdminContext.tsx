import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { ApiError, api, setCsrfToken } from '../lib/api'
import type {
  AdminCustomer, AdminOverview, AdminUser, ApprovalRequest, AuditRow, Deposit, LedgerEntry,
  PaymentMethod, PayoutDestination, Product, RedemptionCode, SupportTicket, UserPlan, Wallet, Withdrawal,
} from '../types'

interface AdminState {
  ready: boolean
  authenticated: boolean
  admin: AdminUser | null
  overview: AdminOverview | null
  customers: AdminCustomer[]
  customersTotal: number
  deposits: Deposit[]
  withdrawals: Withdrawal[]
  ledger: LedgerEntry[]
  plans: Product[]
  userPlans: UserPlan[]
  approvals: ApprovalRequest[]
  audit: AuditRow[]
  admins: AdminUser[]
  roles: { name: string; description: string; permissions: string[] }[]
  welcomeRewards: {
    total: number
    rows: (WelcomeRewardRow & { username: string; transaction_reference: string })[]
    summary: { issued: number; value_centavos: number; per_account_centavos: number }
  } | null
  tasks: AdminTask[]
  codes: RedemptionCode[]
  tickets: SupportTicket[]
  referrals: { total: number; bonus_points_centavos: number; rows: ReferralRow[] }
  notifications: AdminNotification[]
  settings: Record<string, string> | null
  paymentProviders: PaymentMethod[]
  loading: boolean
  error: string | null
}

interface WelcomeRewardRow {
  user_id: string
  amount_centavos: number
  issued_at: string
  status: string
  ledger_status?: string
}

interface AdminTask {
  id: string
  title: string
  description: string | null
  reward_points: number
  recurring: string
  active: number
  claims: number
  action_url: string | null
}

interface ReferralRow {
  id: string
  referrer_username: string
  referred_username: string
  code_used: string
  reward_centavos: number
  status: string
  created_at: string
}

interface AdminNotification {
  id: string
  title: string
  body: string
  severity: string
  audience: string
  user_id: string | null
  username: string | null
  created_at: string
}

interface AdminActions {
  login: (username: string, password: string) => Promise<void>
  logout: () => Promise<void>
  can: (permission: string) => boolean
  refresh: () => Promise<void>
  loadUsers: (query?: { q?: string; status?: string; offset?: number }) => Promise<void>
  userDetail: (id: string) => Promise<any>
  loadDeposits: (status?: string) => Promise<void>
  reviewDeposit: (id: string, action: 'verify' | 'reject' | 'under_review', reason?: string) => Promise<void>
  loadWithdrawals: (status?: string) => Promise<void>
  decideWithdrawal: (id: string, payload: Record<string, unknown>) => Promise<void>
  loadLedger: (query?: Record<string, string>) => Promise<void>
  postAdjustment: (payload: Record<string, unknown>) => Promise<{ status?: string; message?: string }>
  previewAdjustment: (params: Record<string, string>) => Promise<any>
  decideApproval: (id: string, decision: 'approve' | 'reject', note?: string) => Promise<void>
  setUserStatus: (userId: string, status: string, reason: string) => Promise<void>
  addUserNote: (userId: string, body: string) => Promise<void>
  loadPlans: () => Promise<void>
  createPlan: (payload: Record<string, unknown>) => Promise<void>
  updatePlan: (id: string, payload: Record<string, unknown>) => Promise<void>
  assignPlan: (payload: Record<string, unknown>) => Promise<void>
  setPlanAssignmentStatus: (id: string, status: string, reason: string) => Promise<void>
  loadRewards: () => Promise<void>
  saveTask: (payload: Record<string, unknown>, id?: string) => Promise<void>
  saveCode: (payload: Record<string, unknown>, code?: string) => Promise<void>
  loadReferrals: () => Promise<void>
  loadTickets: (status?: string) => Promise<void>
  loadNotifications: () => Promise<void>
  replyTicket: (id: string, body: string, status?: string) => Promise<void>
  sendNotification: (payload: Record<string, unknown>) => Promise<void>
  loadAudit: (query?: Record<string, string>) => Promise<void>
  loadAdmins: () => Promise<void>
  createAdmin: (payload: Record<string, unknown>) => Promise<void>
  updateAdmin: (id: string, payload: Record<string, unknown>) => Promise<void>
  loadSettings: () => Promise<void>
  saveSettings: (changes: Record<string, string>, reason: string) => Promise<void>
  report: (kind: string, from?: string, to?: string) => Promise<{ rows: Record<string, unknown>[]; count: number }>
}

const AdminCtx = createContext<(AdminState & AdminActions) | null>(null)

export function AdminProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false)
  const [authenticated, setAuthenticated] = useState(false)
  const [admin, setAdmin] = useState<AdminUser | null>(null)
  const [overview, setOverview] = useState<AdminOverview | null>(null)
  const [customers, setCustomers] = useState<AdminCustomer[]>([])
  const [customersTotal, setCustomersTotal] = useState(0)
  const [deposits, setDeposits] = useState<Deposit[]>([])
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [ledger, setLedger] = useState<LedgerEntry[]>([])
  const [plans, setPlans] = useState<Product[]>([])
  const [userPlans, setUserPlans] = useState<UserPlan[]>([])
  const [approvals, setApprovals] = useState<ApprovalRequest[]>([])
  const [audit, setAudit] = useState<AuditRow[]>([])
  const [admins, setAdmins] = useState<AdminUser[]>([])
  const [roles, setRoles] = useState<AdminState['roles']>([])
  const [welcomeRewards, setWelcomeRewards] = useState<AdminState['welcomeRewards']>(null)
  const [tasks, setTasks] = useState<AdminTask[]>([])
  const [codes, setCodes] = useState<RedemptionCode[]>([])
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [referrals, setReferrals] = useState<AdminState['referrals']>({ total: 0, bonus_points_centavos: 0, rows: [] })
  const [notifications, setNotifications] = useState<AdminNotification[]>([])
  const [settings, setSettings] = useState<Record<string, string> | null>(null)
  const [paymentProviders, setPaymentProviders] = useState<PaymentMethod[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const clear = useCallback(() => {
    setCsrfToken(null)
    setAuthenticated(false)
    setAdmin(null)
    setOverview(null)
    setCustomers([])
    setDeposits([])
    setWithdrawals([])
    setLedger([])
    setApprovals([])
    setWelcomeRewards(null)
  }, [])

  const login = useCallback(async (username: string, password: string) => {
    const res = await api<{ admin: AdminUser; csrfToken: string }>('/api/admin/login', {
      method: 'POST', body: { username, password },
    })
    setCsrfToken(res.csrfToken)
    setAdmin(res.admin)
    setAuthenticated(true)
  }, [])

  const logout = useCallback(async () => {
    try {
      await api('/api/admin/logout', { method: 'POST', body: {} })
    } finally {
      clear()
    }
  }, [clear])

  const can = useCallback((permission: string) => {
    if (!admin) return false
    if (admin.role === 'SUPER_ADMIN') return true
    return admin.permissions.includes(permission)
  }, [admin])

  const guard = useCallback(async <T,>(fn: () => Promise<T>): Promise<T> => {
    setLoading(true)
    setError(null)
    try {
      return await fn()
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) clear()
      const message = err instanceof Error ? err.message : 'That request failed.'
      setError(message)
      throw err
    } finally {
      setLoading(false)
    }
  }, [clear])

  const refresh = useCallback(async () => {
    if (!authenticated) return
    await guard(async () => {
      const [overviewRes, usersRes, depositsRes, withdrawalsRes, ledgerRes, plansRes, assignmentsRes, approvalsRes] = await Promise.all([
        api<AdminOverview>('/api/admin/overview'),
        api<{ rows: AdminCustomer[]; total: number }>('/api/admin/users?limit=100'),
        api<{ rows: Deposit[] }>('/api/admin/deposits?limit=100'),
        api<{ rows: Withdrawal[] }>('/api/admin/withdrawals?limit=100'),
        api<{ rows: LedgerEntry[] }>('/api/admin/transactions?limit=100'),
        api<Product[]>('/api/admin/plans'),
        api<{ rows: UserPlan[] }>('/api/admin/plan-assignments?limit=100'),
        api<{ rows: ApprovalRequest[] }>('/api/admin/approvals?status=pending'),
      ])
      setOverview(overviewRes)
      setCustomers(usersRes.rows)
      setCustomersTotal(usersRes.total)
      setDeposits(depositsRes.rows)
      setWithdrawals(withdrawalsRes.rows)
      setLedger(ledgerRes.rows)
      setPlans(plansRes)
      setUserPlans(assignmentsRes.rows)
      setApprovals(approvalsRes.rows)
      setPaymentProviders(overviewRes.payment_providers ?? [])
    })
  }, [authenticated, guard])

  const loadUsers = useCallback(async (query: { q?: string; status?: string; offset?: number } = {}) => {
    await guard(async () => {
      const params = new URLSearchParams({ limit: '50' })
      if (query.q) params.set('q', query.q)
      if (query.status) params.set('status', query.status)
      if (query.offset) params.set('offset', String(query.offset))
      const res = await api<{ rows: AdminCustomer[]; total: number }>(`/api/admin/users?${params}`)
      setCustomers(res.rows)
      setCustomersTotal(res.total)
    })
  }, [guard])

  const userDetail = useCallback(async (id: string) => guard(() => api(`/api/admin/users/${id}`)), [guard])

  const loadDeposits = useCallback(async (status?: string) => {
    await guard(async () => {
      const res = await api<{ rows: Deposit[] }>(`/api/admin/deposits?limit=100${status ? `&status=${status}` : ''}`)
      setDeposits(res.rows)
    })
  }, [guard])

  const reviewDeposit = useCallback(async (id: string, action: 'verify' | 'reject' | 'under_review', reason?: string) => {
    await guard(() => api(`/api/admin/deposits/${id}/review`, { method: 'POST', body: { action, reason } }))
  }, [guard])

  const loadWithdrawals = useCallback(async (status?: string) => {
    await guard(async () => {
      const res = await api<{ rows: Withdrawal[] }>(`/api/admin/withdrawals?limit=100${status ? `&status=${status}` : ''}`)
      setWithdrawals(res.rows)
    })
  }, [guard])

  const decideWithdrawal = useCallback(async (id: string, payload: Record<string, unknown>) => {
    await guard(() => api(`/api/admin/withdrawals/${id}/decision`, { method: 'POST', body: payload }))
  }, [guard])

  const loadLedger = useCallback(async (query: Record<string, string> = {}) => {
    await guard(async () => {
      const params = new URLSearchParams({ limit: '200' })
      for (const [k, v] of Object.entries(query)) if (v) params.set(k, v)
      const res = await api<{ rows: LedgerEntry[] }>(`/api/admin/transactions?${params}`)
      setLedger(res.rows)
    })
  }, [guard])

  const postAdjustment = useCallback(async (payload: Record<string, unknown>) => {
    return guard(async () => api<{ status?: string; message?: string }>('/api/admin/adjustments', { method: 'POST', body: payload }))
  }, [guard])

  const previewAdjustment = useCallback(async (params: Record<string, string>) => {
    const search = new URLSearchParams(params)
    return api(`/api/admin/adjustments/preview?${search}`)
  }, [])

  const decideApproval = useCallback(async (id: string, decision: 'approve' | 'reject', note?: string) => {
    await guard(() => api(`/api/admin/approvals/${id}/decision`, { method: 'POST', body: { decision, note } }))
  }, [guard])

  const setUserStatus = useCallback(async (userId: string, status: string, reason: string) => {
    await guard(() => api(`/api/admin/users/${userId}/status`, { method: 'POST', body: { status, reason } }))
  }, [guard])

  const addUserNote = useCallback(async (userId: string, body: string) => {
    await guard(() => api(`/api/admin/users/${userId}/notes`, { method: 'POST', body: { body } }))
  }, [guard])

  const loadPlans = useCallback(async () => {
    await guard(async () => setPlans(await api<Product[]>('/api/admin/plans')))
  }, [guard])

  const createPlan = useCallback(async (payload: Record<string, unknown>) => {
    await guard(() => api('/api/admin/plans', { method: 'POST', body: payload }))
  }, [guard])

  const updatePlan = useCallback(async (id: string, payload: Record<string, unknown>) => {
    await guard(() => api(`/api/admin/plans/${id}`, { method: 'PATCH', body: payload }))
  }, [guard])

  const assignPlan = useCallback(async (payload: Record<string, unknown>) => {
    await guard(() => api('/api/admin/plan-assignments', { method: 'POST', body: payload }))
  }, [guard])

  const setPlanAssignmentStatus = useCallback(async (id: string, status: string, reason: string) => {
    await guard(() => api(`/api/admin/plan-assignments/${id}/status`, { method: 'POST', body: { status, reason } }))
  }, [guard])

  const loadRewards = useCallback(async () => {
    await guard(async () => {
      const [welcomeRes, tasksRes, codesRes] = await Promise.all([
        api<NonNullable<AdminState['welcomeRewards']>>('/api/admin/welcome-rewards?limit=100'),
        api<AdminTask[]>('/api/admin/rewards/tasks'),
        api<RedemptionCode[]>('/api/admin/rewards/codes'),
      ])
      setWelcomeRewards(welcomeRes)
      setTasks(tasksRes)
      setCodes(codesRes)
    })
  }, [guard])

  const saveTask = useCallback(async (payload: Record<string, unknown>, id?: string) => {
    await guard(() => (id ? api(`/api/admin/rewards/tasks/${id}`, { method: 'PATCH', body: payload }) : api('/api/admin/rewards/tasks', { method: 'POST', body: payload })))
  }, [guard])

  const saveCode = useCallback(async (payload: Record<string, unknown>, code?: string) => {
    await guard(() => (code ? api(`/api/admin/rewards/codes/${code}`, { method: 'PATCH', body: payload }) : api('/api/admin/rewards/codes', { method: 'POST', body: payload })))
  }, [guard])

  const loadReferrals = useCallback(async () => {
    await guard(async () => {
      const res = await api<{ total: number; bonus_points_centavos: number; rows: ReferralRow[] }>('/api/admin/referrals')
      setReferrals({ total: res.total, bonus_points_centavos: res.bonus_points_centavos, rows: res.rows })
    })
  }, [guard])

  const loadTickets = useCallback(async (status?: string) => {
    await guard(async () => {
      const res = await api<SupportTicket[]>(`/api/admin/tickets${status ? `?status=${status}` : ''}`)
      setTickets(res)
    })
  }, [guard])

  const loadNotifications = useCallback(async () => {
    await guard(async () => {
      const res = await api<AdminNotification[]>('/api/admin/notifications')
      setNotifications(res)
    })
  }, [guard])

  const replyTicket = useCallback(async (id: string, body: string, status?: string) => {
    await guard(() => api(`/api/admin/tickets/${id}/reply`, { method: 'POST', body: { body, status } }))
  }, [guard])

  const sendNotification = useCallback(async (payload: Record<string, unknown>) => {
    await guard(() => api('/api/admin/notifications', { method: 'POST', body: payload }))
  }, [guard])

  const loadAudit = useCallback(async (query: Record<string, string> = {}) => {
    await guard(async () => {
      const params = new URLSearchParams({ limit: '150' })
      for (const [k, v] of Object.entries(query)) if (v) params.set(k, v)
      const res = await api<{ rows: AuditRow[] }>(`/api/admin/audit?${params}`)
      setAudit(res.rows)
    })
  }, [guard])

  const loadAdmins = useCallback(async () => {
    await guard(async () => {
      const [adminsRes, rolesRes] = await Promise.all([
        api<AdminUser[]>('/api/admin/administrators'),
        api<AdminState['roles']>('/api/admin/roles'),
      ])
      setAdmins(adminsRes)
      setRoles(rolesRes)
    })
  }, [guard])

  const createAdmin = useCallback(async (payload: Record<string, unknown>) => {
    await guard(() => api('/api/admin/administrators', { method: 'POST', body: payload }))
  }, [guard])

  const updateAdmin = useCallback(async (id: string, payload: Record<string, unknown>) => {
    await guard(() => api(`/api/admin/administrators/${id}`, { method: 'PATCH', body: payload }))
  }, [guard])

  const loadSettings = useCallback(async () => {
    await guard(async () => {
      const res = await api<{ settings: Record<string, string>; payment_providers: PaymentMethod[] }>('/api/admin/settings')
      setSettings(res.settings)
      setPaymentProviders(res.payment_providers)
    })
  }, [guard])

  const saveSettings = useCallback(async (changes: Record<string, string>, reason: string) => {
    await guard(() => api('/api/admin/settings', { method: 'PATCH', body: { changes, reason } }))
  }, [guard])

  const report = useCallback(async (kind: string, from?: string, to?: string) => {
    const params = new URLSearchParams()
    if (from) params.set('from', new Date(from).toISOString())
    if (to) params.set('to', new Date(`${to}T23:59:59`).toISOString())
    return api<{ rows: Record<string, unknown>[]; count: number }>(`/api/admin/reports/${kind}?${params}`)
  }, [])

  useEffect(() => {
    let cancelled = false
    api<{ admin: AdminUser; csrfToken: string }>('/api/admin/session')
      .then((res) => {
        if (cancelled) return
        setCsrfToken(res.csrfToken)
        setAdmin(res.admin)
        setAuthenticated(true)
      })
      .catch(() => { if (!cancelled) setAuthenticated(false) })
      .finally(() => { if (!cancelled) setReady(true) })
    return () => { cancelled = true }
  }, [])

  useEffect(() => {
    if (authenticated) void refresh()
  }, [authenticated, refresh])

  const value = useMemo<AdminState & AdminActions>(() => ({
    ready, authenticated, admin, overview, customers, customersTotal, deposits, withdrawals,
    ledger, plans, userPlans, approvals, audit, admins, roles, welcomeRewards, tasks, codes,
    tickets, referrals, notifications, settings, paymentProviders, loading, error,
    login, logout, can, refresh, loadUsers, userDetail, loadDeposits, reviewDeposit,
    loadWithdrawals, decideWithdrawal, loadLedger, postAdjustment, previewAdjustment,
    decideApproval, setUserStatus, addUserNote, loadPlans, createPlan, updatePlan, assignPlan,
    setPlanAssignmentStatus, loadRewards, saveTask, saveCode, loadReferrals, loadTickets,
    loadNotifications,
    replyTicket, sendNotification, loadAudit, loadAdmins, createAdmin, updateAdmin,
    loadSettings, saveSettings, report,
  }), [
    ready, authenticated, admin, overview, customers, customersTotal, deposits, withdrawals,
    ledger, plans, userPlans, approvals, audit, admins, roles, welcomeRewards, tasks, codes,
    tickets, referrals, notifications, settings, paymentProviders, loading, error,
    login, logout, can, refresh, loadUsers, userDetail, loadDeposits, reviewDeposit,
    loadWithdrawals, decideWithdrawal, loadLedger, postAdjustment, previewAdjustment,
    decideApproval, setUserStatus, addUserNote, loadPlans, createPlan, updatePlan, assignPlan,
    setPlanAssignmentStatus, loadRewards, saveTask, saveCode, loadReferrals, loadTickets,
    loadNotifications,
    replyTicket, sendNotification, loadAudit, loadAdmins, createAdmin, updateAdmin,
    loadSettings, saveSettings, report,
  ])

  return <AdminCtx.Provider value={value}>{children}</AdminCtx.Provider>
}

export function useAdmin() {
  const ctx = useContext(AdminCtx)
  if (!ctx) throw new Error('useAdmin must be used inside AdminProvider')
  return ctx
}

export type { PayoutDestination, Wallet }