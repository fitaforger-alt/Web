import { useEffect, useState } from 'react'
import { Gift, Plus, ShieldCheck } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select, TextArea } from '../../components/ui/Input'
import { money, dateTimeStr } from '../../utils/format'

export default function Rewards() {
  const { welcomeRewards, tasks, codes, loadRewards, saveTask, saveCode, error } = useAdmin()
  const [showTask, setShowTask] = useState(false)
  const [showCode, setShowCode] = useState(false)
  const [taskForm, setTaskForm] = useState({ title: '', description: '', reward_points: '10', recurring: 'daily', action_url: '', active: true })
  const [codeForm, setCodeForm] = useState({ code: '', label: '', wallet: 'earnings', value: '50', max_redemptions: '100', per_user_limit: '1', expires_at: '' })
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)

  useEffect(() => { void loadRewards() }, [loadRewards])

  const createTask = async (event: React.FormEvent) => {
    event.preventDefault()
    setBusy(true)
    try {
      await saveTask(taskForm)
      setTaskForm({ title: '', description: '', reward_points: '10', recurring: 'daily', action_url: '', active: true })
      setShowTask(false)
      await loadRewards()
      setNotice('Task published.')
    } catch {
      setNotice(null)
    } finally {
      setBusy(false)
    }
  }

  const createCode = async (event: React.FormEvent) => {
    event.preventDefault()
    setBusy(true)
    try {
      await saveCode({ ...codeForm, expires_at: codeForm.expires_at || undefined })
      setCodeForm({ code: '', label: '', wallet: 'earnings', value: '50', max_redemptions: '100', per_user_limit: '1', expires_at: '' })
      setShowCode(false)
      await loadRewards()
      setNotice('Redemption code created.')
    } catch {
      setNotice(null)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <PageHeading
        title="Rewards & tasks"
        description="Welcome rewards are issued once per account at registration and cannot be duplicated from here."
      />

      <PermissionNotice permission="rewards.manage" />

      {notice && <Card className="p-3 mb-4 bg-emerald-50 border-emerald-100 text-xs text-emerald-800">{notice}</Card>}

      <Card className="p-4 mb-5 flex items-start gap-2 bg-blue-50/50 border-blue-100">
        <ShieldCheck size={16} className="text-blue-600 shrink-0 mt-0.5" />
        <p className="text-xs text-blue-900 leading-relaxed">
          The welcome reward is credited inside the same database transaction that creates the account, its wallet and
          its ledger entry. A unique constraint on the account makes a second issuance impossible. Corrections go
          through an audited manual adjustment, never by re-issuing the bonus.
        </p>
      </Card>

      <div className="grid lg:grid-cols-3 gap-4 mb-5">
        {[
          { label: 'Welcome rewards issued', value: String(welcomeRewards?.summary.issued ?? 0), sub: money(welcomeRewards?.summary.value_centavos ?? 0) },
          { label: 'Value issued', value: money(welcomeRewards?.summary.value_centavos ?? 0), sub: 'customer liabilities' },
          { label: 'Per account', value: money(welcomeRewards?.summary.per_account_centavos ?? 0), sub: 'once, at registration' },
        ].map((card) => (
          <Card key={card.label} className="p-4">
            <p className="text-[11px] text-muted">{card.label}</p>
            <p className="font-extrabold text-text text-xl mt-1">{card.value}</p>
            <p className="text-[10px] text-muted">{card.sub}</p>
          </Card>
        ))}
      </div>

      <Card className="overflow-x-auto mb-6">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">User ID</th>
              <th className="text-left p-3">Username</th>
              <th className="text-left p-3">Amount</th>
              <th className="text-left p-3">Issued</th>
              <th className="text-left p-3">Transaction</th>
              <th className="text-left p-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {(welcomeRewards?.rows.length ?? 0) === 0 && (
              <tr><td colSpan={6} className="p-8 text-center text-muted text-xs">No welcome rewards issued yet.</td></tr>
            )}
            {welcomeRewards?.rows.map((r) => (
              <tr key={r.user_id} className="border-t border-gray-100">
                <td className="p-3 font-mono text-[10px]">{r.user_id}</td>
                <td className="p-3 text-xs font-semibold">{r.username}</td>
                <td className="p-3 text-xs font-bold">{money(r.amount_centavos)}</td>
                <td className="p-3 text-[10px] text-muted">{dateTimeStr(r.issued_at)}</td>
                <td className="p-3 font-mono text-[10px]">{r.transaction_reference}</td>
                <td className="p-3"><Badge color="green">{r.status}</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <div className="flex items-center justify-between mb-3">
        <h2 className="font-bold text-text">Tasks</h2>
        <Button size="sm" onClick={() => setShowTask((v) => !v)} icon={<Plus size={14} />}>{showTask ? 'Close' : 'New task'}</Button>
      </div>

      {showTask && (
        <Card className="p-5 mb-4 max-w-2xl">
          <form onSubmit={createTask} className="grid sm:grid-cols-2 gap-3">
            <Input label="Title" value={taskForm.title} onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })} required />
            <Input label="Reward (PHP, paid to withdrawable balance)" inputMode="decimal" value={taskForm.reward_points} onChange={(e) => setTaskForm({ ...taskForm, reward_points: e.target.value })} />
            <Select label="Recurrence" value={taskForm.recurring} onChange={(e) => setTaskForm({ ...taskForm, recurring: e.target.value })}>
              <option value="daily">Daily</option>
              <option value="once">Once</option>
            </Select>
            <Input label="Link (optional)" value={taskForm.action_url} onChange={(e) => setTaskForm({ ...taskForm, action_url: e.target.value })} placeholder="/news" />
            <div className="sm:col-span-2">
              <TextArea label="Description" value={taskForm.description} onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })} />
            </div>
            <div className="sm:col-span-2"><Button type="submit" loading={busy}>Publish task</Button></div>
          </form>
        </Card>
      )}

      <Card className="overflow-x-auto mb-6">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">Task</th>
              <th className="text-left p-3">Points</th>
              <th className="text-left p-3">Recurrence</th>
              <th className="text-left p-3">Claims</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {tasks.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-muted text-xs">No tasks defined.</td></tr>}
            {tasks.map((t) => (
              <tr key={t.id} className="border-t border-gray-100">
                <td className="p-3">
                  <div className="text-xs font-semibold text-text">{t.title}</div>
                  <div className="text-[10px] text-muted">{t.description}</div>
                </td>
                <td className="p-3 text-xs">{money(t.reward_points)}</td>
                <td className="p-3 text-xs">{t.recurring}</td>
                <td className="p-3 text-xs">{t.claims}</td>
                <td className="p-3"><Badge color={t.active ? 'green' : 'gray'}>{t.active ? 'active' : 'off'}</Badge></td>
                <td className="p-3">
                  <Button size="sm" variant="secondary" onClick={() => void saveTask({ active: !t.active }, t.id)}>
                    {t.active ? 'Disable' : 'Enable'}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <div className="flex items-center justify-between mb-3">
        <h2 className="font-bold text-text">Redemption codes</h2>
        <Button size="sm" onClick={() => setShowCode((v) => !v)} icon={<Plus size={14} />}>{showCode ? 'Close' : 'New code'}</Button>
      </div>

      {showCode && (
        <Card className="p-5 mb-4 max-w-2xl">
          <form onSubmit={createCode} className="grid sm:grid-cols-2 gap-3">
            <Input label="Code" value={codeForm.code} onChange={(e) => setCodeForm({ ...codeForm, code: e.target.value.toUpperCase() })} placeholder="SUMMER-100" required />
            <Input label="Label" value={codeForm.label} onChange={(e) => setCodeForm({ ...codeForm, label: e.target.value })} />
            <Select label="Credits to" value={codeForm.wallet} onChange={(e) => setCodeForm({ ...codeForm, wallet: e.target.value })}>
              <option value="earnings">Earnings wallet (withdrawable)</option>
              <option value="recharge">Recharge wallet (cash)</option>
            </Select>
            <Input label="Value" type="number" value={codeForm.value} onChange={(e) => setCodeForm({ ...codeForm, value: e.target.value })} />
            <Input label="Max redemptions" type="number" value={codeForm.max_redemptions} onChange={(e) => setCodeForm({ ...codeForm, max_redemptions: e.target.value })} />
            <Input label="Per-user limit" type="number" value={codeForm.per_user_limit} onChange={(e) => setCodeForm({ ...codeForm, per_user_limit: e.target.value })} />
            <Input label="Expires (optional)" type="date" value={codeForm.expires_at} onChange={(e) => setCodeForm({ ...codeForm, expires_at: e.target.value })} />
            <div className="sm:col-span-2"><Button type="submit" loading={busy}>Create code</Button></div>
          </form>
        </Card>
      )}

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">Code</th>
              <th className="text-left p-3">Label</th>
              <th className="text-left p-3">Credits</th>
              <th className="text-left p-3">Value</th>
              <th className="text-left p-3">Used</th>
              <th className="text-left p-3">Limit</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {codes.length === 0 && <tr><td colSpan={8} className="p-8 text-center text-muted text-xs">No redemption codes.</td></tr>}
            {codes.map((c) => (
              <tr key={c.code} className="border-t border-gray-100">
                <td className="p-3 font-mono text-xs">{c.code}</td>
                <td className="p-3 text-xs">{c.label ?? '—'}</td>
                <td className="p-3 text-xs">{c.wallet}</td>
                <td className="p-3 text-xs">{money(c.value)}</td>
                <td className="p-3 text-xs">{c.redeemed}</td>
                <td className="p-3 text-xs">{c.max_redemptions}</td>
                <td className="p-3"><Badge color={c.active ? 'green' : 'gray'}>{c.active ? 'active' : 'disabled'}</Badge></td>
                <td className="p-3">
                  <Button size="sm" variant="secondary" onClick={() => void saveCode({ active: !c.active }, c.code)}>
                    {c.active ? 'Disable' : 'Enable'}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {codes.length === 0 && (
        <EmptyState icon={<Gift size={22} />} title="No redemption codes" description="Codes are validated server-side with expiry and use limits." />
      )}

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}