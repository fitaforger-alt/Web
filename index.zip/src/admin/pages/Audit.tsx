import { useEffect, useState } from 'react'
import { ScrollText } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { EmptyState } from '../../components/ui/Card'
import Input from '../../components/ui/Input'
import { dateTimeStr } from '../../utils/format'

export default function Audit() {
  const { audit, loadAudit } = useAdmin()
  const [action, setAction] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [expanded, setExpanded] = useState<string | null>(null)

  useEffect(() => {
    void loadAudit({
      action,
      from: from ? new Date(from).toISOString() : '',
      to: to ? new Date(`${to}T23:59:59`).toISOString() : '',
    })
  }, [loadAudit, action, from, to])

  return (
    <div>
      <PageHeading title="Audit logs" description="Append-only. Database triggers reject any update or delete." />

      <PermissionNotice permission="audit.read" />

      <Card className="p-4 grid grid-cols-1 lg:grid-cols-4 gap-3 mb-4">
        <Input placeholder="Filter by action, e.g. withdrawal" value={action} onChange={(e) => setAction(e.target.value)} />
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From" />
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To" />
        <button onClick={() => { setAction(''); setFrom(''); setTo('') }} className="px-4 py-3 rounded-xl border border-gray-200 text-sm font-semibold text-muted hover:bg-gray-50">
          Clear filters
        </button>
      </Card>

      {audit.length === 0 ? (
        <EmptyState icon={<ScrollText size={22} />} title="No audit entries" description="Administrative actions appear here with before and after values." />
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-muted text-[11px]">
              <tr>
                <th className="text-left p-3">When</th>
                <th className="text-left p-3">Actor</th>
                <th className="text-left p-3">Action</th>
                <th className="text-left p-3">Target</th>
                <th className="text-left p-3">Reason</th>
                <th className="text-left p-3">Transaction</th>
                <th className="text-left p-3">IP</th>
                <th className="text-left p-3"></th>
              </tr>
            </thead>
            <tbody>
              {audit.map((a) => (
                <>
                  <tr key={a.id} className="border-t border-gray-100">
                    <td className="p-3 text-[10px] text-muted whitespace-nowrap">{dateTimeStr(a.created_at)}</td>
                    <td className="p-3 text-xs">
                      {a.actor_name}
                      <span className="block text-[10px] text-muted">{a.actor_type}</span>
                    </td>
                    <td className="p-3 text-xs font-semibold">{a.action}</td>
                    <td className="p-3 text-[10px] text-muted">
                      {a.target_type ?? '—'}
                      {a.target_id && <span className="block font-mono break-all">{a.target_id}</span>}
                    </td>
                    <td className="p-3 text-[11px] text-muted max-w-[240px]">{a.reason ?? '—'}</td>
                    <td className="p-3 font-mono text-[10px]">{a.transaction_reference ?? '—'}</td>
                    <td className="p-3 text-[10px] text-muted">{a.ip ?? '—'}</td>
                    <td className="p-3">
                      <button
                        className="text-brand text-[11px] font-bold"
                        onClick={() => setExpanded(expanded === a.id ? null : a.id)}
                      >
                        {expanded === a.id ? 'Hide' : 'Details'}
                      </button>
                    </td>
                  </tr>
                  {expanded === a.id && (
                    <tr key={`${a.id}-detail`} className="border-t border-gray-100 bg-gray-50">
                      <td colSpan={8} className="p-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <p className="text-[11px] font-bold text-text mb-1">Before</p>
                            <pre className="text-[10px] text-muted whitespace-pre-wrap break-all">{JSON.stringify(a.before_json, null, 2) ?? 'null'}</pre>
                          </div>
                          <div>
                            <p className="text-[11px] font-bold text-text mb-1">After</p>
                            <pre className="text-[10px] text-muted whitespace-pre-wrap break-all">{JSON.stringify(a.after_json, null, 2) ?? 'null'}</pre>
                          </div>
                        </div>
                        <p className="text-[10px] text-muted mt-2">
                          Correlation id: <span className="font-mono">{a.correlation_id ?? '—'}</span>
                        </p>
                      </td>
                    </tr>
                  )}
                </>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  )
}