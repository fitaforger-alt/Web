import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { AlertTriangle, Calculator } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select, TextArea } from '../../components/ui/Input'
import { money, dateTimeStr } from '../../utils/format'

export default function Adjustments() {
  const { customers, ledger, postAdjustment, previewAdjustment, can, error } = useAdmin()
  const adjustments = ledger.filter((l) => l.kind.startsWith('manual_adjustment')).slice(0, 12)
  const [params] = useSearchParams()
  const [userId, setUserId] = useState(params.get('user') ?? '')
  const [wallet, setWallet] = useState('recharge')
  const [direction, setDirection] = useState<'Credit' | 'Debit'>('Credit')
  const [amount, setAmount] = useState('')
  const [reason, setReason] = useState('')
  const [note, setNote] = useState('')
  const [reference, setReference] = useState('')
  const [preview, setPreview] = useState<any>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!userId && customers.length > 0) setUserId(customers[0].id)
  }, [customers, userId])

  useEffect(() => {
    if (!userId || amount === '') { setPreview(null); return }
    let cancelled = false
    previewAdjustment({ userId, wallet, direction, amount })
      .then((res) => { if (!cancelled) setPreview(res) })
      .catch(() => { if (!cancelled) setPreview(null) })
    return () => { cancelled = true }
  }, [userId, wallet, direction, amount, previewAdjustment])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!preview) return
    setBusy(true)
    setNotice(null)
    try {
      const res = await postAdjustment({ userId, wallet, direction, amount, reason, note, reference: reference || undefined })
      if (res.status === 'pending_second_approval') {
        setNotice(res.message ?? 'A second administrator must approve this adjustment.')
      } else {
        setNotice('Adjustment posted to the ledger and recorded in the audit log.')
        setAmount(''); setNote(''); setReference('')
      }
    } catch {
      setNotice(null)
    } finally {
      setBusy(false)
    }
  }

  const valid = preview && preview.resulting_centavos >= 0 && reason.trim().length >= 4 && note.trim().length >= 8

  return (
    <div>
      <PageHeading title="Wallet adjustments" description="Every adjustment posts a ledger entry with before and after balances." />

      <PermissionNotice permission="ledger.adjust" />

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-5">
          <form onSubmit={submit} className="space-y-3">
            <Select label="Account" value={userId} onChange={(e) => setUserId(e.target.value)}>
              <option value="">Select a customer</option>
              {customers.map((c) => <option key={c.id} value={c.id}>{c.username} — {c.id}</option>)}
            </Select>
            <Select label="Wallet" value={wallet} onChange={(e) => setWallet(e.target.value)}>
              <option value="recharge">Recharge wallet</option>
              <option value="earnings">Earnings wallet (withdrawable)</option>
            </Select>
            <Select label="Direction" value={direction} onChange={(e) => setDirection(e.target.value as 'Credit' | 'Debit')}>
              <option value="Credit">Credit (add funds)</option>
              <option value="Debit">Debit (remove funds)</option>
            </Select>
            <Input label="Amount (PHP)" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" />

            <div className="rounded-xl bg-gray-50 p-3 space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="text-muted">Current balance</span>
                <span className="font-bold text-text">{preview ? money(preview.current_centavos) : '—'}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted">After this adjustment</span>
                <span className={`font-extrabold ${preview && preview.resulting_centavos < 0 ? 'text-red-600' : 'text-brand'}`}>
                  {preview ? money(preview.resulting_centavos) : '—'}
                </span>
              </div>
              {preview?.second_approval_required && (
                <p className="text-[11px] text-amber-700 flex items-center gap-1 pt-1">
                  <AlertTriangle size={12} /> This amount exceeds the two-person approval threshold.
                </p>
              )}
            </div>

            <Input label="Reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Accounting correction" />
            <TextArea label="Detailed explanation" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Full context stored on the ledger entry" />
            <Input label="Reference number (optional)" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Ticket or remittance reference" />

            <Button type="submit" block loading={busy} disabled={!valid} icon={<Calculator size={15} />}>
              Post adjustment
            </Button>
          </form>
        </Card>

        <div className="space-y-4">
          {notice && (
            <Card className="p-4 bg-emerald-50 border-emerald-100 text-xs text-emerald-800 leading-relaxed">{notice}</Card>
          )}

          <Card className="p-4">
            <h2 className="font-bold text-text text-sm mb-2">Rules the server enforces</h2>
            <ul className="text-xs text-muted space-y-1.5 list-disc pl-4 leading-relaxed">
              <li>A debit can never exceed the spendable balance; reserved funds count as unavailable.</li>
              <li>Balances cannot go negative — a database check rejects it.</li>
              <li>Every entry records the balance before and after the movement.</li>
              <li>A reason and a detailed explanation are mandatory and land in the audit log.</li>
              <li>Amounts above the configured threshold wait for a second administrator.</li>
              <li>Completed entries are never modified; corrections post linked reversals.</li>
            </ul>
          </Card>

          <Card className="p-4">
            <h2 className="font-bold text-text text-sm mb-2">Recent adjustments</h2>
            {adjustments.length === 0 ? (
              <p className="text-xs text-muted py-3 text-center">No adjustments posted in this session view.</p>
            ) : (
              adjustments.map((a) => (
                <div key={a.id} className="py-2 border-b border-gray-50 last:border-0">
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-bold ${a.direction === 'credit' ? 'text-emerald-600' : 'text-text'}`}>
                      {a.direction === 'credit' ? '+' : '−'}{money(a.amount_centavos)}
                    </span>
                    <Badge color="gray">{a.wallet}</Badge>
                  </div>
                  <p className="text-[10px] text-muted">{a.reason} · {a.actor_name} · {dateTimeStr(a.created_at)}</p>
                </div>
              ))
            )}
          </Card>
        </div>
      </div>

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
      {!can('ledger.adjust') && (
        <p className="text-[11px] text-muted mt-4">Your role cannot post adjustments; the server will refuse the request.</p>
      )}
    </div>
  )
}