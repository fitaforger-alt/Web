import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Search, UserSearch } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select } from '../../components/ui/Input'
import { money, dateStr } from '../../utils/format'

const PAGE_SIZE = 20

export default function Users() {
  const { customers, customersTotal, loadUsers, loading } = useAdmin()
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [page, setPage] = useState(0)

  const search = async (nextQ = q, nextStatus = status, nextPage = 0) => {
    setPage(nextPage)
    await loadUsers({ q: nextQ || undefined, status: nextStatus || undefined, offset: nextPage * PAGE_SIZE })
  }

  const rows = customers
  const pageCount = Math.max(1, Math.ceil(customersTotal / PAGE_SIZE))

  return (
    <div>
      <PageHeading title="Users" description={`${customersTotal} registered accounts`} />

      <Card className="p-4 flex flex-col lg:flex-row gap-3 mb-4">
        <form
          className="flex-1 flex gap-2"
          onSubmit={(e) => { e.preventDefault(); void search(q, status, 0) }}
        >
          <Input
            placeholder="Search username or user ID"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <Button type="submit" loading={loading} icon={<Search size={15} />}>Search</Button>
        </form>
        <Select value={status} onChange={(e) => setStatus(e.target.value)} className="lg:w-56">
          <option value="">All statuses</option>
          <option value="Active">Active</option>
          <option value="Suspended">Suspended</option>
          <option value="Restricted">Restricted</option>
        </Select>
        <Button variant="secondary" onClick={() => { setQ(''); setStatus(''); void search('', '', 0) }}>Clear</Button>
      </Card>

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">User</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Recharge</th>
              <th className="text-left p-3">Earnings</th>
              <th className="text-left p-3">Held</th>
              <th className="text-left p-3">Plans</th>
              <th className="text-left p-3">Registered</th>
              <th className="text-left p-3"></th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && !loading && (
              <tr><td colSpan={9} className="p-8 text-center text-muted text-xs">No users registered yet.</td></tr>
            )}
            {rows.map((u) => (
              <tr key={u.id} className="border-t border-gray-100 hover:bg-gray-50/60">
                <td className="p-3">
                  <div className="font-semibold text-text">{u.username}</div>
                  <div className="text-[10px] text-muted font-mono">{u.id}</div>
                </td>
                <td className="p-3">
                  <Badge color={u.status === 'Active' ? 'green' : u.status === 'Suspended' ? 'red' : 'amber'}>{u.status}</Badge>
                </td>
                <td className="p-3">{money(u.recharge_centavos)}</td>
                <td className="p-3">{money(u.earnings_centavos)}</td>
                <td className="p-3">{u.reserved_centavos > 0 ? <span className="text-amber-700">{money(u.reserved_centavos)}</span> : '—'}</td>
                <td className="p-3">{u.active_plans}</td>
                <td className="p-3 text-muted text-xs">{dateStr(u.created_at)}</td>
                <td className="p-3">
                  <Link to={`/admin/users/${u.id}`} className="text-brand font-bold text-xs hover:underline">Open</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {pageCount > 1 && (
        <div className="flex items-center justify-between mt-4">
          <span className="text-xs text-muted">Page {page + 1} of {pageCount}</span>
          <div className="flex gap-2">
            <Button size="sm" variant="secondary" disabled={page === 0} onClick={() => void search(q, status, page - 1)}>Previous</Button>
            <Button size="sm" variant="secondary" disabled={page >= pageCount - 1} onClick={() => void search(q, status, page + 1)}>Next</Button>
          </div>
        </div>
      )}

      {customers.length === 0 && customersTotal === 0 && (
        <EmptyState icon={<UserSearch size={22} />} title="No users registered yet" description="Accounts appear here as soon as they register." />
      )}
    </div>
  )
}