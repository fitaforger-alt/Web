import { useEffect } from 'react'
import { Users2 } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import { money } from '../../utils/format'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import { dateTimeStr } from '../../utils/format'

export default function Referrals() {
  const { referrals, loadReferrals } = useAdmin()

  useEffect(() => { void loadReferrals() }, [loadReferrals])

  return (
    <div>
      <PageHeading title="Referrals" description="Every relationship is stored against the real referring account." />

      <PermissionNotice permission="ledger.read" />

      <div className="grid lg:grid-cols-3 gap-4 mb-5">
        {[
          { label: 'Referred accounts', value: String(referrals.total) },
          { label: 'Bonus awarded', value: money(referrals.bonus_points_centavos) },
          { label: 'Average bonus', value: referrals.total > 0 ? money(Math.round(referrals.bonus_points_centavos / referrals.total)) : money(0) },
        ].map((card) => (
          <Card key={card.label} className="p-4">
            <p className="text-[11px] text-muted">{card.label}</p>
            <p className="font-extrabold text-text text-xl mt-1">{card.value}</p>
          </Card>
        ))}
      </div>

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">Referrer</th>
              <th className="text-left p-3">Referred account</th>
              <th className="text-left p-3">Code used</th>
              <th className="text-left p-3">Bonus</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">When</th>
            </tr>
          </thead>
          <tbody>
            {referrals.rows.length === 0 && (
              <tr><td colSpan={6} className="p-8 text-center text-muted text-xs">No referrals recorded yet.</td></tr>
            )}
            {referrals.rows.map((r) => (
              <tr key={r.id} className="border-t border-gray-100">
                <td className="p-3 text-xs font-semibold">{r.referrer_username}</td>
                <td className="p-3 text-xs">{r.referred_username}</td>
                <td className="p-3 font-mono text-[10px]">{r.code_used}</td>
                <td className="p-3 text-xs">{r.reward_centavos > 0 ? money(r.reward_centavos) : '—'}</td>
                <td className="p-3"><Badge color="green">{r.status}</Badge></td>
                <td className="p-3 text-[10px] text-muted">{dateTimeStr(r.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {referrals.rows.length === 0 && (
        <EmptyState icon={<Users2 size={22} />} title="No referrals yet" description="A relationship is created when someone registers with a valid code." />
      )}
    </div>
  )
}