import { useEffect, useState } from 'react'
import { ArrowLeftRight, Lock } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select } from '../../components/ui/Input'
import { money, dateTimeStr } from '../../utils/format'

export default function Transactions() {
  const { ledger, loadLedger, error } = useAdmin()
  const [kind, setKind] = useState('')
  const [wallet, setWallet] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')

  useEffect(() => {
    void loadLedger({
      kind, wallet,
      from: from ? new Date(from).toISOString() : '',
      to: to ? new Date(`${to}T23:59:59`).toISOString() : '',
    })
  }, [loadLedger, kind, wallet, from, to])

  const kinds = [...new Set(ledger.map((l) => l.kind))].sort()

  return (
    <div>
      <PageHeading title="Transactions" description="The permanent financial ledger. Entries are immutable; corrections post linked reversals." />

      <PermissionNotice permission="ledger.read" />

      <Card className="p-4 grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
        <Select value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="">All types</option>
          {kinds.map((k) => <option key={k} value={k}>{k}</option>)}
        </Select>
        <Select value={wallet} onChange={(e) => setWallet(e.target.value)}>
          <option value="">All wallets</option>
          <option value="recharge">Recharge</option>
          <option value="earnings">Earnings</option>
          {/* Historical rows only — points are no longer awarded anywhere. */}
          <option value="points">Points (legacy, historical only)</option>
        </Select>
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" />
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" />
        <Button variant="secondary" onClick={() => { setKind(''); setWallet(''); setFrom(''); setTo('') }}>Clear</Button>
      </Card>

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">Reference</th>
              <th className="text-left p-3">User</th>
              <th className="text-left p-3">Type</th>
              <th className="text-left p-3">Wallet</th>
              <th className="text-left p-3">Amount</th>
              <th className="text-left p-3">Before → After</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Actor</th>
              <th className="text-left p-3">When</th>
            </tr>
          </thead>
          <tbody>
            {ledger.length === 0 && (
              <tr><td colSpan={9} className="p-8 text-center text-muted text-xs">No transactions available.</td></tr>
            )}
            {ledger.map((l) => (
              <tr key={l.id} className="border-t border-gray-100">
                <td className="p-3 font-mono text-[10px]">
                  {l.reference}
                  {l.reversal_of && <span className="block text-amber-700">reversal</span>}
                </td>
                <td className="p-3 text-xs">{l.username ?? l.user_id}</td>
                <td className="p-3 text-xs">{l.kind}</td>
                <td className="p-3 text-xs">{l.wallet}</td>
                <td className={`p-3 font-bold text-xs ${l.direction === 'credit' ? 'text-emerald-600' : 'text-text'}`}>
                  {l.direction === 'credit' ? '+' : '−'}{l.wallet === 'points' ? l.amount_centavos : money(l.amount_centavos)}
                </td>
                <td className="p-3 text-[10px] text-muted">
                  {l.balance_before_centavos === null ? '—' : l.wallet === 'points'
                    ? `${l.balance_before_centavos} → ${l.balance_after_centavos}`
                    : `${money(l.balance_before_centavos)} → ${money(l.balance_after_centavos ?? 0)}`}
                </td>
                <td className="p-3"><Badge color={l.status === 'completed' ? 'green' : l.status === 'pending' ? 'amber' : 'gray'}>{l.status}</Badge></td>
                <td className="p-3 text-[10px] text-muted">{l.actor_name ?? 'system'}</td>
                <td className="p-3 text-[10px] text-muted">{dateTimeStr(l.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {ledger.length === 0 && (
        <EmptyState icon={<ArrowLeftRight size={22} />} title="No transactions available" description="Ledger entries appear here as movements are recorded." />
      )}

      <Card className="p-3 mt-4 flex items-start gap-2 bg-gray-50">
        <Lock size={14} className="text-muted shrink-0 mt-0.5" />
        <p className="text-[11px] text-muted">
          Completed entries cannot be edited or deleted — database triggers reject both. A correction is posted as a
          linked reversal with its own reason and audit entry.
        </p>
      </Card>

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}