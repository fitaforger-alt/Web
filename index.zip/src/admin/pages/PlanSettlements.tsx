import { useCallback, useEffect, useState } from 'react'
import { CalendarClock, PlayCircle } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { api, ApiError } from '../../lib/api'
import { money, dateTimeStr } from '../../utils/format'

interface SettlementRow {
  id: string
  user_plan_id: string
  user_id: string
  username: string
  plan_name: string
  day_number: number
  amount_centavos: number
  ledger_entry_id: string
  reference: string
  settled_at: string
}

interface SettlementFeed {
  total: number
  value_centavos: number
  rows: SettlementRow[]
}

export default function PlanSettlements() {
  const { can } = useAdmin()
  const [feed, setFeed] = useState<SettlementFeed | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [running, setRunning] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)
  const [result, setResult] = useState<{ days: number; amount_centavos: number } | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await api<SettlementFeed>('/api/admin/plan-settlements?limit=200')
      setFeed(data)
      setError(null)
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load plan settlements.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const runSettlement = async () => {
    setRunning(true)
    setNotice(null)
    try {
      const res = await api<{ days: number; amount_centavos: number }>('/api/admin/system/settle', {
        method: 'POST',
        body: { reason: 'Manual settlement run from the admin console' },
      })
      setResult(res)
      setNotice(
        res.days === 0
          ? 'Sweep complete. No plan had a completed 24-hour period due, so nothing was credited.'
          : `Credited ${res.days} day(s), totalling ${money(res.amount_centavos)}.`,
      )
      await load()
    } catch (err) {
      setNotice(err instanceof ApiError ? err.message : 'The settlement sweep failed.')
    } finally {
      setRunning(false)
    }
  }

  const rows = feed?.rows ?? []

  return (
    <div>
      <PageHeading
        title="Plan settlements"
        description="Every daily plan income credit, with the ledger reference it posted. One credit per completed 24-hour period."
      />

      <PermissionNotice permission="plans.manage" />

      <div className="grid sm:grid-cols-3 gap-4 mb-5">
        <Card className="p-4">
          <p className="text-[11px] text-muted">Days settled</p>
          <p className="text-2xl font-extrabold text-text mt-1">{feed?.total ?? '—'}</p>
        </Card>
        <Card className="p-4">
          <p className="text-[11px] text-muted">Income credited to date</p>
          <p className="text-2xl font-extrabold text-brand mt-1">{money(feed?.value_centavos ?? 0)}</p>
        </Card>
        <Card className="p-4 flex flex-col justify-between">
          <p className="text-[11px] text-muted mb-2">Settlement sweep</p>
          {can('plans.manage') ? (
            <Button size="sm" loading={running} onClick={runSettlement} icon={<PlayCircle size={14} />}>
              Run settlement
            </Button>
          ) : (
            <p className="text-[11px] text-muted">Requires plans.manage.</p>
          )}
        </Card>
      </div>

      {notice && (
        <Card
          className={`p-3 mb-4 text-xs ${error ? 'bg-red-50 border-red-100 text-red-700' : 'bg-emerald-50 border-emerald-100 text-emerald-800'}`}
        >
          {notice}
        </Card>
      )}

      {result && (
        <Card className="p-3 mb-4 border-gray-200 bg-gray-50 text-xs text-text">
          Last run: {result.days === 0 ? (
            <>no completed 24-hour period was due, so nothing was credited</>
          ) : (
            <>credited <strong>{result.days}</strong> day(s) totalling <strong>{money(result.amount_centavos)}</strong></>
          )}. Running this again will not pay twice — each day is claimed by a unique settlement record.
        </Card>
      )}

      <Card className="p-4 mb-5">
        <h2 className="font-bold text-text text-sm mb-2 flex items-center gap-2">
          <CalendarClock size={15} className="text-brand" />
          How this works
        </h2>
        <ul className="text-xs text-muted space-y-1.5 list-disc pl-4 leading-relaxed">
          <li>Each plan's clock starts at the exact moment of purchase, not midnight.</li>
          <li>A credit posts only after a full 24-hour period has elapsed, to the customer's withdrawable earnings wallet.</li>
          <li>The sweep runs on a timer and again whenever a customer opens their dashboard or plans, so income appears promptly.</li>
          <li>Each day is claimed by a unique record. A repeated sweep, a restart or two workers racing can never pay the same day twice.</li>
          <li>A plan stops crediting once its purchased term is fully settled.</li>
        </ul>
      </Card>

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">Customer</th>
              <th className="text-left p-3">Plan</th>
              <th className="text-left p-3">Day</th>
              <th className="text-left p-3">Credited</th>
              <th className="text-left p-3">Period ended</th>
              <th className="text-left p-3">Reference</th>
            </tr>
          </thead>
          <tbody>
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={6}>
                  <EmptyState
                    icon={<CalendarClock size={22} />}
                    title="No plan income credited yet"
                    description="Credits appear here once a plan has completed its first full 24-hour period. Nothing is listed until money has genuinely moved."
                  />
                </td>
              </tr>
            )}
            {rows.map((row) => (
              <tr key={row.id} className="border-t border-gray-50">
                <td className="p-3 font-semibold text-text">{row.username}</td>
                <td className="p-3 text-muted">{row.plan_name}</td>
                <td className="p-3 text-muted">Day {row.day_number}</td>
                <td className="p-3 font-bold text-emerald-600">{money(row.amount_centavos)}</td>
                <td className="p-3 text-muted text-xs">{dateTimeStr(row.settled_at)}</td>
                <td className="p-3 font-mono text-[11px] text-muted">{row.reference}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}