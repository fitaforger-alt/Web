import { useEffect, useState } from 'react'
import { Package, Plus } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select, TextArea } from '../../components/ui/Input'
import { money } from '../../utils/format'

const BLANK = {
  name: '', category: 'daily', price: '', duration_days: '30', projected_daily: '',
  slots_total: '0', image_url: '', description: '', terms: '', eligibility: '', active: true,
}

export default function Plans() {
  const { plans, createPlan, updatePlan, loadPlans, error } = useAdmin()
  const [form, setForm] = useState({ ...BLANK })
  const [showForm, setShowForm] = useState(false)
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)

  useEffect(() => { void loadPlans() }, [loadPlans])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    setBusy(true)
    setNotice(null)
    try {
      await createPlan(form)
      setNotice(`Product "${form.name}" created.`)
      setForm({ ...BLANK })
      setShowForm(false)
    } catch {
      setNotice(null)
    } finally {
      setBusy(false)
    }
  }

  const toggle = async (id: string, active: boolean) => {
    await updatePlan(id, { active, reason: active ? 'Product activated' : 'Product deactivated' })
    await loadPlans()
  }

  const archive = async (id: string) => {
    if (!window.confirm('Archive this product? Existing customer plans keep the terms they accepted.')) return
    await updatePlan(id, { archived: true, reason: 'Product archived' })
    await loadPlans()
  }

  return (
    <div>
      <PageHeading
        title="Products"
        description="Term and price changes create a new version. Customer plans keep the copy they accepted."
        actions={<Button size="sm" onClick={() => setShowForm((v) => !v)} icon={<Plus size={14} />}>{showForm ? 'Close' : 'New product'}</Button>}
      />

      <PermissionNotice permission="plans.manage" />

      {notice && <Card className="p-3 mb-4 bg-emerald-50 border-emerald-100 text-xs text-emerald-800">{notice}</Card>}

      {showForm && (
        <Card className="p-5 mb-5 max-w-2xl">
          <h2 className="font-bold text-text text-sm mb-3">Create a product</h2>
          <form onSubmit={submit} className="grid sm:grid-cols-2 gap-3">
            <Input label="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <Select label="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              <option value="daily">Daily</option>
              <option value="vip">VIP</option>
            </Select>
            <Input label="Price (PHP)" inputMode="decimal" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required />
            <Input label="Duration (days)" type="number" value={form.duration_days} onChange={(e) => setForm({ ...form, duration_days: e.target.value })} required />
            <Input label="Daily income (PHP)" inputMode="decimal" value={form.projected_daily} onChange={(e) => setForm({ ...form, projected_daily: e.target.value })} />
            <Input label="Slots (0 = unlimited)" type="number" value={form.slots_total} onChange={(e) => setForm({ ...form, slots_total: e.target.value })} />
            <div className="sm:col-span-2">
              <Input label="Image URL" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="https://…" />
            </div>
            <div className="sm:col-span-2">
              <Input label="Short description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <TextArea
                label="Published terms"
                value={form.terms}
                onChange={(e) => setForm({ ...form, terms: e.target.value })}
                placeholder="Must describe that projected rewards are estimates, not guarantees."
              />
            </div>
            <div className="sm:col-span-2">
              <Input label="Eligibility" value={form.eligibility} onChange={(e) => setForm({ ...form, eligibility: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <Button type="submit" loading={busy}>Create product</Button>
            </div>
          </form>
        </Card>
      )}

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">Product</th>
              <th className="text-left p-3">Category</th>
              <th className="text-left p-3">Price</th>
              <th className="text-left p-3">Duration</th>
              <th className="text-left p-3">Projected daily</th>
              <th className="text-left p-3">Slots</th>
              <th className="text-left p-3">Version</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {plans.length === 0 && (
              <tr><td colSpan={9} className="p-8 text-center text-muted text-xs">No products defined yet.</td></tr>
            )}
            {plans.map((p) => (
              <tr key={p.id} className="border-t border-gray-100">
                <td className="p-3">
                  <div className="font-semibold text-text">{p.name}</div>
                  <div className="text-[10px] text-muted font-mono">{p.id}</div>
                </td>
                <td className="p-3"><Badge color={p.category === 'vip' ? 'violet' : 'blue'}>{p.category}</Badge></td>
                <td className="p-3">{money(p.price_centavos)}</td>
                <td className="p-3">{p.duration_days} days</td>
                <td className="p-3">{money(p.projected_daily_centavos)}</td>
                <td className="p-3">
                  {p.slots_total > 0 ? `${Math.max(0, p.slots_total - p.slots_taken)}/${p.slots_total}` : 'Unlimited'}
                </td>
                <td className="p-3">v{p.current_version}</td>
                <td className="p-3">
                  <Badge color={p.archived ? 'gray' : p.active ? 'green' : 'amber'}>
                    {p.archived ? 'archived' : p.active ? 'active' : 'inactive'}
                  </Badge>
                </td>
                <td className="p-3">
                  <div className="flex flex-col gap-1.5">
                    {!p.archived && (
                      <Button size="sm" variant="secondary" onClick={() => void toggle(p.id, !p.active)}>
                        {p.active ? 'Deactivate' : 'Activate'}
                      </Button>
                    )}
                    {!p.archived && (
                      <Button size="sm" variant="danger" onClick={() => void archive(p.id)}>Archive</Button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {plans.length === 0 && (
        <Card className="p-8 text-center">
          <Package size={22} className="text-muted mx-auto mb-2" />
          <p className="text-sm font-semibold text-text">No products defined yet</p>
          <p className="text-xs text-muted mt-1">Create the first product so customers have something to activate.</p>
        </Card>
      )}

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}