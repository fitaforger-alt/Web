import { useEffect, useState } from 'react'
import { Save, Settings2 } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { TextArea } from '../../components/ui/Input'
import { money } from '../../utils/format'

const FIELDS: { key: string; label: string; type: 'text' | 'number' | 'boolean' | 'textarea'; hint?: string }[] = [
  { key: 'platform_name', label: 'Platform name', type: 'text' },
  { key: 'platform_tagline', label: 'Tagline', type: 'text' },
  { key: 'welcome_reward_centavos', label: 'Welcome reward (centavos)', type: 'number', hint: '5000 = ₱50.00' },
  { key: 'welcome_reward_withdrawable', label: 'Welcome reward withdrawable', type: 'boolean' },
  { key: 'welcome_reward_note', label: 'Welcome reward note', type: 'textarea' },
  { key: 'welcome_reward_bonus_referral_centavos', label: 'Referral bonus (centavos)', type: 'number' },
  { key: 'registration_open', label: 'Registration open', type: 'boolean' },
  { key: 'maintenance_mode', label: 'Maintenance mode', type: 'boolean' },
  { key: 'maintenance_message', label: 'Maintenance message', type: 'textarea' },
  { key: 'min_deposit_centavos', label: 'Minimum deposit (centavos)', type: 'number' },
  { key: 'max_deposit_centavos', label: 'Maximum deposit (centavos)', type: 'number' },
  { key: 'min_withdrawal_centavos', label: 'Minimum withdrawal (centavos)', type: 'number' },
  { key: 'withdrawal_fee_centavos', label: 'Withdrawal fee (centavos)', type: 'number' },
  { key: 'withdrawal_fee_percent', label: 'Withdrawal fee (basis points)', type: 'number', hint: '100 = 1%' },
  { key: 'daily_withdrawal_limit_centavos', label: 'Daily withdrawal limit (centavos, 0 = none)', type: 'number' },
  { key: 'second_approval_threshold_centavos', label: 'Two-person approval threshold (centavos)', type: 'number' },
  { key: 'checkin_reward_centavos', label: 'Check-in reward (centavos, paid to withdrawable balance)', type: 'number' },
  { key: 'referral_terms', label: 'Referral terms', type: 'textarea' },
  { key: 'support_email', label: 'Support email', type: 'text' },
  { key: 'support_hours', label: 'Support hours', type: 'text' },
  { key: 'terms_version', label: 'Terms version', type: 'text' },
]

export default function SettingsPage() {
  const { settings, paymentProviders, loadSettings, saveSettings, error } = useAdmin()
  const [draft, setDraft] = useState<Record<string, string>>({})
  const [reason, setReason] = useState('')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)

  useEffect(() => { void loadSettings() }, [loadSettings])

  useEffect(() => {
    if (settings) setDraft(settings)
  }, [settings])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!settings) return
    const changes: Record<string, string> = {}
    for (const field of FIELDS) {
      const next = draft[field.key]
      if (next !== undefined && next !== settings[field.key]) changes[field.key] = next
    }
    if (Object.keys(changes).length === 0) { setNotice('Nothing changed.'); return }
    setBusy(true)
    setNotice(null)
    try {
      await saveSettings(changes, reason.trim())
      await loadSettings()
      setNotice(`${Object.keys(changes).length} setting(s) saved and written to the audit log.`)
      setReason('')
    } catch {
      setNotice(null)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <PageHeading title="Settings" description="Platform configuration. Every change requires a reason and is audited." />

      <PermissionNotice permission="settings.manage" />

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <h2 className="font-bold text-text text-sm mb-4 flex items-center gap-2">
            <Settings2 size={15} className="text-brand" /> Platform configuration
          </h2>
          <form onSubmit={submit} className="grid sm:grid-cols-2 gap-4">
            {FIELDS.map((field) => {
              const value = draft[field.key] ?? ''
              if (field.type === 'boolean') {
                return (
                  <label key={field.key} className="flex items-center gap-2 text-xs text-text sm:col-span-2">
                    <input
                      type="checkbox"
                      className="w-4 h-4 rounded border-gray-300"
                      checked={value === 'true'}
                      onChange={(e) => setDraft({ ...draft, [field.key]: String(e.target.checked) })}
                    />
                    {field.label}
                  </label>
                )
              }
              if (field.type === 'textarea') {
                return (
                  <div key={field.key} className="sm:col-span-2">
                    <TextArea
                      label={field.label}
                      value={value}
                      onChange={(e) => setDraft({ ...draft, [field.key]: e.target.value })}
                    />
                  </div>
                )
              }
              return (
                <Input
                  key={field.key}
                  label={field.label}
                  type={field.type === 'number' ? 'number' : 'text'}
                  value={value}
                  hint={field.hint}
                  onChange={(e) => setDraft({ ...draft, [field.key]: e.target.value })}
                />
              )
            })}

            <div className="sm:col-span-2">
              <Input
                label="Reason for these changes (required, audited)"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Why are these settings changing?"
              />
              <Button type="submit" className="mt-3" loading={busy} disabled={reason.trim().length < 4} icon={<Save size={15} />}>
                Save settings
              </Button>
              {notice && <p className="text-xs text-emerald-700 mt-2">{notice}</p>}
            </div>
          </form>
        </Card>

        <div className="space-y-4">
          <Card className="p-4">
            <h2 className="font-bold text-text text-sm mb-3">Payment providers</h2>
            {paymentProviders.map((p) => (
              <div key={p.id} className="py-2 border-b border-gray-50 last:border-0">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-text">{p.label}</p>
                  <Badge color={p.enabled ? 'green' : 'gray'}>{p.enabled ? p.mode : 'disabled'}</Badge>
                </div>
                <p className="text-[11px] text-muted">{p.reason ?? 'Credentials are configured on the server.'}</p>
              </div>
            ))}
            <p className="text-[11px] text-muted mt-3 leading-relaxed">
              Provider credentials are environment variables, never stored in the database or sent to the browser.
            </p>
          </Card>

          <Card className="p-4">
            <h2 className="font-bold text-text text-sm mb-2">Current thresholds</h2>
            <ul className="text-xs text-muted space-y-1.5">
              <li>Welcome reward: <strong className="text-text">{money(Number(draft.welcome_reward_centavos ?? 0))}</strong></li>
              <li>Minimum deposit: <strong className="text-text">{money(Number(draft.min_deposit_centavos ?? 0))}</strong></li>
              <li>Minimum withdrawal: <strong className="text-text">{money(Number(draft.min_withdrawal_centavos ?? 0))}</strong></li>
              <li>Two-person approval above: <strong className="text-text">{money(Number(draft.second_approval_threshold_centavos ?? 0))}</strong></li>
            </ul>
          </Card>
        </div>
      </div>

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}