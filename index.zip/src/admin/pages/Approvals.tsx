import { useEffect } from 'react'
import { CheckSquare, ShieldAlert } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { money, dateTimeStr } from '../../utils/format'

export default function Approvals() {
  const { approvals, decideApproval, refresh } = useAdmin()

  useEffect(() => { void refresh() }, [refresh])

  const decide = async (id: string, decision: 'approve' | 'reject') => {
    const note = window.prompt(decision === 'approve'
      ? 'Note for the approval record:'
      : 'Reason for rejecting this request:')
    if (decision === 'reject' && (!note || note.trim().length < 4)) return
    await decideApproval(id, decision, note?.trim())
    await refresh()
  }

  return (
    <div>
      <PageHeading
        title="Approvals"
        description="Large adjustments wait here until a second administrator decides. The requester cannot approve their own request."
      />

      <PermissionNotice permission="ledger.adjust" />

      {approvals.length === 0 ? (
        <EmptyState
          icon={<CheckSquare size={22} />}
          title="No approvals pending"
          description="Adjustments above the configured two-person threshold appear here."
        />
      ) : (
        <div className="space-y-3">
          {approvals.map((a) => (
            <Card key={a.id} className="p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-extrabold text-text text-lg">
                      {a.payload.direction === 'Credit' ? '+' : '−'}{money(a.payload.amount_centavos)}
                    </p>
                    <Badge color="gray">{a.payload.wallet} wallet</Badge>
                    <Badge color="violet">two-person rule</Badge>
                  </div>
                  <p className="text-[11px] text-muted mt-1">
                    Requested by {a.requested_by_name} · {dateTimeStr(a.requested_at)}
                  </p>
                  <p className="text-xs text-text mt-1">Reason: {a.payload.reason}</p>
                  <p className="text-[11px] text-muted mt-0.5">{a.payload.note}</p>
                </div>
                <div className="flex flex-col gap-2 sm:min-w-[200px]">
                  <Button size="sm" onClick={() => void decide(a.id, 'approve')}>Approve and post</Button>
                  <Button size="sm" variant="danger" onClick={() => void decide(a.id, 'reject')}>Reject</Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Card className="p-4 mt-4 flex items-start gap-2 bg-gray-50">
        <ShieldAlert size={16} className="text-muted shrink-0 mt-0.5" />
        <p className="text-[11px] text-muted leading-relaxed">
          Nothing is credited when a request is submitted. The ledger entry is written only when a second administrator
          approves, and the requester is blocked from approving their own request by the server.
        </p>
      </Card>
    </div>
  )
}