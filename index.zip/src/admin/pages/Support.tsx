import { useEffect, useState } from 'react'
import { LifeBuoy, MessageSquare } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import TextArea from '../../components/ui/Input'
import { api } from '../../lib/api'
import { dateTimeStr } from '../../utils/format'

export default function Support() {
  const { tickets, loadTickets, replyTicket, error } = useAdmin()
  const [status, setStatus] = useState('')
  const [selected, setSelected] = useState<string | null>(null)
  const [detail, setDetail] = useState<{ ticket: any; messages: any[] } | null>(null)
  const [reply, setReply] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => { void loadTickets() }, [loadTickets])

  const open = async (id: string) => {
    setSelected(id)
    setDetail(null)
    try {
      setDetail(await api<{ ticket: any; messages: any[] }>(`/api/admin/tickets/${id}`))
    } catch {
      setDetail(null)
    }
  }

  const send = async (nextStatus?: string) => {
    if (!selected || reply.trim().length < 2) return
    setBusy(true)
    try {
      await replyTicket(selected, reply.trim(), nextStatus)
      setReply('')
      await open(selected)
      await loadTickets()
    } finally {
      setBusy(false)
    }
  }

  const rows = tickets.filter((t) => !status || t.status === status)

  return (
    <div>
      <PageHeading title="Support tickets" description="Customer requests, with the full message history." />

      <PermissionNotice permission="support.manage" />

      <div className="flex gap-2 flex-wrap mb-4">
        {['', 'open', 'in_progress', 'waiting_user', 'resolved', 'closed'].map((s) => (
          <button
            key={s || 'all'}
            onClick={() => setStatus(s)}
            className={`px-3 py-1.5 rounded-full text-[11px] font-bold transition ${
              status === s ? 'bg-brand text-white' : 'bg-white text-muted border border-gray-200'
            }`}
          >
            {s === '' ? 'All' : s.replace('_', ' ')}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <h2 className="font-bold text-text text-sm mb-3">Inbox ({rows.length})</h2>
          {rows.length === 0 ? (
            <EmptyState icon={<LifeBuoy size={22} />} title="No support tickets" description="Tickets created from the customer site appear here." />
          ) : (
            rows.map((t) => (
              <button
                key={t.id}
                onClick={() => void open(t.id)}
                className={`w-full text-left py-2.5 border-b border-gray-50 last:border-0 hover:bg-gray-50 rounded px-2 ${selected === t.id ? 'bg-red-50/50' : ''}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-semibold text-text truncate">{t.subject}</p>
                  <Badge color={t.status === 'resolved' || t.status === 'closed' ? 'green' : t.status === 'open' ? 'amber' : 'blue'}>
                    {t.status.replace('_', ' ')}
                  </Badge>
                </div>
                <p className="text-[10px] text-muted mt-0.5">
                  {t.reference} · {t.username ?? t.user_id} · {t.category} · {dateTimeStr(t.updated_at)}
                </p>
              </button>
            ))
          )}
        </Card>

        <Card className="p-4">
          {!detail ? (
            <EmptyState icon={<MessageSquare size={22} />} title="Select a ticket" description="The conversation appears here." />
          ) : (
            <>
              <h2 className="font-bold text-text text-sm">{detail.ticket.subject}</h2>
              <p className="text-[10px] text-muted mb-3">
                {detail.ticket.reference} · {detail.ticket.username ?? detail.ticket.user_id} · opened {dateTimeStr(detail.ticket.created_at)}
              </p>
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {detail.messages.map((m) => (
                  <div key={m.id} className={`p-3 rounded-xl ${m.author_type === 'admin' ? 'bg-brand/5 ml-6' : 'bg-gray-50 mr-6'}`}>
                    <p className="text-[10px] font-bold text-muted mb-1">{m.author_type === 'admin' ? 'Support' : 'Customer'} · {dateTimeStr(m.created_at)}</p>
                    <p className="text-xs text-text leading-relaxed">{m.body}</p>
                  </div>
                ))}
              </div>
              <TextArea className="mt-3" value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Write a reply" />
              <div className="flex gap-2 mt-2">
                <Button size="sm" block loading={busy} onClick={() => void send()}>Send reply</Button>
                <Button size="sm" block variant="secondary" loading={busy} onClick={() => void send('resolved')}>Resolve</Button>
                <Button size="sm" block variant="secondary" loading={busy} onClick={() => void send('closed')}>Close</Button>
              </div>
            </>
          )}
        </Card>
      </div>

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}