import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, Ban, CheckCircle2, StickyNote } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState, Row } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { TextArea } from '../../components/ui/Input'
import { money, dateStr, dateTimeStr } from '../../utils/format'

const TABS = ['Overview', 'Wallets', 'Transactions', 'Plans', 'Referrals', 'Notes', 'Audit'] as const
type Tab = typeof TABS[number]

interface UserDetail {
  user: any
  wallet: any
  entries: any[]
  plans: any[]
  notes: any[]
  welcomeReward: any
  referrals: any[]
  auditTrail: any[]
  adjustments: any[]
}

export default function UserDetailPage() {
  const { id } = useParams()
  const { userDetail, setUserStatus, addUserNote, error } = useAdmin()
  const [data, setData] = useState<UserDetail | null>(null)
  const [tab, setTab] = useState<Tab>('Overview')
  const [note, setNote] = useState('')
  const [statusReason, setStatusReason] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!id) return
    let cancelled = false
    userDetail(id).then((res: UserDetail) => { if (!cancelled) setData(res) }).catch(() => undefined)
    return () => { cancelled = true }
  }, [id, userDetail])

  if (!data) {
    return (
      <div>
        <Link to="/admin/users" className="inline-flex items-center gap-1 text-xs font-bold text-brand mb-4">
          <ArrowLeft size={14} /> Back to users
        </Link>
        <div className="h-40 animate-pulse rounded-card bg-gray-100" />
      </div>
    )
  }

  const { user, wallet, entries, plans, notes, welcomeReward, referrals, auditTrail, adjustments } = data

  const changeStatus = (status: string) => {
    if (statusReason.trim().length < 4) return
    setBusy(true)
    setUserStatus(user.id, status, statusReason.trim())
      .then(() => userDetail(user.id).then((res: UserDetail) => setData(res)))
      .finally(() => setBusy(false))
    setStatusReason('')
  }

  const saveNote = () => {
    if (note.trim().length < 2) return
    setBusy(true)
    addUserNote(user.id, note.trim())
      .then(() => userDetail(user.id).then((res: UserDetail) => setData(res)))
      .finally(() => setBusy(false))
    setNote('')
  }

  return (
    <div>
      <Link to="/admin/users" className="inline-flex items-center gap-1 text-xs font-bold text-brand mb-3">
        <ArrowLeft size={14} /> Back to users
      </Link>

      <PageHeading
        title={user.username}
        description={`User ID ${user.id} · registered ${dateStr(user.created_at)}`}
      />

      <PermissionNotice permission="users.manage" />

      <div className="flex flex-wrap gap-2 mb-4">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition ${
              tab === t ? 'bg-brand text-white' : 'bg-white text-muted border border-gray-200 hover:border-gray-300'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'Overview' && (
        <div className="grid lg:grid-cols-3 gap-4">
          <Card className="p-4 lg:col-span-2">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-text text-sm">Account</h2>
              <Badge color={user.status === 'Active' ? 'green' : user.status === 'Suspended' ? 'red' : 'amber'}>{user.status}</Badge>
            </div>
            <Row label="User ID" value={<span className="font-mono text-xs">{user.id}</span>} />
            <Row label="Membership" value={user.membership} />
            <Row label="Referral code" value={user.referral_code} />
            <Row label="Recharge" value={money(wallet.recharge_centavos)} />
            <Row label="Earnings" value={money(wallet.earnings_centavos)} />
            <Row label="Held for payouts" value={money(wallet.reserved_centavos)} />
            <Row label="Available" value={money(wallet.available_centavos)} />
            <Row label="Last sign-in" value={user.last_login ? dateTimeStr(user.last_login) : 'Never'} />
            <Row
              label="Welcome reward"
              value={welcomeReward ? `${money(welcomeReward.amount_centavos)} · ${dateStr(welcomeReward.issued_at)}` : 'Not issued'}
            />
          </Card>

          <Card className="p-4">
            <h2 className="font-bold text-text text-sm mb-3">Change status</h2>
            <TextArea
              label="Reason (recorded in the audit log)"
              value={statusReason}
              onChange={(e) => setStatusReason(e.target.value)}
              placeholder="Explain the change"
            />
            <div className="flex flex-col gap-2 mt-3">
              {user.status !== 'Active' && (
                <Button block loading={busy} onClick={() => changeStatus('Active')} icon={<CheckCircle2 size={15} />}>
                  Reactivate account
                </Button>
              )}
              {user.status !== 'Suspended' && (
                <Button block variant="danger" loading={busy} onClick={() => changeStatus('Suspended')} icon={<Ban size={15} />}>
                  Suspend account
                </Button>
              )}
              {user.status !== 'Restricted' && (
                <Button block variant="secondary" loading={busy} onClick={() => changeStatus('Restricted')}>
                  Restrict account
                </Button>
              )}
            </div>
            <p className="text-[10px] text-muted mt-3 leading-relaxed">
              Suspending or restricting signs the account out of every session immediately.
            </p>
          </Card>
        </div>
      )}

      {tab === 'Wallets' && (
        <Card className="p-4">
          <h2 className="font-bold text-text text-sm mb-3">Wallet detail</h2>
          <Row label="Recharge wallet (spendable on plans)" value={money(wallet.recharge_centavos)} />
          <Row label="Earnings wallet (ledger total)" value={money(wallet.earnings_centavos)} />
          <Row label="Reserved for pending payouts" value={money(wallet.reserved_centavos)} />
          <Row label="Available to withdraw" value={money(wallet.available_centavos)} />
          <Row label="Last movement" value={dateTimeStr(wallet.updated_at)} />
          <Link to={`/admin/adjustments?user=${user.id}`} className="inline-block mt-4 text-xs font-bold text-brand">
            Post a balance adjustment →
          </Link>
        </Card>
      )}

      {tab === 'Transactions' && (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-muted text-[11px]">
              <tr>
                <th className="text-left p-3">Reference</th>
                <th className="text-left p-3">Type</th>
                <th className="text-left p-3">Wallet</th>
                <th className="text-left p-3">Amount</th>
                <th className="text-left p-3">Balance after</th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Actor</th>
                <th className="text-left p-3">When</th>
              </tr>
            </thead>
            <tbody>
              {entries.length === 0 && <tr><td colSpan={8} className="p-8 text-center text-muted text-xs">No ledger entries for this account.</td></tr>}
              {entries.map((e) => (
                <tr key={e.id} className="border-t border-gray-100">
                  <td className="p-3 font-mono text-[10px]">{e.reference}</td>
                  <td className="p-3 text-xs">{e.kind}</td>
                  <td className="p-3 text-xs">{e.wallet}</td>
                  <td className={`p-3 font-bold text-xs ${e.direction === 'credit' ? 'text-emerald-600' : 'text-text'}`}>
                    {e.direction === 'credit' ? '+' : '−'}{e.wallet === 'points' ? e.amount_centavos : money(e.amount_centavos)}
                  </td>
                  <td className="p-3 text-xs">
                    {e.balance_after_centavos === null ? '—' : e.wallet === 'points' ? e.balance_after_centavos : money(e.balance_after_centavos)}
                  </td>
                  <td className="p-3"><Badge color={e.status === 'completed' ? 'green' : e.status === 'pending' ? 'amber' : 'gray'}>{e.status}</Badge></td>
                  <td className="p-3 text-xs text-muted">{e.actor_name ?? '—'}</td>
                  <td className="p-3 text-xs text-muted">{dateTimeStr(e.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {tab === 'Plans' && (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-muted text-[11px]">
              <tr>
                <th className="text-left p-3">Plan</th>
                <th className="text-left p-3">Version</th>
                <th className="text-left p-3">Amount</th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Period</th>
                <th className="text-left p-3">Source</th>
              </tr>
            </thead>
            <tbody>
              {plans.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-muted text-xs">No plans on this account.</td></tr>}
              {plans.map((p) => (
                <tr key={p.id} className="border-t border-gray-100">
                  <td className="p-3 font-semibold text-xs">{p.plan_name}</td>
                  <td className="p-3 text-xs">v{p.plan_version}</td>
                  <td className="p-3 text-xs">{money(p.amount_centavos)}</td>
                  <td className="p-3"><Badge color={p.status === 'active' ? 'green' : 'gray'}>{p.status}</Badge></td>
                  <td className="p-3 text-xs text-muted">{dateStr(p.start_date)} → {dateStr(p.end_date)}</td>
                  <td className="p-3 text-xs text-muted">{p.source}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {tab === 'Referrals' && (
        <Card className="p-4">
          <h2 className="font-bold text-text text-sm mb-3">Referrals made</h2>
          {referrals.length === 0 ? (
            <p className="text-xs text-muted py-4 text-center">This account has not referred anyone.</p>
          ) : (
            referrals.map((r) => (
              <Row key={r.id} label={r.username} value={`${dateStr(r.created_at)} · +${money(r.reward_centavos)}`} />
            ))
          )}
        </Card>
      )}

      {tab === 'Notes' && (
        <div className="grid lg:grid-cols-2 gap-4">
          <Card className="p-4">
            <h2 className="font-bold text-text text-sm mb-3">Add internal note</h2>
            <TextArea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Internal context for other staff" />
            <Button className="mt-3" block loading={busy} onClick={saveNote} icon={<StickyNote size={15} />}>Save note</Button>
            <p className="text-[10px] text-muted mt-2">Notes are visible to administrators only.</p>
          </Card>
          <Card className="p-4">
            <h2 className="font-bold text-text text-sm mb-3">Notes ({notes.length})</h2>
            {notes.length === 0 ? (
              <p className="text-xs text-muted py-4 text-center">No notes recorded.</p>
            ) : (
              notes.map((n) => (
                <div key={n.id} className="py-2 border-b border-gray-50 last:border-0">
                  <p className="text-xs text-text">{n.body}</p>
                  <p className="text-[10px] text-muted mt-0.5">{n.author_name} · {dateTimeStr(n.created_at)}</p>
                </div>
              ))
            )}
          </Card>
        </div>
      )}

      {tab === 'Audit' && (
        <div className="space-y-4">
          <Card className="p-4">
            <h2 className="font-bold text-text text-sm mb-3">Administrative actions on this account</h2>
            {auditTrail.length === 0 ? (
              <EmptyState title="No administrative actions recorded" />
            ) : (
              auditTrail.map((a) => (
                <div key={a.id} className="py-2 border-b border-gray-50 last:border-0">
                  <p className="text-xs font-semibold text-text">{a.action}</p>
                  <p className="text-[10px] text-muted">{a.actor_name} · {dateTimeStr(a.created_at)}</p>
                  {a.reason && <p className="text-[11px] text-muted mt-0.5">{a.reason}</p>}
                </div>
              ))
            )}
          </Card>
          {adjustments.length > 0 && (
            <Card className="p-4">
              <h2 className="font-bold text-text text-sm mb-3">Manual adjustments</h2>
              {adjustments.map((a) => (
                <Row
                  key={a.id}
                  label={`${a.direction === 'credit' ? '+' : '−'}${money(a.amount_centavos)} · ${a.reason ?? ''}`}
                  value={`${a.actor_name} · ${dateTimeStr(a.created_at)}`}
                />
              ))}
            </Card>
          )}
        </div>
      )}

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}