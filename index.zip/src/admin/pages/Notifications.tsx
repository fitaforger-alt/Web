import { useEffect, useState } from 'react'
import { Bell, Send } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select, TextArea } from '../../components/ui/Input'
import { dateTimeStr } from '../../utils/format'

export default function Notifications() {
  const { notifications, customers, sendNotification, loadNotifications, error } = useAdmin()
  const [audience, setAudience] = useState('broadcast')
  const [userId, setUserId] = useState('')
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [severity, setSeverity] = useState('info')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)

  useEffect(() => { void loadNotifications() }, [loadNotifications])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    setBusy(true)
    setNotice(null)
    try {
      await sendNotification({
        audience,
        userId: audience === 'user' ? userId : undefined,
        title,
        body,
        severity,
      })
      await loadNotifications()
      setTitle(''); setBody('')
      setNotice('Notification sent.')
    } catch {
      setNotice(null)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <PageHeading title="Notifications" description="Customer-facing messages. Deliveries appear in each account's inbox." />

      <PermissionNotice permission="support.manage" />

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-5">
          <h2 className="font-bold text-text text-sm mb-3 flex items-center gap-2">
            <Send size={15} className="text-brand" /> Send a notification
          </h2>
          <form onSubmit={submit} className="space-y-3">
            <Select label="Audience" value={audience} onChange={(e) => setAudience(e.target.value)}>
              <option value="broadcast">Everyone (broadcast)</option>
              <option value="user">A single customer</option>
            </Select>
            {audience === 'user' && (
              <Select label="Customer" value={userId} onChange={(e) => setUserId(e.target.value)}>
                <option value="">Select a customer</option>
                {customers.map((c) => <option key={c.id} value={c.id}>{c.username} — {c.id}</option>)}
              </Select>
            )}
            <Select label="Severity" value={severity} onChange={(e) => setSeverity(e.target.value)}>
              <option value="info">Info</option>
              <option value="success">Success</option>
              <option value="warning">Warning</option>
            </Select>
            <Input label="Title" value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={120} />
            <TextArea label="Message" value={body} onChange={(e) => setBody(e.target.value)} required />
            <Button type="submit" block loading={busy} disabled={audience === 'user' && !userId}>Send notification</Button>
          </form>
          {notice && <p className="text-xs text-emerald-700 mt-3">{notice}</p>}
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Bell size={15} className="text-muted" />
            <h2 className="font-bold text-text text-sm">Recent notifications</h2>
          </div>
          {notifications.length === 0 ? (
            <EmptyState title="No notifications sent" description="Messages you send appear here." />
          ) : (
            notifications.slice(0, 25).map((n) => (
              <div key={n.id} className="py-2 border-b border-gray-50 last:border-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-semibold text-text">{n.title}</p>
                  <Badge color={n.severity === 'warning' ? 'amber' : n.severity === 'success' ? 'green' : 'blue'}>
                    {n.audience === 'broadcast' ? 'broadcast' : n.username ?? 'user'}
                  </Badge>
                </div>
                <p className="text-[11px] text-muted mt-0.5">{n.body}</p>
                <p className="text-[10px] text-muted mt-0.5">{dateTimeStr(n.created_at)}</p>
              </div>
            ))
          )}
        </Card>
      </div>

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}