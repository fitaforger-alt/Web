import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import {
  Activity, AlertTriangle, ArrowDownToLine, ArrowUpFromLine, Gift, Package,
  RefreshCw, TrendingDown, TrendingUp, Users, Wallet,
} from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { money, dateTimeStr } from '../../utils/format'

export default function Overview() {
  const { overview, refresh, loading, paymentProviders } = useAdmin()

  useEffect(() => { void refresh() }, [refresh])

  if (!overview) {
    return (
      <div>
        <PageHeading title="Overview" />
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          {Array.from({ length: 10 }).map((_, i) => <div key={i} className="h-24 animate-pulse rounded-card bg-gray-100" />)}
        </div>
      </div>
    )
  }

  const c = overview.cards
  const cards = [
    { label: 'Registered users', value: c.users, icon: Users, to: '/admin/users' },
    { label: 'Active users', value: c.active_users, icon: Users, tone: 'text-emerald-600' },
    { label: 'Suspended / restricted', value: c.suspended_users, icon: AlertTriangle, tone: 'text-amber-600' },
    { label: 'Pending deposits', value: c.pending_deposits, icon: ArrowDownToLine, tone: 'text-amber-600', to: '/admin/deposits' },
    { label: 'Pending withdrawals', value: c.pending_withdrawals, icon: ArrowUpFromLine, tone: 'text-amber-600', to: '/admin/withdrawals' },
    { label: 'Active plans', value: c.active_plans, icon: Package, to: '/admin/plan-assignments' },
    { label: 'Deposits credited', value: money(c.total_deposits_centavos), icon: TrendingUp, tone: 'text-emerald-600' },
    { label: 'Withdrawals paid', value: money(c.total_withdrawals_centavos), icon: TrendingDown, tone: 'text-red-600' },
    { label: 'Welcome rewards issued', value: `${c.welcome_rewards_issued}`, icon: Gift, sub: money(c.welcome_rewards_value_centavos) },
    { label: 'Failed transactions', value: c.failed_transactions, icon: AlertTriangle, tone: c.failed_transactions > 0 ? 'text-red-600' : undefined },
  ]

  const maxVolume = Math.max(1, ...overview.daily.map((d) => Math.max(d.credits, d.debits)))

  return (
    <div>
      <PageHeading
        title="Overview"
        description="Every figure is queried from the live ledger and account tables."
        actions={<Button size="sm" variant="secondary" onClick={() => void refresh()} loading={loading} icon={<RefreshCw size={14} />}>Refresh</Button>}
      />

      <PermissionNotice permission="users.read" />

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-5">
        {cards.map((card) => {
          const body = (
            <Card className="p-4 h-full hover:shadow-md transition">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-[11px] text-muted leading-tight">{card.label}</p>
                  <p className={`font-extrabold text-text text-lg mt-1 truncate ${card.tone ?? ''}`}>{card.value}</p>
                  {card.sub && <p className="text-[10px] text-muted">{card.sub}</p>}
                </div>
                <card.icon size={18} className="text-muted shrink-0" />
              </div>
            </Card>
          )
          return card.to ? <Link key={card.label} to={card.to}>{body}</Link> : <div key={card.label}>{body}</div>
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mb-5">
        <Card className="p-4 lg:col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <Activity size={15} className="text-muted" />
            <h2 className="font-bold text-text text-sm">Ledger flow — last 30 days</h2>
          </div>
          {overview.daily.length === 0 ? (
            <EmptyState title="No ledger activity" description="Credits and debits appear here as they are recorded." />
          ) : (
            <div className="space-y-1.5">
              {overview.daily.slice(-14).map((d) => (
                <div key={d.day} className="flex items-center gap-2">
                  <span className="text-[10px] text-muted w-16 shrink-0">{d.day.slice(5)}</span>
                  <div className="flex-1 flex items-center gap-1 h-4">
                    <div className="h-full bg-emerald-500 rounded-sm" style={{ width: `${(d.credits / maxVolume) * 100}%` }} title={`Credits ${money(d.credits)}`} />
                    <div className="h-full bg-brand rounded-sm" style={{ width: `${(d.debits / maxVolume) * 100}%` }} title={`Debits ${money(d.debits)}`} />
                  </div>
                  <span className="text-[10px] text-muted w-16 text-right shrink-0">{d.entries} entries</span>
                </div>
              ))}
              <div className="flex gap-4 pt-2 text-[10px] text-muted">
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-emerald-500 rounded-sm" /> Credits</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-brand rounded-sm" /> Debits</span>
              </div>
            </div>
          )}
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Wallet size={15} className="text-muted" />
            <h2 className="font-bold text-text text-sm">Customer funds</h2>
          </div>
          <div className="space-y-2.5 text-sm">
            <div>
              <p className="text-[11px] text-muted">Recharge wallet</p>
              <p className="font-bold text-text">{money(c.wallet_recharge_centavos)}</p>
            </div>
            <div>
              <p className="text-[11px] text-muted">Earnings wallet</p>
              <p className="font-bold text-text">{money(c.wallet_earnings_centavos)}</p>
            </div>
            <div>
              <p className="text-[11px] text-muted">Held for pending payouts</p>
              <p className="font-bold text-amber-700">{money(c.wallet_reserved_centavos)}</p>
            </div>
            <div className="pt-2 border-t border-gray-100">
              <p className="text-[11px] text-muted">Total customer balance</p>
              <p className="font-extrabold text-text text-lg">{money(c.wallet_liabilities_centavos)}</p>
            </div>
          </div>
          <p className="text-[10px] text-muted mt-3 leading-relaxed">
            This is money held for customers. It is a liability of the platform, not revenue or profit.
          </p>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <h2 className="font-bold text-text text-sm mb-3">Payment providers</h2>
          <div className="space-y-2">
            {paymentProviders.length === 0 && <p className="text-xs text-muted">No providers configured.</p>}
            {paymentProviders.map((p) => (
              <div key={p.id} className="flex items-center justify-between gap-2">
                <div>
                  <p className="text-xs font-semibold text-text">{p.label}</p>
                  <p className="text-[10px] text-muted">{p.reason ?? `Mode: ${p.mode}`}</p>
                </div>
                <Badge color={p.enabled ? 'green' : 'gray'}>{p.enabled ? p.mode : 'disabled'}</Badge>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-muted mt-3 leading-relaxed">
            While a provider is disabled, customers cannot submit deposits against it and no simulated payment can be
            presented as real.
          </p>
        </Card>

        <Card className="p-4">
          <h2 className="font-bold text-text text-sm mb-3">Recent administrative activity</h2>
          {overview.recent_audit.length === 0 ? (
            <p className="text-xs text-muted py-4 text-center">No activity recorded yet.</p>
          ) : (
            overview.recent_audit.slice(0, 10).map((a) => (
              <div key={a.id} className="flex items-start justify-between gap-2 py-2 border-b border-gray-50 last:border-0">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-text">{a.action}</p>
                  <p className="text-[10px] text-muted truncate">{a.actor_name} · {a.target_type}:{a.target_id ?? '—'}</p>
                </div>
                <span className="text-[10px] text-muted shrink-0">{dateTimeStr(a.created_at)}</span>
              </div>
            ))
          )}
        </Card>
      </div>
    </div>
  )
}