import { useEffect, useState } from 'react'
import { CheckCircle2, CreditCard, Search, ShieldQuestion } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select } from '../../components/ui/Input'
import { money, dateTimeStr } from '../../utils/format'

export default function Deposits() {
  const { deposits, loadDeposits, reviewDeposit, paymentProviders, error } = useAdmin()
  const [status, setStatus] = useState('')
  const [ref, setRef] = useState('')
  const [busyId, setBusyId] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)

  useEffect(() => { void loadDeposits() }, [loadDeposits])

  const rows = deposits.filter((d) =>
    (!status || d.status === status)
    && (ref === '' || d.reference.toLowerCase().includes(ref.toLowerCase()) || (d.username ?? '').toLowerCase().includes(ref.toLowerCase())))

  const act = async (id: string, action: 'verify' | 'reject' | 'under_review', reason?: string) => {
    setBusyId(id)
    setNotice(null)
    try {
      await reviewDeposit(id, action, reason)
      await loadDeposits()
      setNotice(action === 'verify'
        ? 'Deposit verified against the provider and credited.'
        : action === 'reject' ? 'Deposit rejected.' : 'Deposit moved to under review.')
    } catch {
      setNotice(null)
    } finally {
      setBusyId(null)
    }
  }

  return (
    <div>
      <PageHeading
        title="Deposits"
        description="A wallet is credited only from a signed provider callback or a provider API reconciliation."
      />

      <PermissionNotice permission="deposits.review" />

      <Card className="p-4 mb-4 bg-blue-50/50 border-blue-100">
        <div className="flex items-start gap-2">
          <ShieldQuestion size={16} className="text-blue-600 shrink-0 mt-0.5" />
          <div className="text-xs text-blue-900 leading-relaxed">
            <p className="font-bold mb-1">There is no approve button by design.</p>
            <p>
              "Verify against provider" calls the payment provider API for this reference and credits the wallet only if
              the provider reports the payment settled with a matching amount. A screenshot never credits funds.
            </p>
            <div className="flex flex-wrap gap-2 mt-2">
              {paymentProviders.map((p) => (
                <Badge key={p.id} color={p.enabled ? 'green' : 'gray'}>
                  {p.label}: {p.enabled ? p.mode : 'not connected'}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-4 flex flex-col lg:flex-row gap-3 mb-4">
        <Input placeholder="Filter by reference or username" value={ref} onChange={(e) => setRef(e.target.value)} />
        <Select value={status} onChange={(e) => setStatus(e.target.value)} className="lg:w-56">
          <option value="">All statuses</option>
          <option value="pending">Pending</option>
          <option value="under_review">Under review</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="failed">Failed</option>
        </Select>
      </Card>

      {notice && <Card className="p-3 mb-4 bg-emerald-50 border-emerald-100 text-xs text-emerald-800">{notice}</Card>}

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">Reference</th>
              <th className="text-left p-3">User</th>
              <th className="text-left p-3">Amount</th>
              <th className="text-left p-3">Method</th>
              <th className="text-left p-3">Provider ref</th>
              <th className="text-left p-3">Verification</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Submitted</th>
              <th className="text-left p-3">Reviewed</th>
              <th className="text-left p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={10} className="p-8 text-center text-muted text-xs">No deposit requests available.</td></tr>
            )}
            {rows.map((d) => (
              <tr key={d.id} className="border-t border-gray-100">
                <td className="p-3 font-mono text-[10px]">{d.reference}</td>
                <td className="p-3 text-xs font-semibold">{d.username ?? d.user_id}</td>
                <td className="p-3 font-bold text-xs">{money(d.amount_centavos)}</td>
                <td className="p-3 text-xs">{d.method}</td>
                <td className="p-3 font-mono text-[10px]">{d.provider_reference ?? '—'}</td>
                <td className="p-3">
                  <Badge color={d.verification_state === 'unverified' ? 'gray' : 'green'}>
                    {d.verification_state.replace(/_/g, ' ')}
                  </Badge>
                </td>
                <td className="p-3">
                  <Badge color={d.status === 'approved' ? 'green' : d.status === 'rejected' ? 'red' : d.status === 'failed' ? 'red' : 'amber'}>
                    {d.status.replace('_', ' ')}
                  </Badge>
                </td>
                <td className="p-3 text-xs text-muted">{dateTimeStr(d.submitted_at)}</td>
                <td className="p-3 text-xs text-muted">
                  {d.reviewer_name ? `${d.reviewer_name} · ${dateTimeStr(d.reviewed_at ?? d.submitted_at)}` : '—'}
                </td>
                <td className="p-3">
                  <div className="flex flex-col gap-1.5">
                    {d.status === 'pending' && (
                      <Button size="sm" variant="secondary" loading={busyId === d.id} onClick={() => void act(d.id, 'under_review')} icon={<Search size={12} />}>
                        Take for review
                      </Button>
                    )}
                    {(d.status === 'pending' || d.status === 'under_review') && (
                      <>
                        <Button size="sm" loading={busyId === d.id} onClick={() => void act(d.id, 'verify')} icon={<CheckCircle2 size={12} />}>
                          Verify with provider
                        </Button>
                        <Button size="sm" variant="danger" loading={busyId === d.id} onClick={() => {
                          const reason = window.prompt('Reason for rejecting this deposit (recorded in the audit log):')
                          if (reason && reason.trim().length >= 4) void act(d.id, 'reject', reason.trim())
                        }}>
                          Reject
                        </Button>
                      </>
                    )}
                    {d.status === 'approved' && (
                      <span className="text-[10px] text-emerald-700 flex items-center gap-1">
                        <CreditCard size={11} /> Credited to wallet
                      </span>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {deposits.length === 0 && (
        <EmptyState icon={<CreditCard size={22} />} title="No deposits yet" description="Requests appear here once a customer submits one." />
      )}

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}