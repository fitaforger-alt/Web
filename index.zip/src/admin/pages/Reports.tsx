import { useEffect, useState } from 'react'
import { BarChart3, Download } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input from '../../components/ui/Input'
import { API_ORIGIN } from '../../lib/api'
import { money } from '../../utils/format'

const REPORTS = [
  { kind: 'deposits', label: 'Deposits' },
  { kind: 'withdrawals', label: 'Withdrawals' },
  { kind: 'liabilities', label: 'Wallet liabilities' },
  { kind: 'plans', label: 'Plans' },
  { kind: 'welcome_rewards', label: 'Welcome rewards' },
  { kind: 'failures', label: 'Failed and reversed entries' },
  { kind: 'adjustments', label: 'Manual adjustments' },
  { kind: 'provider_reconciliation', label: 'Provider reconciliation' },
  { kind: 'admin_activity', label: 'Administrative activity' },
]

export default function Reports() {
  const { report, error } = useAdmin()
  const [kind, setKind] = useState('deposits')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [rows, setRows] = useState<Record<string, unknown>[]>([])
  const [loading, setLoading] = useState(false)

  const load = async (nextKind = kind, nextFrom = from, nextTo = to) => {
    setLoading(true)
    try {
      const res = await report(nextKind, nextFrom || undefined, nextTo || undefined)
      setRows(res.rows)
    } catch {
      setRows([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { void load() }, [report])

  const exportUrl = () => {
    const params = new URLSearchParams()
    if (from) params.set('from', new Date(from).toISOString())
    if (to) params.set('to', new Date(`${to}T23:59:59`).toISOString())
    return `${API_ORIGIN}/api/admin/reports/${kind}/export.csv?${params}`
  }

  const columns = rows.length > 0 ? Object.keys(rows[0]) : []

  return (
    <div>
      <PageHeading title="Reports" description="Real records filtered by date. Exports are audited." />

      <PermissionNotice permission="ledger.read" />

      <Card className="p-4 grid grid-cols-1 lg:grid-cols-4 gap-3 mb-4">
        <select
          value={kind}
          onChange={(e) => { setKind(e.target.value); void load(e.target.value) }}
          className="rounded-xl border border-gray-200 px-4 py-3 text-sm text-text bg-white"
        >
          {REPORTS.map((r) => <option key={r.kind} value={r.kind}>{r.label}</option>)}
        </select>
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From" />
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To" />
        <div className="flex gap-2">
          <Button onClick={() => void load()} loading={loading}>Run report</Button>
          <a href={exportUrl()} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border border-brand/30 text-brand hover:bg-red-50">
            <Download size={14} /> CSV
          </a>
        </div>
      </Card>

      <Card className="p-4 mb-4 flex items-center justify-between">
        <p className="text-xs text-muted">{rows.length} record{rows.length === 1 ? '' : 's'}</p>
        <Badge color="gray">{kind.replace('_', ' ')}</Badge>
      </Card>

      {rows.length === 0 ? (
        <EmptyState
          icon={<BarChart3 size={22} />}
          title="No records for this report"
          description="Nothing was recorded in the selected period. The export is unavailable because there is nothing to export."
        />
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-muted text-[11px]">
              <tr>{columns.map((c) => <th key={c} className="text-left p-3 whitespace-nowrap">{c}</th>)}</tr>
            </thead>
            <tbody>
              {rows.slice(0, 200).map((row, i) => (
                <tr key={i} className="border-t border-gray-100">
                  {columns.map((c) => (
                    <td key={c} className="p-3 text-xs whitespace-nowrap">
                      {typeof row[c] === 'number' && row[c] > 1000
                        ? money(Number(row[c]))
                        : String(row[c] ?? '—')}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
          {rows.length > 200 && (
            <p className="p-3 text-[11px] text-muted">Showing the first 200 rows. Use the CSV export for the full set.</p>
          )}
        </Card>
      )}

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}