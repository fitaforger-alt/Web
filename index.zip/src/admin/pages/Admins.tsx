import { useEffect, useState } from 'react'
import { Plus, Shield } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select } from '../../components/ui/Input'
import { dateStr } from '../../utils/format'

const BLANK = { username: '', displayName: '', password: '', role: 'AUDITOR', reason: 'New administrator' }

export default function Admins() {
  const { admins, roles, loadAdmins, createAdmin, updateAdmin, error } = useAdmin()
  const [form, setForm] = useState({ ...BLANK })
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)

  useEffect(() => { void loadAdmins() }, [loadAdmins])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    setBusy(true)
    setNotice(null)
    try {
      await createAdmin(form)
      setForm({ ...BLANK })
      await loadAdmins()
      setNotice(`Administrator "${form.username}" provisioned.`)
    } catch {
      setNotice(null)
    } finally {
      setBusy(false)
    }
  }

  const change = async (id: string, patch: Record<string, unknown>) => {
    const reason = window.prompt('Reason for this change (recorded in the audit log):')
    if (!reason || reason.trim().length < 4) return
    try {
      await updateAdmin(id, { ...patch, reason: reason.trim() })
      await loadAdmins()
      setNotice('Administrator updated.')
    } catch {
      setNotice(null)
    }
  }

  return (
    <div>
      <PageHeading title="Administrators" description="Staff accounts are provisioned here or from the server console. There is no public sign-up." />

      <PermissionNotice permission="admin.manage" />

      {notice && <Card className="p-3 mb-4 bg-emerald-50 border-emerald-100 text-xs text-emerald-800">{notice}</Card>}

      <div className="grid lg:grid-cols-3 gap-4 mb-5">
        <Card className="p-5">
          <h2 className="font-bold text-text text-sm mb-3 flex items-center gap-2">
            <Plus size={15} className="text-brand" /> Provision an administrator
          </h2>
          <form onSubmit={submit} className="space-y-3">
            <Input label="Username" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} required />
            <Input label="Display name" value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} />
            <Input label="Password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} hint="At least 8 characters with a letter and a number." required />
            <Select label="Role" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              {roles.map((r) => <option key={r.name} value={r.name}>{r.name.replace('_', ' ')}</option>)}
            </Select>
            <Button type="submit" block loading={busy}>Create administrator</Button>
          </form>
        </Card>

        <Card className="p-4 lg:col-span-2 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-muted text-[11px]">
              <tr>
                <th className="text-left p-3">Administrator</th>
                <th className="text-left p-3">Role</th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Last sign-in</th>
                <th className="text-left p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {admins.length === 0 && (
                <tr><td colSpan={5} className="p-8 text-center text-muted text-xs">No administrator accounts loaded.</td></tr>
              )}
              {admins.map((a) => (
                <tr key={a.id} className="border-t border-gray-100">
                  <td className="p-3">
                    <div className="font-semibold text-text">{a.display_name}</div>
                    <div className="text-[10px] text-muted">{a.username}</div>
                  </td>
                  <td className="p-3">
                    <Badge color={a.role === 'SUPER_ADMIN' ? 'red' : a.role === 'FINANCE_ADMIN' ? 'blue' : a.role === 'AUDITOR' ? 'gray' : 'violet'}>
                      {a.role.replace('_', ' ')}
                    </Badge>
                  </td>
                  <td className="p-3"><Badge color={a.status === 'Active' ? 'green' : 'gray'}>{a.status}</Badge></td>
                  <td className="p-3 text-[10px] text-muted">{a.last_login ? dateStr(a.last_login) : 'Never'}</td>
                  <td className="p-3">
                    <div className="flex flex-col gap-1.5">
                      <select
                        className="text-xs rounded-lg border border-gray-200 px-2 py-1"
                        value={a.role}
                        onChange={(e) => void change(a.id, { role: e.target.value })}
                      >
                        {roles.map((r) => <option key={r.name} value={r.name}>{r.name.replace('_', ' ')}</option>)}
                      </select>
                      <Button size="sm" variant="secondary" onClick={() => void change(a.id, { status: a.status === 'Active' ? 'Disabled' : 'Active' })}>
                        {a.status === 'Active' ? 'Disable' : 'Enable'}
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <h2 className="font-bold text-text text-sm mb-3 flex items-center gap-2">
            <Shield size={15} className="text-brand" /> Roles and what they can do
          </h2>
          {roles.map((r) => (
            <div key={r.name} className="py-2 border-b border-gray-50 last:border-0">
              <p className="text-xs font-bold text-text">{r.name.replace('_', ' ')}</p>
              <p className="text-[11px] text-muted">{r.description}</p>
              <div className="flex flex-wrap gap-1 mt-1">
                {r.permissions.length === 0 && <span className="text-[10px] text-muted">Full access</span>}
                {r.permissions.slice(0, 6).map((p) => <Badge key={p} color="gray">{p}</Badge>)}
                {r.permissions.length > 6 && <span className="text-[10px] text-muted">+{r.permissions.length - 6} more</span>}
              </div>
            </div>
          ))}
        </Card>

        <Card className="p-4">
          <h2 className="font-bold text-text text-sm mb-2">Enforcement</h2>
          <ul className="text-xs text-muted space-y-1.5 list-disc pl-4 leading-relaxed">
            <li>Permissions are checked on the server for every admin endpoint, not only hidden in the interface.</li>
            <li>Support admins cannot post adjustments or approve payouts.</li>
            <li>Auditors are read-only across financial records and audit history.</li>
            <li>Plan managers control product definitions without balance access.</li>
            <li>The last active super administrator cannot be demoted or disabled.</li>
            <li>Every change here is written to the audit trail with its reason.</li>
          </ul>
        </Card>
      </div>

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}