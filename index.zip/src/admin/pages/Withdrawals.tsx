import { useEffect, useState } from 'react'
import { CheckCircle2, ShieldCheck, Users2 } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input from '../../components/ui/Input'
import { money, dateTimeStr } from '../../utils/format'

export default function Withdrawals() {
  const { withdrawals, loadWithdrawals, decideWithdrawal, error } = useAdmin()
  const [status, setStatus] = useState('')
  const [busyId, setBusyId] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [paidRef, setPaidRef] = useState<Record<string, string>>({})

  useEffect(() => { void loadWithdrawals() }, [loadWithdrawals])

  const rows = withdrawals.filter((w) => !status || w.status === status)

  const act = async (id: string, payload: Record<string, unknown>, successMessage: string) => {
    setBusyId(id)
    setNotice(null)
    try {
      await decideWithdrawal(id, payload)
      await loadWithdrawals()
      setNotice(successMessage)
    } catch {
      setNotice(null)
    } finally {
      setBusyId(null)
    }
  }

  return (
    <div>
      <PageHeading
        title="Withdrawals"
        description="Funds are held from the moment a request is made. Approval only moves a request to processing."
      />

      <PermissionNotice permission="withdrawals.review" />

      <Card className="p-4 mb-4 bg-amber-50/50 border-amber-100">
        <div className="flex items-start gap-2 text-xs text-amber-900 leading-relaxed">
          <ShieldCheck size={16} className="text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold mb-1">Approval is not payment.</p>
            <p>
              Approving reserves the request for processing. It only reaches Completed once a payout reference and
              confirmation note are recorded, and that payout is what debits the customer wallet.
            </p>
          </div>
        </div>
      </Card>

      <Card className="p-4 mb-4">
        <div className="flex gap-2 flex-wrap">
          {['', 'pending', 'under_review', 'processing', 'completed', 'rejected', 'failed'].map((s) => (
            <button
              key={s || 'all'}
              onClick={() => setStatus(s)}
              className={`px-3 py-1.5 rounded-full text-[11px] font-bold transition ${
                status === s ? 'bg-brand text-white' : 'bg-gray-100 text-muted hover:bg-gray-200'
              }`}
            >
              {s === '' ? 'All' : s.replace('_', ' ')}
            </button>
          ))}
        </div>
      </Card>

      {notice && <Card className="p-3 mb-4 bg-emerald-50 border-emerald-100 text-xs text-emerald-800">{notice}</Card>}

      {rows.length === 0 ? (
        <EmptyState icon={<Users2 size={22} />} title="No withdrawal requests" description="Requests appear here as customers submit them." />
      ) : (
        <div className="space-y-3">
          {rows.map((w) => (
            <Card key={w.id} className="p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-extrabold text-text text-lg">{money(w.net_centavos)}</p>
                    <Badge color={w.status === 'completed' ? 'green' : w.status === 'rejected' || w.status === 'failed' ? 'red' : 'amber'}>
                      {w.status.replace('_', ' ')}
                    </Badge>
                    {w.requires_second_approval === 1 && (
                      <Badge color="violet">two-person rule</Badge>
                    )}
                  </div>
                  <p className="text-[11px] text-muted mt-1">
                    <span className="font-mono">{w.reference}</span> · {w.username ?? w.user_id} · {w.destination_masked}
                  </p>
                  <p className="text-[11px] text-muted">
                    Requested {dateTimeStr(w.created_at)} · fee {money(w.fee_centavos)} · gross {money(w.amount_centavos)}
                  </p>
                  {w.payout_reference && (
                    <p className="text-[11px] text-emerald-700 mt-1">
                      Paid {dateTimeStr(w.paid_at ?? w.created_at)} · ref {w.payout_reference}
                    </p>
                  )}
                </div>

                <div className="flex flex-col gap-2 w-full sm:w-auto sm:min-w-[240px]">
                  {(w.status === 'pending' || w.status === 'under_review') && (
                    <>
                      <Button
                        size="sm"
                        loading={busyId === w.id}
                        icon={<CheckCircle2 size={13} />}
                        onClick={() => {
                          const reason = window.prompt('Approval reason (recorded in the audit log):')
                          if (reason && reason.trim().length >= 4) {
                            void act(w.id, { action: 'approve', reason: reason.trim() }, 'Request approved and moved to processing.')
                          }
                        }}
                      >
                        Approve for processing
                      </Button>
                      <Button
                        size="sm"
                        variant="danger"
                        loading={busyId === w.id}
                        onClick={() => {
                          const reason = window.prompt('Rejection reason (recorded in the audit log):')
                          if (reason && reason.trim().length >= 4) {
                            void act(w.id, { action: 'reject', reason: reason.trim() }, 'Request rejected and the held funds released.')
                          }
                        }}
                      >
                        Reject and release
                      </Button>
                    </>
                  )}

                  {w.status === 'processing' && (
                    <div className="space-y-2">
                      <Input
                        placeholder="Payout reference"
                        value={paidRef[w.id] ?? ''}
                        onChange={(e) => setPaidRef((prev) => ({ ...prev, [w.id]: e.target.value }))}
                      />
                      <Button
                        size="sm"
                        block
                        loading={busyId === w.id}
                        onClick={() => {
                          const proof = window.prompt('How was the payout confirmed? (provider reference check or remittance detail)')
                          if (proof && proof.trim().length >= 8) {
                            void act(
                              w.id,
                              { action: 'mark_paid', payoutReference: (paidRef[w.id] ?? '').trim(), proof: proof.trim() },
                              'Payout recorded. The ledger entry was written and the audit log updated.',
                            )
                          }
                        }}
                      >
                        Confirm payout completed
                      </Button>
                      <Button
                        size="sm"
                        variant="secondary"
                        block
                        loading={busyId === w.id}
                        onClick={() => {
                          const reason = window.prompt('Why did the payout fail? The held funds are released.')
                          if (reason && reason.trim().length >= 4) {
                            void act(w.id, { action: 'mark_failed', reason: reason.trim() }, 'Marked failed and the held funds released.')
                          }
                        }}
                      >
                        Payout failed — release funds
                      </Button>
                    </div>
                  )}

                  {(w.reviews?.length ?? 0) > 0 && (
                    <details className="text-[10px] text-muted">
                      <summary className="cursor-pointer font-bold">Review history</summary>
                      <div className="mt-1 space-y-1">
                        {w.reviews!.map((r) => (
                          <div key={r.id}>
                            <span className="font-semibold text-text">{r.admin_name}</span> · {r.action} · {dateTimeStr(r.created_at)}
                            <p className="text-muted">{r.reason}</p>
                          </div>
                        ))}
                      </div>
                    </details>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}