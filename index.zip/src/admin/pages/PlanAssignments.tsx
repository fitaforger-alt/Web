import { useEffect, useState } from 'react'
import { ClipboardList } from 'lucide-react'
import { useAdmin } from '../AdminContext'
import { PageHeading, PermissionNotice } from '../AdminLayout'
import Card, { Badge, EmptyState } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input, { Select, TextArea } from '../../components/ui/Input'
import { money, dateStr } from '../../utils/format'

export default function PlanAssignments() {
  const { customers, plans, userPlans, assignPlan, setPlanAssignmentStatus, refresh, error } = useAdmin()
  const [userId, setUserId] = useState('')
  const [planId, setPlanId] = useState('')
  const [reason, setReason] = useState('')
  const [debit, setDebit] = useState(false)
  const [startDate, setStartDate] = useState('')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)
  const [filter, setFilter] = useState('')

  useEffect(() => {
    if (!userId && customers.length > 0) setUserId(customers[0].id)
    if (!planId && plans.length > 0) setPlanId(plans[0].id)
  }, [customers, plans, userId, planId])

  const selectedUser = customers.find((c) => c.id === userId)
  const selectedPlan = plans.find((p) => p.id === planId)

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!selectedUser || !selectedPlan) return
    setBusy(true)
    setNotice(null)
    try {
      await assignPlan({
        userId,
        planId,
        reason,
        debitCustomer: debit,
        startDate: startDate || undefined,
      })
      await refresh()
      setNotice(`${selectedPlan.name} assigned to ${selectedUser.username}.`)
      setReason('')
    } catch {
      setNotice(null)
    } finally {
      setBusy(false)
    }
  }

  const rows = userPlans.filter((p) => !filter || p.status === filter)

  return (
    <div>
      <PageHeading title="Plan assignments" description="Assign an existing product to a customer. The assignment appears on their account immediately." />

      <PermissionNotice permission="plans.assign" />

      <div className="grid lg:grid-cols-2 gap-4 mb-5">
        <Card className="p-5">
          <h2 className="font-bold text-text text-sm mb-3">Assign a plan</h2>
          <form onSubmit={submit} className="space-y-3">
            <Select label="Customer" value={userId} onChange={(e) => setUserId(e.target.value)}>
              {customers.map((c) => <option key={c.id} value={c.id}>{c.username} — {c.id}</option>)}
            </Select>
            <Select label="Product" value={planId} onChange={(e) => setPlanId(e.target.value)}>
              {plans.filter((p) => !p.archived).map((p) => <option key={p.id} value={p.id}>{p.name} — {money(p.price_centavos)}</option>)}
            </Select>

            {selectedUser && selectedPlan && (
              <Card className="p-3 bg-gray-50">
                <p className="text-[11px] font-bold text-text mb-1">Confirm before assigning</p>
                <p className="text-[11px] text-muted">Customer: {selectedUser.username} ({selectedUser.id})</p>
                <p className="text-[11px] text-muted">Product: {selectedPlan.name} · {money(selectedPlan.price_centavos)} · {selectedPlan.duration_days} days</p>
                <p className="text-[11px] text-muted">
                  Recharge balance: {money(selectedUser.recharge_centavos)}
                  {debit ? ' — this amount will be debited' : ' — no charge will be made'}
                </p>
                <p className="text-[11px] text-muted">Terms version v{selectedPlan.current_version}</p>
              </Card>
            )}

            <Input label="Start date (optional)" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
            <label className="flex items-center gap-2 text-xs text-text">
              <input type="checkbox" checked={debit} onChange={(e) => setDebit(e.target.checked)} className="w-4 h-4 rounded border-gray-300" />
              Debit the customer's recharge wallet for the plan price
            </label>
            <TextArea label="Reason (recorded in the audit log)" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Why is this plan being assigned?" />
            <Button type="submit" block loading={busy} disabled={!selectedUser || !selectedPlan || reason.trim().length < 4}>
              Assign plan
            </Button>
          </form>
        </Card>

        <Card className="p-4">
          <h2 className="font-bold text-text text-sm mb-2">What happens on assignment</h2>
          <ul className="text-xs text-muted space-y-1.5 list-disc pl-4 leading-relaxed">
            <li>A user plan record is created with the product's current terms snapshot.</li>
            <li>When charging the customer, the debit is written through the ledger with the administrator as actor.</li>
            <li>When granting it free, a matching credit entry records the grant and its reason.</li>
            <li>The customer sees the plan on their account and in My Plans on their next request.</li>
            <li>Historical terms on existing plans are never rewritten.</li>
          </ul>
        </Card>
      </div>

      {notice && <Card className="p-3 mb-4 bg-emerald-50 border-emerald-100 text-xs text-emerald-800">{notice}</Card>}

      <div className="flex gap-2 flex-wrap mb-4">
        {['', 'active', 'paused', 'completed', 'cancelled', 'expired'].map((s) => (
          <button
            key={s || 'all'}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-[11px] font-bold transition ${
              filter === s ? 'bg-brand text-white' : 'bg-white text-muted border border-gray-200'
            }`}
          >
            {s === '' ? 'All' : s}
          </button>
        ))}
      </div>

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-muted text-[11px]">
            <tr>
              <th className="text-left p-3">Customer</th>
              <th className="text-left p-3">Plan</th>
              <th className="text-left p-3">Amount</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Period</th>
              <th className="text-left p-3">Source</th>
              <th className="text-left p-3">Progress</th>
              <th className="text-left p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={8} className="p-8 text-center text-muted text-xs">No plan assignments yet.</td></tr>
            )}
            {rows.map((p) => (
              <tr key={p.id} className="border-t border-gray-100">
                <td className="p-3 text-xs font-semibold">{p.username ?? p.user_id}</td>
                <td className="p-3 text-xs">{p.plan_name} <span className="text-muted">v{p.plan_version}</span></td>
                <td className="p-3 text-xs">{money(p.amount_centavos)}</td>
                <td className="p-3"><Badge color={p.status === 'active' ? 'green' : p.status === 'cancelled' ? 'red' : 'gray'}>{p.status}</Badge></td>
                <td className="p-3 text-[10px] text-muted">{dateStr(p.start_date)} → {dateStr(p.end_date)}</td>
                <td className="p-3 text-[10px] text-muted">{p.source}</td>
                <td className="p-3 text-[10px] text-muted">{p.progress_percent}%</td>
                <td className="p-3">
                  {p.status === 'active' && (
                    <div className="flex gap-1.5">
                      <Button size="sm" variant="secondary" onClick={() => {
                        const why = window.prompt('Reason for pausing this plan:')
                        if (why && why.trim().length >= 4) void setPlanAssignmentStatus(p.id, 'paused', why.trim())
                      }}>Pause</Button>
                      <Button size="sm" variant="danger" onClick={() => {
                        const why = window.prompt('Reason for cancelling this plan:')
                        if (why && why.trim().length >= 4) void setPlanAssignmentStatus(p.id, 'cancelled', why.trim())
                      }}>Cancel</Button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {userPlans.length === 0 && (
        <EmptyState icon={<ClipboardList size={22} />} title="No plan assignments yet" description="Assigned plans appear here and on the customer's account." />
      )}

      {error && <p className="text-xs text-red-500 mt-4">{error}</p>}
    </div>
  )
}