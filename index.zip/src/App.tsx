import { Navigate, Route, Routes } from 'react-router-dom'
import { AppStateProvider } from './context/AppState'
import { AdminProvider } from './admin/AdminContext'
import AppShell, { RequireAuth } from './components/layout/AppShell'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import Products from './pages/Products'
import ProductDetail from './pages/ProductDetail'
import MyPlans from './pages/MyPlans'
import PlanDetail from './pages/PlanDetail'
import Wallet from './pages/Wallet'
import Recharge from './pages/Recharge'
import Withdraw from './pages/Withdraw'
import Withdrawals from './pages/Withdrawals'
import BankCard from './pages/BankCard'
import News from './pages/News'
import Article from './pages/Article'
import Tasks from './pages/Tasks'
import CheckIn from './pages/CheckIn'
import RewardsWheel from './pages/RewardsWheel'
import Redeem from './pages/Redeem'
import Share from './pages/Share'
import Team from './pages/Team'
import Profile from './pages/Profile'
import Records from './pages/Records'
import Messages from './pages/Messages'
import FAQ from './pages/FAQ'
import Security from './pages/Security'
import About from './pages/About'
import Help from './pages/Help'

import AdminLayout from './admin/AdminLayout'
import AdminLogin from './admin/LoginPage'
import AdminOverview from './admin/pages/Overview'
import AdminUsers from './admin/pages/Users'
import AdminUserDetail from './admin/pages/UserDetail'
import AdminDeposits from './admin/pages/Deposits'
import AdminWithdrawals from './admin/pages/Withdrawals'
import AdminTransactions from './admin/pages/Transactions'
import AdminAdjustments from './admin/pages/Adjustments'
import AdminApprovals from './admin/pages/Approvals'
import AdminPlans from './admin/pages/Plans'
import AdminPlanAssignments from './admin/pages/PlanAssignments'
import AdminPlanSettlements from './admin/pages/PlanSettlements'
import AdminRewards from './admin/pages/Rewards'
import AdminReferrals from './admin/pages/Referrals'
import AdminNotifications from './admin/pages/Notifications'
import AdminSupport from './admin/pages/Support'
import AdminReports from './admin/pages/Reports'
import AdminAudit from './admin/pages/Audit'
import AdminAdmins from './admin/pages/Admins'
import AdminSettings from './admin/pages/Settings'

/** Customer pages that need a signed-in session. */
const protectedRoute = (element: React.ReactElement) => <RequireAuth>{element}</RequireAuth>

export default function App() {
  return (
    <AdminProvider>
      <AppStateProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          <Route path="/" element={<AppShell><Home /></AppShell>} />
          <Route path="/products" element={<AppShell><Products /></AppShell>} />
          <Route path="/products/:id" element={<AppShell><ProductDetail /></AppShell>} />
          <Route path="/news" element={<AppShell><News /></AppShell>} />
          <Route path="/news/:id" element={<AppShell><Article /></AppShell>} />
          <Route path="/faq" element={<AppShell><FAQ /></AppShell>} />
          <Route path="/about" element={<AppShell><About /></AppShell>} />
          <Route path="/help" element={<AppShell><Help /></AppShell>} />
          <Route path="/profile" element={<AppShell><Profile /></AppShell>} />

          <Route path="/wallet" element={<AppShell>{protectedRoute(<Wallet />)}</AppShell>} />
          <Route path="/recharge" element={<AppShell>{protectedRoute(<Recharge />)}</AppShell>} />
          <Route path="/withdraw" element={<AppShell>{protectedRoute(<Withdraw />)}</AppShell>} />
          <Route path="/withdrawals" element={<AppShell>{protectedRoute(<Withdrawals />)}</AppShell>} />
          <Route path="/bank-card" element={<AppShell>{protectedRoute(<BankCard />)}</AppShell>} />
          <Route path="/records" element={<AppShell>{protectedRoute(<Records />)}</AppShell>} />
          <Route path="/plans" element={<AppShell>{protectedRoute(<MyPlans />)}</AppShell>} />
          <Route path="/plans/:id" element={<AppShell>{protectedRoute(<PlanDetail />)}</AppShell>} />
          <Route path="/tasks" element={<AppShell>{protectedRoute(<Tasks />)}</AppShell>} />
          <Route path="/checkin" element={<AppShell>{protectedRoute(<CheckIn />)}</AppShell>} />
          <Route path="/wheel" element={<AppShell>{protectedRoute(<RewardsWheel />)}</AppShell>} />
          <Route path="/redeem" element={<AppShell>{protectedRoute(<Redeem />)}</AppShell>} />
          <Route path="/share" element={<AppShell>{protectedRoute(<Share />)}</AppShell>} />
          <Route path="/team" element={<AppShell>{protectedRoute(<Team />)}</AppShell>} />
          <Route path="/security" element={<AppShell>{protectedRoute(<Security />)}</AppShell>} />
          <Route path="/messages" element={<AppShell>{protectedRoute(<Messages />)}</AppShell>} />

          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminOverview />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="users/:id" element={<AdminUserDetail />} />
            <Route path="deposits" element={<AdminDeposits />} />
            <Route path="withdrawals" element={<AdminWithdrawals />} />
            <Route path="transactions" element={<AdminTransactions />} />
            <Route path="adjustments" element={<AdminAdjustments />} />
            <Route path="approvals" element={<AdminApprovals />} />
            <Route path="plans" element={<AdminPlans />} />
            <Route path="plan-assignments" element={<AdminPlanAssignments />} />
            <Route path="plan-settlements" element={<AdminPlanSettlements />} />
            <Route path="rewards" element={<AdminRewards />} />
            <Route path="referrals" element={<AdminReferrals />} />
            <Route path="notifications" element={<AdminNotifications />} />
            <Route path="support" element={<AdminSupport />} />
            <Route path="reports" element={<AdminReports />} />
            <Route path="audit" element={<AdminAudit />} />
            <Route path="admins" element={<AdminAdmins />} />
            <Route path="settings" element={<AdminSettings />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AppStateProvider>
    </AdminProvider>
  )
}