import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Bell, ChevronLeft, LogIn } from 'lucide-react'
import { useApp } from '../../context/AppState'

interface Props {
  title: string
  subtitle?: string
  right?: React.ReactNode
  back?: boolean
}

export default function PageHeader({ title, subtitle, right, back = true }: Props) {
  const nav = useNavigate()
  const location = useLocation()
  const app = useApp()
  const [showNotifications, setShowNotifications] = useState(false)

  const showBack = back && location.pathname !== '/' && location.pathname !== '/products' && location.pathname !== '/news' && location.pathname !== '/profile'

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-30">
      <div className="flex items-center gap-3 px-4 h-14">
        {showBack ? (
          <button onClick={() => nav(-1)} className="p-2 -ml-2 rounded-full hover:bg-gray-100 active:scale-95" aria-label="Go back">
            <ChevronLeft size={20} className="text-text" />
          </button>
        ) : (
          <Link to="/" className="w-9 h-9 rounded-xl bg-brand text-white flex items-center justify-center font-black text-lg shrink-0">
            D
          </Link>
        )}

        <div className="flex-1 min-w-0">
          <h1 className="text-base font-extrabold text-text leading-tight truncate">{title}</h1>
          {subtitle && <p className="text-[11px] text-muted truncate">{subtitle}</p>}
        </div>

        {right ?? (
          <div className="flex items-center gap-1">
            {app.authenticated ? (
              <button onClick={() => { setShowNotifications((v) => !v); void app.loadNotifications() }} className="relative p-2 rounded-full hover:bg-gray-100" aria-label="Notifications">
                <Bell size={19} className="text-text" />
                {app.unread > 0 && (
                  <span className="absolute top-1 right-1 min-w-4 h-4 px-1 bg-brand text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                    {app.unread > 99 ? '99+' : app.unread}
                  </span>
                )}
              </button>
            ) : (
              <Link to="/login" className="flex items-center gap-1.5 text-xs font-bold text-brand px-3 py-2 rounded-lg hover:bg-red-50">
                <LogIn size={14} /> Sign in
              </Link>
            )}
          </div>
        )}
      </div>

      {showNotifications && (
        <div className="border-t border-gray-100 max-h-72 overflow-y-auto">
          {app.notifications.length === 0 ? (
            <p className="text-xs text-muted text-center py-6">No notifications.</p>
          ) : (
            app.notifications.slice(0, 12).map((n) => (
              <button
                key={n.id}
                onClick={() => { void app.markNotificationRead(n.id); if (n.action_url) nav(n.action_url); setShowNotifications(false) }}
                className={`w-full text-left px-4 py-3 border-b border-gray-50 last:border-0 hover:bg-gray-50 ${n.read_at ? '' : 'bg-red-50/40'}`}
              >
                <div className="flex items-center gap-2">
                  {!n.read_at && <span className="w-1.5 h-1.5 rounded-full bg-brand shrink-0" />}
                  <span className="text-xs font-bold text-text">{n.title}</span>
                </div>
                <p className="text-[11px] text-muted mt-0.5 leading-snug">{n.body}</p>
              </button>
            ))
          )}
        </div>
      )}
    </header>
  )
}