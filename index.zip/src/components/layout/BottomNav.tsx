import { useEffect, useState } from 'react'
import { NavLink, useLocation, useNavigate } from 'react-router-dom'
import { Car, Home, LogIn, Newspaper, User } from 'lucide-react'
import { useApp } from '../../context/AppState'

const TABS = [
  { to: '/', icon: Home, label: 'Home', auth: false },
  { to: '/products', icon: Car, label: 'Products', auth: false },
  { to: '/news', icon: Newspaper, label: 'News', auth: false },
  { to: '/profile', icon: User, label: 'Profile', auth: true },
]

export default function BottomNav() {
  const { authenticated } = useApp()
  const location = useLocation()
  const navigate = useNavigate()
  const [visible, setVisible] = useState(true)

  // The nav hides while the keyboard is open on a mobile form so it does not
  // cover the field being typed into.
  useEffect(() => {
    const onResize = () => setVisible(window.innerHeight > 480)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const hiddenByRoute = /^\/(login|register|admin)/.test(location.pathname)

  return (
    <nav
      className={`fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[520px] md:max-w-[980px] bg-white/95 backdrop-blur border-t border-gray-100 z-40 safe-bottom transition-transform duration-200 ${
        visible && !hiddenByRoute ? 'translate-y-0' : 'translate-y-full'
      }`}
    >
      <div className="flex justify-around items-center h-16 px-2">
        {TABS.map(({ to, icon: Icon, label, auth }) => {
          if (auth && !authenticated) {
            return (
              <button
                key={to}
                onClick={() => navigate('/login', { state: { from: to } })}
                className="flex flex-col items-center gap-1 text-[11px] font-medium px-3 py-1 text-muted"
              >
                <Icon size={22} />
                <span>{label}</span>
              </button>
            )
          }
          return (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 text-[11px] font-semibold px-3 py-1 rounded-lg transition ${
                  isActive ? 'text-brand' : 'text-muted hover:text-text'
                }`
              }
            >
              <Icon size={22} />
              <span>{label}</span>
            </NavLink>
          )
        })}
        {!authenticated && (
          <NavLink
            to="/login"
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 text-[11px] font-semibold px-3 py-1 rounded-lg transition ${
                isActive ? 'text-brand' : 'text-muted'
              }`
            }
          >
            <LogIn size={22} />
            <span>Sign in</span>
          </NavLink>
        )}
      </div>
    </nav>
  )
}