import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { Loader2 } from 'lucide-react'
import { useApp } from '../../context/AppState'
import BottomNav from './BottomNav'
import Toasts from '../ui/Toasts'
import ConfirmModal from '../ui/ConfirmModal'
import WelcomeModal from '../ui/WelcomeModal'

const PUBLIC_ROUTES = ['/', '/products', '/news', '/login', '/register', '/faq', '/about', '/help']

export default function AppShell({ children }: { children: React.ReactNode }) {
  const { ready, settings } = useApp()
  const location = useLocation()

  if (!ready) {
    return (
      <div className="min-h-screen grid place-items-center bg-bg">
        <Loader2 className="animate-spin text-brand" size={28} />
      </div>
    )
  }

  if (settings?.maintenance_mode && !PUBLIC_ROUTES.includes(location.pathname)) {
    return (
      <div className="min-h-screen grid place-items-center bg-bg px-6">
        <div className="text-center">
          <div className="w-14 h-14 rounded-2xl bg-brand/10 text-brand grid place-items-center mx-auto mb-3">🚧</div>
          <h1 className="font-extrabold text-text">DriveVest is under maintenance</h1>
          <p className="text-sm text-muted mt-2">{settings.maintenance_message}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-bg">
      <div className="mx-auto w-full max-w-[520px] md:max-w-[980px] min-h-screen relative pb-24">
        {children}
        <BottomNav />
      </div>
      <Toasts />
      <ConfirmModal />
      <WelcomeModal />
    </div>
  )
}

/** Guards customer pages that need a session and re-renders on session change. */
export function RequireAuth({ children }: { children: React.ReactElement }) {
  const { ready, authenticated } = useApp()
  const location = useLocation()

  if (!ready) {
    return (
      <div className="min-h-screen grid place-items-center bg-bg">
        <Loader2 className="animate-spin text-brand" size={28} />
      </div>
    )
  }
  if (!authenticated) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />
  }
  return children
}

/** Renders the routed page inside the phone-width shell. */
export function ShellOutlet() {
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  )
}