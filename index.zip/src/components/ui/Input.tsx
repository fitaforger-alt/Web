import { useState, type InputHTMLAttributes, type ReactNode } from 'react'
import { Eye, EyeOff } from 'lucide-react'

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  hint?: string
  trailing?: ReactNode
}

export default function Input({ label, error, hint, trailing, className = '', type = 'text', ...rest }: Props) {
  const [revealed, setRevealed] = useState(false)
  const isPassword = type === 'password'
  const inputType = isPassword && revealed ? 'text' : type

  return (
    <div className="w-full">
      {label && <label className="block text-xs font-semibold text-muted mb-1.5">{label}</label>}
      <div className="relative">
        <input
          type={inputType}
          className={`w-full rounded-xl border ${error ? 'border-red-400' : 'border-gray-200'} bg-white px-4 py-3 text-sm text-text placeholder:text-muted/70 focus:outline-none focus:ring-2 focus:ring-brand/30 transition ${isPassword ? 'pr-11' : ''} ${className}`}
          aria-invalid={error ? true : undefined}
          {...rest}
        />
        {isPassword && (
          <button
            type="button"
            onClick={() => setRevealed((v) => !v)}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg text-muted hover:text-text transition"
            aria-label={revealed ? 'Hide password' : 'Show password'}
          >
            {revealed ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        )}
        {trailing && <div className="absolute right-2 top-1/2 -translate-y-1/2">{trailing}</div>}
      </div>
      {error && <p className="text-xs text-red-500 mt-1.5">{error}</p>}
      {!error && hint && <p className="text-xs text-muted mt-1.5">{hint}</p>}
    </div>
  )
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string
  children: ReactNode
}

export function Select({ label, children, className = '', ...rest }: SelectProps) {
  return (
    <div className="w-full">
      {label && <label className="block text-xs font-semibold text-muted mb-1.5">{label}</label>}
      <select
        className={`w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-text focus:outline-none focus:ring-2 focus:ring-brand/30 ${className}`}
        {...rest}
      >
        {children}
      </select>
    </div>
  )
}

interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string
  error?: string
}

export function TextArea({ label, error, className = '', ...rest }: TextAreaProps) {
  return (
    <div className="w-full">
      {label && <label className="block text-xs font-semibold text-muted mb-1.5">{label}</label>}
      <textarea
        className={`w-full rounded-xl border ${error ? 'border-red-400' : 'border-gray-200'} bg-white px-4 py-3 text-sm text-text focus:outline-none focus:ring-2 focus:ring-brand/30 min-h-[96px] ${className}`}
        {...rest}
      />
      {error && <p className="text-xs text-red-500 mt-1.5">{error}</p>}
    </div>
  )
}