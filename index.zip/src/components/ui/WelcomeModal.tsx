import { useNavigate } from 'react-router-dom'
import { Gift, Sparkles, Wallet as WalletIcon } from 'lucide-react'
import { useApp } from '../../context/AppState'
import { money } from '../../utils/format'
import Card from './Card'
import Button from './Button'

/**
 * Shown only after the server has committed the welcome-reward ledger entry.
 * A refresh or a later sign-in never re-opens it.
 */
export default function WelcomeModal() {
  const app = useApp()
  const nav = useNavigate()
  const reward = app.welcomeReward
  if (!reward?.granted) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#20283A]/55 px-6 backdrop-blur-[2px]">
      <Card className="p-7 w-full max-w-sm text-center relative overflow-hidden">
        <div className="absolute -top-16 -right-16 w-40 h-40 rounded-full bg-brand/10" />
        <div className="absolute -bottom-20 -left-16 w-44 h-44 rounded-full bg-brand/5" />

        <div className="relative">
          <div className="w-20 h-20 rounded-3xl bg-brand/10 flex items-center justify-center mx-auto mb-4">
            <Gift size={34} className="text-brand" />
          </div>

          <div className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-brand bg-brand/10 rounded-full px-2.5 py-1">
            <Sparkles size={11} /> Welcome reward credited
          </div>

          <h2 className="font-extrabold text-text text-2xl mt-3">Congratulations!</h2>
          <p className="text-sm text-muted mt-2 leading-relaxed">
            You&apos;ve received {money(reward.amount_centavos)} in welcome rewards! Your starting balance has been
            credited successfully. Welcome to DriveVest!
          </p>

          <div className="mt-5 py-4 rounded-2xl bg-brand text-white shadow-lg">
            <div className="text-2xl font-extrabold tracking-tight">{money(reward.amount_centavos)}</div>
            <div className="text-[11px] opacity-90 mt-0.5">
              {reward.withdrawable ? 'Withdrawable once earned' : 'Promotional credit'}
            </div>
          </div>

          {reward.note && <p className="text-[11px] text-muted mt-3 leading-relaxed">{reward.note}</p>}
          {reward.transaction_reference && (
            <p className="text-[10px] text-muted/80 mt-2 break-all">Reference {reward.transaction_reference}</p>
          )}

          <div className="flex gap-2 mt-5">
            <Button
              className="flex-1"
              icon={<WalletIcon size={16} />}
              onClick={() => { app.consumeWelcomeReward(); nav('/wallet') }}
            >
              View My Wallet
            </Button>
            <Button className="flex-1" variant="secondary" onClick={() => { app.consumeWelcomeReward(); nav('/products') }}>
              Get Started
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}