import type { HTMLAttributes } from 'react'

export default function Card({ className = '', children, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={`bg-white rounded-card border border-gray-100 shadow-[0_1px_2px_rgba(32,40,58,0.04),0_8px_24px_-16px_rgba(32,40,58,0.18)] ${className}`}
      {...rest}
    >
      {children}
    </div>
  )
}

interface BadgeProps {
  children: React.ReactNode
  color?: 'red' | 'green' | 'amber' | 'blue' | 'gray' | 'violet'
  className?: string
}

const BADGE_COLORS = {
  red: 'bg-red-50 text-brand',
  green: 'bg-emerald-50 text-emerald-700',
  amber: 'bg-amber-50 text-amber-700',
  blue: 'bg-blue-50 text-blue-700',
  gray: 'bg-gray-100 text-muted',
  violet: 'bg-violet-50 text-violet-700',
}

export function Badge({ children, color = 'gray', className = '' }: BadgeProps) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${BADGE_COLORS[color]} ${className}`}>
      {children}
    </span>
  )
}

interface EmptyStateProps {
  title: string
  description?: string
  action?: React.ReactNode
  icon?: React.ReactNode
}

export function EmptyState({ title, description, action, icon }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-12 px-6">
      {icon && <div className="w-14 h-14 rounded-2xl bg-gray-100 text-muted flex items-center justify-center mb-3">{icon}</div>}
      <p className="font-semibold text-text text-sm">{title}</p>
      {description && <p className="text-xs text-muted mt-1 max-w-xs">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

interface SkeletonProps {
  className?: string
}

export function Skeleton({ className = 'h-16' }: SkeletonProps) {
  return <div className={`animate-pulse rounded-xl bg-gray-100 ${className}`} />
}

interface RowProps {
  label: string
  value: React.ReactNode
  className?: string
}

export function Row({ label, value, className = '' }: RowProps) {
  return (
    <div className={`flex items-center justify-between gap-4 py-2 text-sm ${className}`}>
      <span className="text-muted shrink-0">{label}</span>
      <span className="font-semibold text-text text-right break-words">{value}</span>
    </div>
  )
}

interface ErrorStateProps {
  message: string
  onRetry?: () => void
}

export function ErrorState({ message, onRetry }: ErrorStateProps) {
  return (
    <Card className="p-5 border-red-100 bg-red-50/40">
      <p className="text-sm font-semibold text-red-700">Something went wrong</p>
      <p className="text-xs text-red-600/90 mt-1">{message}</p>
      <p className="text-[11px] text-red-600/70 mt-2">
        No balance was changed. Your figures stay exactly as last confirmed.
      </p>
      {onRetry && (
        <button onClick={onRetry} className="mt-3 text-xs font-bold text-red-700 underline">
          Try again
        </button>
      )}
    </Card>
  )
}