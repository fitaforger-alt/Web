import { CheckCircle2, Info, XCircle } from 'lucide-react'
import { useApp } from '../../context/AppState'

const STYLES = {
  success: { wrap: 'bg-emerald-600', Icon: CheckCircle2 },
  error: { wrap: 'bg-red-600', Icon: XCircle },
  info: { wrap: 'bg-[#20283A]', Icon: Info },
}

export default function Toasts() {
  const { toasts, dismissToast } = useApp()
  if (toasts.length === 0) return null

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[60] flex flex-col gap-2 w-[92%] max-w-sm pointer-events-none">
      {toasts.map((toast) => {
        const { wrap, Icon } = STYLES[toast.type]
        return (
          <button
            key={toast.id}
            onClick={() => dismissToast(toast.id)}
            className={`pointer-events-auto flex items-start gap-2.5 px-4 py-3 rounded-xl shadow-lg text-white text-left ${wrap}`}
          >
            <Icon size={16} className="mt-0.5 shrink-0" />
            <span className="text-sm font-medium leading-snug">{toast.msg}</span>
          </button>
        )
      })}
    </div>
  )
}