import type { ButtonHTMLAttributes, ReactNode } from 'react'

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'dark'
  loading?: boolean
  size?: 'sm' | 'md' | 'lg'
  block?: boolean
  icon?: ReactNode
}

export default function Button({
  variant = 'primary', loading, size = 'md', block, icon, children, className = '', disabled, ...rest
}: Props) {
  const base =
    'inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40'
  const sizes = {
    sm: 'text-xs px-3 py-2',
    md: 'text-sm px-4 py-3',
    lg: 'text-sm px-6 py-3.5',
  }[size]
  const styles = {
    primary: 'bg-brand text-white hover:bg-brand-dark shadow-sm',
    secondary: 'bg-white text-brand border border-brand/30 hover:bg-red-50',
    ghost: 'bg-transparent text-text hover:bg-gray-100',
    danger: 'bg-red-600 text-white hover:bg-red-700',
    dark: 'bg-[#20283A] text-white hover:bg-[#171D2B]',
  }[variant]

  return (
    <button
      className={`${base} ${sizes} ${styles} ${block ? 'w-full' : ''} ${className}`}
      disabled={disabled || loading}
      {...rest}
    >
      {loading && <span className="w-4 h-4 border-2 border-current/30 border-t-current rounded-full animate-spin" />}
      {icon}
      {children}
    </button>
  )
}