import { useState } from 'react'
import { useApp } from '../../context/AppState'
import Card from './Card'
import Button from './Button'

export default function ConfirmModal() {
  const { confirm, closeConfirm } = useApp()
  const [busy, setBusy] = useState(false)
  if (!confirm.open) return null

  const run = async () => {
    setBusy(true)
    try {
      await confirm.onConfirm?.()
    } finally {
      setBusy(false)
      closeConfirm()
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#20283A]/55 px-6 backdrop-blur-[2px]">
      <Card className="p-6 w-full max-w-sm">
        <h3 className="font-extrabold text-text text-base">{confirm.title}</h3>
        <p className="text-sm text-muted mt-2 leading-relaxed whitespace-pre-line">{confirm.message}</p>
        <div className="flex gap-2 mt-6">
          <Button variant="ghost" block onClick={closeConfirm} disabled={busy}>Cancel</Button>
          <Button
            block
            variant={confirm.tone === 'danger' ? 'danger' : 'primary'}
            loading={busy}
            onClick={run}
          >
            {confirm.confirmLabel}
          </Button>
        </div>
      </Card>
    </div>
  )
}