'use strict'
/** Customer-facing API. Every balance here comes from the ledger. */
const express = require('express')
const db = require('../db')
const auth = require('../lib/auth')
const ledger = require('../lib/ledger')
const audit = require('../lib/audit')
const plans = require('../lib/plans')
const userPlans = require('../lib/userPlans')
const deposits = require('../lib/deposits')
const withdrawals = require('../lib/withdrawals')
const engagement = require('../lib/engagement')
const payments = require('../providers/payments')
const { limitBySubject } = require('../lib/ratelimit')
const {
  asyncRoute, fail, id, now, toCentavos, today, maskAccount,
  getBoolSetting, getSetting, allSettings, getIntSetting,
} = require('../lib/util')

const router = express.Router()
const requireUser = auth.requireUser()

const moneyMutation = limitBySubject('money', 30, 60_000)

/* ------------------------------------------------------------------ profile */

router.get('/me', requireUser, asyncRoute((req, res) => {
  const user = req.user
  const welcome = db.prepare('SELECT * FROM welcome_rewards WHERE user_id = ?').get(user.id)
  res.json({
    user: {
      id: user.id,
      username: user.username,
      status: user.status,
      membership: user.membership,
      referral_code: user.referral_code,
      created_at: user.created_at,
      last_login: user.last_login,
    },
    wallet: ledger.walletSummary(user.id),
    welcomeReward: welcome
      ? { granted: true, amount_centavos: welcome.amount_centavos, issued_at: welcome.issued_at, status: welcome.status }
      : { granted: false, amount_centavos: 0 },
    unread: engagement.unreadCount(user.id),
    restrictions: {
      welcome_reward_note: getSetting('welcome_reward_note', ''),
      welcome_reward_withdrawable: getBoolSetting('welcome_reward_withdrawable', true),
      points_note: 'Points are promotional credits. They are not withdrawable cash.',
    },
  })
}))

router.get('/dashboard', requireUser, asyncRoute((req, res) => {
  const userId = req.user.id
  // Credit any daily income that has come due, so the home screen is never
  // stale relative to the settlement sweep.
  userPlans.settleDue()
  const wallet = ledger.walletSummary(userId)
  const { total: txCount } = ledger.entriesForUser(userId, { limit: 1 })
  const activePlans = db.prepare("SELECT COUNT(*) c FROM user_plans WHERE user_id = ? AND status = 'active'").get(userId).c
  const referralTotal = db.prepare('SELECT COUNT(*) c FROM referrals WHERE referrer_id = ?').get(userId).c
  const lastCheckin = db.prepare('SELECT checkin_date FROM checkins WHERE user_id = ? ORDER BY checkin_date DESC LIMIT 1').get(userId)
  return res.json({
    wallet,
    stats: {
      transactions: txCount,
      active_plans: activePlans,
      referrals: referralTotal,
      checkin_streak: engagement.checkinStreak(userId),
      checked_in_today: lastCheckin?.checkin_date === today(),
    },
    unread: engagement.unreadCount(userId),
  })
}))

/* ------------------------------------------------------------------- ledger */

router.get('/wallet', requireUser, asyncRoute((req, res) => {
  res.json(ledger.walletSummary(req.user.id))
}))

router.get('/transactions', requireUser, asyncRoute((req, res) => {
  const limit = Math.min(Number(req.query.limit) || 50, 200)
  const offset = Math.max(Number(req.query.offset) || 0, 0)
  const { total, rows } = ledger.entriesForUser(req.user.id, {
    limit,
    offset,
    wallet: req.query.wallet,
    kind: req.query.kind,
  })
  res.json({ total, rows, limit, offset })
}))

/* ------------------------------------------------------------------- plans */

router.get('/plans', asyncRoute((req, res) => {
  res.json(plans.listPublic())
}))

router.get('/plans/:id', asyncRoute((req, res) => {
  const plan = db.prepare('SELECT * FROM plans WHERE id = ? AND archived = 0').get(req.params.id)
  if (!plan) fail(404, 'plan_not_found', 'That product is no longer available.')
  res.json({
    ...plan,
    slots_remaining: plan.slots_total > 0 ? Math.max(0, plan.slots_total - plan.slots_taken) : null,
    versions: plans.versions(plan.id).map((v) => ({ version: v.version, created_at: v.created_at, change_reason: v.change_reason })),
  })
}))

router.get('/user-plans', requireUser, asyncRoute((req, res) => {
  // Settle first so the page shows income that has actually been credited.
  userPlans.settleDue()
  res.json(userPlans.forUser(req.user.id).map(userPlans.decorate))
}))

router.get('/user-plans/:id/settlements', requireUser, asyncRoute((req, res) => {
  const plan = db.prepare('SELECT * FROM user_plans WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id)
  if (!plan) fail(404, 'plan_not_found', 'Plan not found on your account.')
  res.json({
    plan: userPlans.decorate(plan),
    duration_days: userPlans.durationOf(plan),
    days_completed: plan.days_completed,
    daily_income_centavos: plan.projected_daily_centavos,
    total_income_centavos: plan.days_completed * plan.projected_daily_centavos,
    next_settlement_at: userPlans.nextSettlementAt(plan),
    rows: userPlans.settlementsFor(plan.id),
  })
}))

router.post('/user-plans/purchase', requireUser, moneyMutation, asyncRoute((req, res) => {
  const { planId } = req.body || {}
  const idempotencyKey = req.get('x-idempotency-key') || null
  const result = userPlans.purchase({
    userId: req.user.id,
    planId,
    idempotencyKey,
    correlationId: req.correlationId,
  })
  audit.record(req, {
    action: 'plan.purchase',
    targetType: 'plan',
    targetId: planId,
    reason: `${result.userPlan.plan_name} activated`,
    after: { user_plan_id: result.userPlan.id, amount_centavos: result.userPlan.amount_centavos },
    transactionReference: result.entry.reference,
  })
  res.status(201).json({ userPlan: userPlans.decorate(result.userPlan), transaction: result.entry })
}))

/* --------------------------------------------------------------- destinations */

router.get('/payout-destinations', requireUser, asyncRoute((req, res) => {
  res.json(db.prepare('SELECT id, holder_name, provider, masked, verified, created_at FROM payout_destinations WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id))
}))

router.post('/payout-destinations', requireUser, moneyMutation, asyncRoute((req, res) => {
  const { holderName, provider, accountNumber } = req.body || {}
  const holder = String(holderName || '').trim()
  if (holder.length < 2 || holder.length > 80) fail(400, 'invalid_holder', 'Enter the account holder name as it appears on your account.')
  if (!['GCash', 'Maya', 'Bank'].includes(provider)) fail(400, 'invalid_provider', 'Choose a payout provider.')
  const account = String(accountNumber || '').replace(/\D/g, '')
  if (!/^\d{10,16}$/.test(account)) fail(400, 'invalid_account', 'Enter a valid account number.')

  const duplicate = db.prepare('SELECT id FROM payout_destinations WHERE user_id = ? AND provider = ? AND account_number = ?')
    .get(req.user.id, provider, account)
  if (duplicate) fail(409, 'duplicate_destination', 'That destination is already saved.')

  const destId = id('dst')
  db.prepare(`
    INSERT INTO payout_destinations (id, user_id, holder_name, provider, account_number, masked, verified, created_at)
    VALUES (?,?,?,?,?,?,0,?)
  `).run(destId, req.user.id, holder, provider, account, `${provider} ${maskAccount(account)}`, now())

  res.status(201).json({ id: destId, holder_name: holder, provider, masked: `${provider} ${maskAccount(account)}`, verified: 0 })
}))

router.delete('/payout-destinations/:id', requireUser, asyncRoute((req, res) => {
  const pending = db.prepare(
    "SELECT COUNT(*) c FROM withdrawals WHERE destination_id = ? AND status IN ('pending','under_review','processing')",
  ).get(req.params.id).c
  if (pending > 0) fail(409, 'destination_in_use', 'This destination has a withdrawal in progress.')
  db.prepare('DELETE FROM payout_destinations WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id)
  res.json({ ok: true })
}))

/* ---------------------------------------------------------------- deposits */

router.get('/deposits/methods', asyncRoute((req, res) => {
  res.json({
    methods: payments.catalogue(),
    presets: [20000, 50000, 120000, 300000, 500000, 1000000, 2500000, 5000000],
    min_centavos: getIntSetting('min_deposit_centavos', 10000),
    max_centavos: getIntSetting('max_deposit_centavos', 50000000),
    note: payments.catalogue().some((m) => m.enabled)
      ? 'Deposits are credited only after the provider confirms your payment.'
      : 'No payment provider is connected to this server yet, so deposits cannot be submitted. Nothing is charged.',
  })
}))

router.get('/deposits', requireUser, asyncRoute((req, res) => {
  const { total, rows } = deposits.listDeposits({ userId: req.user.id, limit: 50 })
  res.json({ total, rows })
}))

router.post('/deposits', requireUser, moneyMutation, asyncRoute((req, res) => {
  const { amount, method, providerReference } = req.body || {}
  if (!payments.isEnabled(method)) {
    fail(409, 'provider_unavailable',
      `${method} is not connected to this server yet, so no deposit can be submitted. Nothing has been charged.`)
  }
  const amountCentavos = toCentavos(amount)
  const deposit = deposits.createDepositRequest({
    userId: req.user.id,
    amountCentavos,
    method: String(method).toUpperCase(),
    providerReference: providerReference ? String(providerReference).trim() : null,
    idempotencyKey: req.get('x-idempotency-key') || null,
  })
  audit.record(req, {
    action: 'deposit.requested',
    targetType: 'deposit',
    targetId: deposit.id,
    reason: `Deposit request ${deposit.reference}`,
    after: { amount_centavos: deposit.amount_centavos, method: deposit.method },
    transactionReference: deposit.reference,
  })
  res.status(201).json({ deposit })
}))

/* ------------------------------------------------------------- withdrawals */

router.get('/withdrawals', requireUser, asyncRoute((req, res) => {
  const { total, rows } = withdrawals.listWithdrawals({ userId: req.user.id, limit: 50 })
  res.json({
    total,
    rows,
    limits: {
      min_centavos: getIntSetting('min_withdrawal_centavos', 10000),
      fee_centavos: getIntSetting('withdrawal_fee_centavos', 0),
      fee_percent: getIntSetting('withdrawal_fee_percent', 0),
      daily_limit_centavos: getIntSetting('daily_withdrawal_limit_centavos', 0),
    },
  })
}))

router.post('/withdrawals', requireUser, moneyMutation, asyncRoute((req, res) => {
  const { amount, destinationId } = req.body || {}
  const withdrawal = withdrawals.createRequest({
    userId: req.user.id,
    amountCentavos: toCentavos(amount),
    destinationId,
    idempotencyKey: req.get('x-idempotency-key') || null,
    correlationId: req.correlationId,
    actor: { type: 'user', id: req.user.id, name: req.user.username },
  })
  audit.record(req, {
    action: 'withdrawal.requested',
    targetType: 'withdrawal',
    targetId: withdrawal.id,
    reason: `Withdrawal request ${withdrawal.reference}`,
    after: { amount_centavos: withdrawal.amount_centavos, net_centavos: withdrawal.net_centavos },
    transactionReference: withdrawal.reference,
  })
  res.status(201).json({ withdrawal })
}))

/* ------------------------------------------------------- tasks / engagement */

router.get('/tasks', requireUser, asyncRoute((req, res) => {
  res.json(engagement.listTasks(req.user.id))
}))

router.post('/tasks/:id/claim', requireUser, moneyMutation, asyncRoute((req, res) => {
  const result = engagement.claimTask(req.user.id, req.params.id, { correlationId: req.correlationId })
  res.json({ task: result.task, entry: result.entry })
}))

router.get('/checkin', requireUser, asyncRoute((req, res) => {
  const last = db.prepare('SELECT checkin_date FROM checkins WHERE user_id = ? ORDER BY checkin_date DESC LIMIT 1').get(req.user.id)
  res.json({
    streak: engagement.checkinStreak(req.user.id),
    last_checkin: last?.checkin_date || null,
    checked_in_today: last?.checkin_date === today(),
    reward_centavos: engagement.checkinRewardCentavos(),
    wallet: 'earnings',
  })
}))

router.post('/checkin', requireUser, moneyMutation, asyncRoute((req, res) => {
  const result = engagement.checkin(req.user.id, { correlationId: req.correlationId })
  res.json(result)
}))

router.get('/wheel', requireUser, asyncRoute((req, res) => {
  const todaySpin = db.prepare('SELECT * FROM wheel_spins WHERE user_id = ? AND spin_date = ?').get(req.user.id, today())
  res.json({
    rules: engagement.wheelRules(),
    spun_today: !!todaySpin,
    today_result: todaySpin ? { outcome: todaySpin.outcome, points: todaySpin.points } : null,
    history: db.prepare('SELECT outcome, points, created_at FROM wheel_spins WHERE user_id = ? ORDER BY created_at DESC LIMIT 10').all(req.user.id),
  })
}))

router.post('/wheel/spin', requireUser, moneyMutation, asyncRoute((req, res) => {
  const result = engagement.spin(req.user.id, { correlationId: req.correlationId })
  res.json(result)
}))

router.get('/redemptions', requireUser, asyncRoute((req, res) => {
  res.json(engagement.redemptionsFor(req.user.id))
}))

router.post('/redemptions', requireUser, moneyMutation, asyncRoute((req, res) => {
  const result = engagement.redeem(req.user.id, req.body?.code, { correlationId: req.correlationId })
  res.json({ code: result.code.code, entry: result.entry })
}))

/* ------------------------------------------------------------ notifications */

router.get('/notifications', requireUser, asyncRoute((req, res) => {
  res.json({ unread: engagement.unreadCount(req.user.id), rows: engagement.notificationsFor(req.user.id) })
}))

router.post('/notifications/:id/read', requireUser, asyncRoute((req, res) => {
  db.prepare("UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ?").run(now(), req.params.id, req.user.id)
  res.json({ unread: engagement.unreadCount(req.user.id) })
}))

/* -------------------------------------------------------------- referrals */

router.get('/referrals', requireUser, asyncRoute((req, res) => {
  const rows = db.prepare(`
    SELECT r.id, r.level, r.code_used, r.reward_centavos, r.status, r.created_at, u.username
    FROM referrals r JOIN users u ON u.id = r.referred_id
    WHERE r.referrer_id = ? ORDER BY r.created_at DESC
  `).all(req.user.id)
  const bonusEarned = rows.reduce((a, r) => a + r.reward_centavos, 0)
  return res.json({
    code: req.user.referral_code,
    link: `/register?ref=${req.user.referral_code}`,
    total: rows.length,
    bonus_earned_centavos: bonusEarned,
    terms: getSetting('referral_terms', 'A one-time bonus is credited when someone registers with your code. Referral activity is not guaranteed income.'),
    rows,
  })
}))

/* ---------------------------------------------------------------- support */

router.get('/tickets', requireUser, asyncRoute((req, res) => {
  res.json(engagement.listTickets({ userId: req.user.id }))
}))

router.post('/tickets', requireUser, asyncRoute((req, res) => {
  const { category, subject, body } = req.body || {}
  if (!subject || String(subject).trim().length < 4) fail(400, 'invalid_subject', 'Add a short subject.')
  if (!body || String(body).trim().length < 8) fail(400, 'invalid_body', 'Describe your request so support can help.')
  const ticket = engagement.createTicket({
    userId: req.user.id,
    category: category || 'general',
    subject: String(subject).trim(),
    body: String(body).trim(),
  })
  res.status(201).json({ ticket })
}))

router.get('/tickets/:id', requireUser, asyncRoute((req, res) => {
  const ticket = db.prepare('SELECT * FROM support_tickets WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id)
  if (!ticket) fail(404, 'ticket_not_found', 'Support ticket not found.')
  res.json({ ticket, messages: engagement.ticketMessages(ticket.id) })
}))

router.post('/tickets/:id/reply', requireUser, asyncRoute((req, res) => {
  const ticket = db.prepare('SELECT id FROM support_tickets WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id)
  if (!ticket) fail(404, 'ticket_not_found', 'Support ticket not found.')
  const body = String(req.body?.body || '').trim()
  if (body.length < 2) fail(400, 'invalid_body', 'Write a message.')
  res.json({ ticket: engagement.replyToTicket(ticket.id, { authorType: 'user', authorId: req.user.id, body }) })
}))

/* ------------------------------------------------------------------- news */

router.get('/news', asyncRoute((req, res) => {
  const rows = db.prepare(`
    SELECT id, title, summary, category, image_url, published_at, pinned
    FROM news_articles ORDER BY pinned DESC, published_at DESC LIMIT 50
  `).all()
  res.json(rows.map((r) => ({ ...r, is_new: Date.now() - new Date(r.published_at).getTime() < 7 * 86400_000 })))
}))

router.get('/news/:id', asyncRoute((req, res) => {
  const article = db.prepare('SELECT * FROM news_articles WHERE id = ?').get(req.params.id)
  if (!article) fail(404, 'article_not_found', 'Article not found.')
  res.json(article)
}))

router.get('/settings/public', asyncRoute((req, res) => {
  const all = allSettings()
  res.json({
    platform_name: all.platform_name,
    platform_tagline: all.platform_tagline,
    maintenance_mode: all.maintenance_mode === 'true',
    maintenance_message: all.maintenance_message,
    registration_open: all.registration_open === 'true',
    min_deposit_centavos: Number(all.min_deposit_centavos),
    min_withdrawal_centavos: Number(all.min_withdrawal_centavos),
    welcome_reward_centavos: Number(all.welcome_reward_centavos),
    welcome_reward_withdrawable: all.welcome_reward_withdrawable === 'true',
    welcome_reward_note: all.welcome_reward_note,
    support_email: all.support_email,
    support_hours: all.support_hours,
    currency: all.currency,
    terms_version: all.terms_version,
    notice: 'Projected plan rewards are estimates, not guaranteed returns. DriveVest does not offer risk-free or guaranteed investment products.',
  })
}))

module.exports = router