'use strict'
/** Customer authentication: register (3 fields), login (2 fields), session, logout, password. */
const express = require('express')
const db = require('../db')
const accounts = require('../lib/accounts')
const ledger = require('../lib/ledger')
const audit = require('../lib/audit')
const auth = require('../lib/auth')
const engagement = require('../lib/engagement')
const { asyncRoute, fail } = require('../lib/util')

const router = express.Router()

const publicUser = (row) => ({
  id: row.id,
  username: row.username,
  membership: row.membership,
  status: row.status,
  referral_code: row.referral_code,
  created_at: row.created_at,
})

router.post('/register', accounts.registrationLimiter, asyncRoute((req, res) => {
  const { username, password, referralCode } = req.body || {}
  // Registration accepts exactly these three inputs. No email, phone or role is
  // ever read from the request body.
  const result = accounts.register(req, { username, password, referralCode })
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.user.id)
  const session = auth.createSession('user', user.id, req, auth.USER_SESSION_HOURS)
  auth.setSessionCookie(res, session.token, session.hours)
  audit.record(req, {
    action: 'user.register',
    targetType: 'user',
    targetId: user.id,
    reason: 'Account created',
    after: { username: user.username, referral_code: user.referral_code, referred_by: result.user.referred_by },
    transactionReference: result.welcomeReward.transaction_reference,
  })
  engagement.publishNotification({
    userId: user.id,
    audience: 'user',
    title: 'Welcome to DriveVest',
    body: `Your ₱${(result.welcomeReward.amount_centavos / 100).toFixed(2)} welcome reward has been credited to your ${result.welcomeReward.wallet} wallet.`,
    severity: 'success',
    actionUrl: '/wallet',
  })
  res.status(201).json({
    user: { ...publicUser(user), referred_by: result.user.referred_by },
    wallet: result.wallet,
    welcomeReward: result.welcomeReward,
    csrfToken: session.csrf,
  })
}))

router.post('/login', asyncRoute(async (req, res) => {
  const { username, password } = req.body || {}
  const key = String(username || '').trim().toLowerCase()
  // No IP-keyed middleware here: it could not tell a correct sign-in from a
  // wrong one, so it counted successes and locked customers out of their own
  // accounts after 30 legitimate logins. Both guards below count failures only.
  accounts.assertLoginAllowedByIp(req.ip)
  accounts.assertLoginAllowed(key, req.ip)

  const user = db.prepare('SELECT * FROM users WHERE username_lower = ?').get(key)
  const ok = await auth.equalizedCompare(String(password || ''), user?.password_hash)
  // A wrong password is what burns the budget; a suspended account is not a
  // failed guess, so it must not lock the owner out of their own account.
  if (!user || !ok) {
    accounts.recordLoginFailure(key, req.ip)
    fail(401, 'invalid_credentials', 'Incorrect username or password.')
  }
  if (user.status !== 'Active') fail(403, 'account_not_active', `This account is ${user.status.toLowerCase()}. Contact support for help.`)

  accounts.clearLoginAttempts(key, req.ip)
  db.prepare('UPDATE users SET last_login = ? WHERE id = ?').run(new Date().toISOString(), user.id)
  const session = auth.createSession('user', user.id, req, auth.USER_SESSION_HOURS)
  auth.setSessionCookie(res, session.token, session.hours)

  const welcome = db.prepare('SELECT * FROM welcome_rewards WHERE user_id = ?').get(user.id)
  res.json({
    user: publicUser(user),
    wallet: ledger.walletSummary(user.id),
    csrfToken: session.csrf,
    welcomeRewardIssued: !!welcome,
  })
}))

router.post('/logout', auth.requireUser(), asyncRoute((req, res) => {
  auth.revokeAll('user', req.user.id, req.sessionToken)
  auth.clearSessionCookie(res, 'user')
  res.json({ ok: true })
}))

router.get('/session', asyncRoute((req, res) => {
  const loaded = auth.loadSession(req)
  if (!loaded || loaded.session.subject_type !== 'user') {
    return res.status(401).json({ error: { code: 'unauthenticated', message: 'No active session.' } })
  }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(loaded.session.subject_id)
  if (!user) return res.status(401).json({ error: { code: 'unauthenticated', message: 'No active session.' } })
  return res.json({
    user: publicUser(user),
    wallet: ledger.walletSummary(user.id),
    csrfToken: loaded.session.csrf_token,
    unread: engagement.unreadCount(user.id),
  })
}))

router.post('/password', auth.requireUser(), asyncRoute(async (req, res) => {
  const { currentPassword, newPassword } = req.body || {}
  const ok = await auth.equalizedCompare(String(currentPassword || ''), req.user.password_hash)
  if (!ok) fail(401, 'invalid_credentials', 'Your current password is incorrect.')
  const clean = auth.validatePassword(newPassword)
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(auth.hashPassword(clean), req.user.id)
  auth.revokeAll('user', req.user.id, req.sessionToken)
  audit.record(req, { action: 'user.password_changed', targetType: 'user', targetId: req.user.id, reason: 'Password changed by account holder' })
  res.json({ ok: true, message: 'Password updated. Other sessions were signed out.' })
}))

router.get('/sessions', auth.requireUser(), asyncRoute((req, res) => {
  const rows = db.prepare(`
    SELECT id, created_at, last_seen_at, expires_at, ip, user_agent, revoked_at
    FROM sessions WHERE subject_type = 'user' AND subject_id = ?
    ORDER BY created_at DESC LIMIT 20
  `).all(req.user.id)
  const hash = require('../lib/util').sha256(req.sessionToken)
  res.json(rows.map((r) => ({ ...r, current: db.prepare('SELECT 1 FROM sessions WHERE id=? AND token_hash=?').get(r.id, hash) ? true : false })))
}))

module.exports = router