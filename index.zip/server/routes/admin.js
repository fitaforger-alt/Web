'use strict'
/** Administrator API. Every route enforces a server-side permission check. */
const express = require('express')
const db = require('../db')
const auth = require('../lib/auth')
const ledger = require('../lib/ledger')
const audit = require('../lib/audit')
const plans = require('../lib/plans')
const userPlans = require('../lib/userPlans')
const deposits = require('../lib/deposits')
const withdrawals = require('../lib/withdrawals')
const engagement = require('../lib/engagement')
const payments = require('../providers/payments')
const { limitByIp, limitBySubject, hit, peek, fail: recordFailure, reset: clearBucket } = require('../lib/ratelimit')
const {
  asyncRoute, fail, id, now, toCentavos, today, addDays, setSetting, allSettings, getIntSetting,
} = require('../lib/util')

const router = express.Router()

const financeMutation = limitBySubject('finance', 60, 60_000)

// Administrator sign-in throttle — DISABLED by default.
//
// This platform has a small, named set of administrator accounts rather than
// open self-service signup, so the exposure a sign-in throttle is defending
// against is narrow, while the cost is real: an operator who fat-fingers a
// password is locked out of the console that manages their own money, with no
// self-service recovery.
//
// Setting ADMIN_LOGIN_MAX_FAILURES to a positive number turns it back on. The
// counter, when enabled, counts FAILED sign-ins only and a correct password
// clears it — an earlier version counted every attempt and locked out
// administrators who were signing in correctly, which was a bug, not a policy.
//
// There is deliberately no IP-keyed middleware limiter on this route: as
// middleware it cannot tell a correct sign-in from a wrong one, so it counted
// successes and locked people out after 20 legitimate logins.
// Read per request rather than at module load so the guard can be exercised in
// both states by one process, and so changing the setting does not need a
// restart to be observed.
function throttleConfig() {
  const max = Number(process.env.ADMIN_LOGIN_MAX_FAILURES || 0)
  return {
    enabled: max > 0,
    max,
    ipMax: Number(process.env.ADMIN_LOGIN_IP_MAX_FAILURES || 0),
    windowMs: Number(process.env.ADMIN_LOGIN_WINDOW_MINUTES || 15) * 60_000,
  }
}

const adminActor = (req) => ({ type: 'admin', id: req.admin.id, name: req.admin.display_name })

/* ------------------------------------------------------------------- login */

router.post('/login', asyncRoute(async (req, res) => {
  const { username, password } = req.body || {}
  const key = String(username || '').trim().toLowerCase()

  // Per-account bucket. Keyed on username+IP so one attacker cannot lock a
  // legitimate administrator out of their own account.
  const accountKey = `admin-login-fail:${key}:${req.ip}`
  const ipKey = `admin-login-ip-fail:${req.ip}`

  const limit = throttleConfig()

  if (limit.enabled) {
    // Refuse before doing any password work, but do not count the refusal.
    const blocked = peek(accountKey)
    if (blocked.retryAfter > 0 && blocked.count >= limit.max) {
      fail(429, 'rate_limited', `Too many failed sign-in attempts. Try again in ${blocked.retryAfter} seconds.`)
    }
  }

  const admin = db.prepare('SELECT * FROM admin_users WHERE username_lower = ?').get(key)
  const ok = await auth.equalizedCompare(String(password || ''), admin?.password_hash)

  if (!admin || !ok || admin.status !== 'Active') {
    if (limit.enabled) {
      const account = recordFailure(accountKey, limit.max, limit.windowMs)
      if (limit.ipMax > 0) recordFailure(ipKey, limit.ipMax, limit.windowMs)
      if (!account.allowed) {
        fail(429, 'rate_limited', `Too many failed sign-in attempts. Try again in ${account.retryAfter} seconds.`)
      }
    }
    if (!admin || !ok) fail(401, 'invalid_credentials', 'Incorrect administrator username or password.')
    fail(403, 'account_not_active', 'This administrator account is not active.')
  }

  // Correct credentials clear both buckets immediately.
  if (limit.enabled) {
    clearBucket(accountKey)
    clearBucket(ipKey)
  }

  db.prepare('UPDATE admin_users SET last_login = ?, last_login_ip = ? WHERE id = ?').run(now(), req.ip, admin.id)
  const session = auth.createSession('admin', admin.id, req, auth.ADMIN_SESSION_HOURS)
  auth.setSessionCookie(res, session.token, session.hours)
  audit.record(req, {
    action: 'admin.login',
    targetType: 'admin',
    targetId: admin.id,
    after: { username: admin.username, role: admin.role },
    actor: adminActor({ admin }),
  })

  res.json({
    admin: {
      id: admin.id,
      username: admin.username,
      display_name: admin.display_name,
      role: admin.role,
      permissions: auth.permissionsForRole(admin.role),
    },
    csrfToken: session.csrf,
  })
}))

router.post('/logout', auth.requireAdmin(), asyncRoute((req, res) => {
  auth.revokeAll('admin', req.admin.id, req.sessionToken)
  auth.clearSessionCookie(res)
  res.json({ ok: true })
}))

router.get('/session', asyncRoute((req, res) => {
  const loaded = auth.loadSession(req)
  if (!loaded || loaded.session.subject_type !== 'admin') {
    return res.status(401).json({ error: { code: 'unauthenticated', message: 'No active administrator session.' } })
  }
  const admin = db.prepare('SELECT * FROM admin_users WHERE id = ?').get(loaded.session.subject_id)
  if (!admin) return res.status(401).json({ error: { code: 'unauthenticated', message: 'No active administrator session.' } })
  return res.json({
    admin: { id: admin.id, username: admin.username, display_name: admin.display_name, role: admin.role, permissions: auth.permissionsForRole(admin.role) },
    csrfToken: loaded.session.csrf_token,
  })
}))

/* ---------------------------------------------------------------- overview */

router.get('/overview', auth.requireAdmin('users.read'), asyncRoute((req, res) => {
  const one = (sql, ...params) => db.prepare(sql).get(...params)
  const users = one('SELECT COUNT(*) c FROM users').c
  const activeUsers = one("SELECT COUNT(*) c FROM users WHERE status = 'Active'").c
  const suspendedUsers = one("SELECT COUNT(*) c FROM users WHERE status != 'Active'").c
  const pendingDeposits = one("SELECT COUNT(*) c FROM deposits WHERE status IN ('pending','under_review')").c
  const pendingWithdrawals = one("SELECT COUNT(*) c FROM withdrawals WHERE status IN ('pending','under_review','processing')").c
  const activePlans = one("SELECT COUNT(*) c FROM user_plans WHERE status = 'active'").c
  const totalDeposits = one("SELECT COALESCE(SUM(amount_centavos),0) s FROM deposits WHERE status = 'approved'").s
  const totalWithdrawals = one("SELECT COALESCE(SUM(amount_centavos),0) s FROM withdrawals WHERE status = 'completed'").s
  const welcomeRewards = one('SELECT COUNT(*) c, COALESCE(SUM(amount_centavos),0) s FROM welcome_rewards')
  const liabilities = one('SELECT COALESCE(SUM(recharge_centavos),0) recharge, COALESCE(SUM(earnings_centavos),0) earnings, COALESCE(SUM(reserved_centavos),0) reserved FROM wallets')
  const failed = one("SELECT COUNT(*) c FROM ledger_entries WHERE status = 'failed'").c
    + one("SELECT COUNT(*) c FROM deposits WHERE status = 'failed'").c
    + one("SELECT COUNT(*) c FROM withdrawals WHERE status = 'failed'").c

  const daily = db.prepare(`
    SELECT substr(created_at,1,10) day,
      SUM(CASE WHEN direction='credit' THEN amount_centavos ELSE 0 END) credits,
      SUM(CASE WHEN direction='debit' THEN amount_centavos ELSE 0 END) debits,
      COUNT(*) entries
    FROM ledger_entries WHERE created_at >= ? GROUP BY day ORDER BY day ASC
  `).all(addDays(today(), -29) + 'T00:00:00.000Z')

  res.json({
    cards: {
      users, active_users: activeUsers, suspended_users: suspendedUsers,
      pending_deposits: pendingDeposits, pending_withdrawals: pendingWithdrawals,
      active_plans: activePlans,
      total_deposits_centavos: totalDeposits,
      total_withdrawals_centavos: totalWithdrawals,
      welcome_rewards_issued: welcomeRewards.c,
      welcome_rewards_value_centavos: welcomeRewards.s,
      wallet_liabilities_centavos: liabilities.recharge + liabilities.earnings,
      wallet_recharge_centavos: liabilities.recharge,
      wallet_earnings_centavos: liabilities.earnings,
      wallet_reserved_centavos: liabilities.reserved,
      failed_transactions: failed,
    },
    daily,
    recent_audit: audit.query({ limit: 12 }).rows,
    payment_providers: payments.catalogue(),
  })
}))

/* ------------------------------------------------------------------- users */

router.get('/users', auth.requireAdmin('users.read'), asyncRoute((req, res) => {
  const q = String(req.query.q || '').trim()
  const status = String(req.query.status || '')
  const limit = Math.min(Number(req.query.limit) || 25, 100)
  const offset = Math.max(Number(req.query.offset) || 0, 0)

  const clauses = []
  const params = { limit, offset }
  if (q) {
    clauses.push('(u.username_lower LIKE @q OR u.id = @id)')
    params.q = `%${q.toLowerCase()}%`
    params.id = q
  }
  if (status) { clauses.push('u.status = @status'); params.status = status }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : ''

  const total = db.prepare(`SELECT COUNT(*) c FROM users u ${where}`).get(params).c
  const rows = db.prepare(`
    SELECT u.id, u.username, u.status, u.membership, u.referral_code, u.created_at, u.last_login,
      w.recharge_centavos, w.earnings_centavos, w.reserved_centavos, w.points,
      (SELECT COUNT(*) FROM user_plans up WHERE up.user_id = u.id AND up.status = 'active') AS active_plans,
      (SELECT COUNT(*) FROM referrals r WHERE r.referrer_id = u.id) AS referrals
    FROM users u LEFT JOIN wallets w ON w.user_id = u.id
    ${where} ORDER BY u.created_at DESC LIMIT @limit OFFSET @offset
  `).all(params)

  res.json({ total, limit, offset, rows })
}))

router.get('/users/:id', auth.requireAdmin('users.read'), asyncRoute((req, res) => {
  const user = db.prepare(`
    SELECT id, username, status, membership, referral_code, referred_by, created_at, last_login
    FROM users WHERE id = ? OR username_lower = ?
  `).get(req.params.id, String(req.params.id).toLowerCase())
  if (!user) fail(404, 'user_not_found', 'Account not found.')

  const wallet = ledger.walletSummary(user.id)
  const { rows: entries } = ledger.entriesForUser(user.id, { limit: 100 })
  const planRows = userPlans.forUser(user.id)
  const notes = db.prepare("SELECT * FROM admin_notes WHERE subject_type = 'user' AND subject_id = ? ORDER BY created_at DESC").all(user.id)
  const welcome = db.prepare('SELECT * FROM welcome_rewards WHERE user_id = ?').get(user.id)
  const referralsMade = db.prepare(`
    SELECT r.*, u.username FROM referrals r JOIN users u ON u.id = r.referred_id WHERE r.referrer_id = ?
  `).all(user.id)
  const auditTrail = audit.query({ targetType: 'user', targetId: user.id, limit: 50 }).rows
  const adjustmentHistory = db.prepare(`
    SELECT * FROM ledger_entries WHERE user_id = ? AND kind IN ('manual_adjustment','manual_adjustment_reversal') ORDER BY created_at DESC
  `).all(user.id)

  res.json({
    user, wallet, entries, plans: planRows.map(userPlans.decorate), notes,
    welcomeReward: welcome || null,
    referrals: referralsMade,
    auditTrail,
    adjustments: adjustmentHistory,
  })
}))

router.post('/users/:id/status', auth.requireAdmin('users.manage'), asyncRoute((req, res) => {
  const { status, reason } = req.body || {}
  const allowed = ['Active', 'Suspended', 'Restricted']
  if (!allowed.includes(status)) fail(400, 'invalid_status', 'Choose Active, Suspended or Restricted.')
  if (!reason || String(reason).trim().length < 4) fail(400, 'reason_required', 'Record why this account status is changing.')

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id)
  if (!user) fail(404, 'user_not_found', 'Account not found.')

  db.prepare('UPDATE users SET status = ? WHERE id = ?').run(status, user.id)
  if (status !== 'Active') auth.revokeAll('user', user.id)
  audit.record(req, {
    action: 'user.status_changed',
    targetType: 'user',
    targetId: user.id,
    reason: String(reason).trim(),
    before: { status: user.status },
    after: { status },
  })
  res.json({ user: db.prepare('SELECT id, username, status FROM users WHERE id = ?').get(user.id) })
}))

router.post('/users/:id/notes', auth.requireAdmin('users.manage'), asyncRoute((req, res) => {
  const body = String(req.body?.body || '').trim()
  if (body.length < 2) fail(400, 'invalid_note', 'Write the note before saving.')
  const noteId = id('note')
  db.prepare(`
    INSERT INTO admin_notes (id, subject_type, subject_id, body, author_id, author_name, created_at)
    VALUES (?,'user',?,?,?,?,?)
  `).run(noteId, req.params.id, body, req.admin.id, req.admin.display_name, now())
  audit.record(req, { action: 'user.note_added', targetType: 'user', targetId: req.params.id, reason: body.slice(0, 200) })
  res.status(201).json({ id: noteId })
}))

/* ------------------------------------------------------------- adjustments */

router.get('/adjustments/preview', auth.requireAdmin('ledger.adjust'), asyncRoute((req, res) => {
  const userId = String(req.query.userId || '')
  const wallet = String(req.query.wallet || 'recharge')
  if (!ledger.WALLETS.includes(wallet)) fail(400, 'invalid_wallet', 'Unknown wallet.')
  const walletRow = ledger.ensureWallet(userId)
  const summary = ledger.walletSummary(userId)
  const amount = req.query.amount ? toCentavos(req.query.amount) : 0
  const direction = req.query.direction === 'Debit' ? 'Debit' : 'Credit'
  const column = ledger.COLUMN[wallet]
  const current = walletRow[column]
  return res.json({
    wallet, direction, amount_centavos: amount,
    current_centavos: current,
    resulting_centavos: direction === 'Credit' ? current + amount : current - amount,
    wallet_summary: summary,
    second_approval_required: amount >= getIntSetting('second_approval_threshold_centavos', 0),
  })
}))

router.get('/adjustments', auth.requireAdmin('ledger.adjust'), asyncRoute((req, res) => {
  const { rows, total } = db.prepare(`
    SELECT l.*, u.username, a.display_name AS actor_display
    FROM ledger_entries l
    LEFT JOIN users u ON u.id = l.user_id
    LEFT JOIN admin_users a ON a.id = l.actor_id
    WHERE l.kind LIKE 'manual_adjustment%'
    ORDER BY l.created_at DESC LIMIT ? OFFSET ?
  `).all(Math.min(Number(req.query.limit) || 50, 200), Math.max(Number(req.query.offset) || 0, 0))
  return res.json({ total, rows })
}))

router.post('/adjustments', auth.requireAdmin('ledger.adjust'), financeMutation, asyncRoute((req, res) => {
  const { userId, wallet, direction, amount, reason, note, reference } = req.body || {}
  if (!ledger.WALLETS.includes(wallet)) fail(400, 'invalid_wallet', 'Choose recharge, earnings or points.')
  if (!['Credit', 'Debit'].includes(direction)) fail(400, 'invalid_direction', 'Choose credit or debit.')
  const amountCentavos = toCentavos(amount)
  if (amountCentavos <= 0) fail(400, 'invalid_amount', 'Enter an amount greater than zero.')
  if (!reason || String(reason).trim().length < 4) fail(400, 'reason_required', 'A reason is required for every adjustment.')
  if (!note || String(note).trim().length < 8) fail(400, 'note_required', 'Add a detailed explanation for the ledger.')

  const user = db.prepare('SELECT * FROM users WHERE id = ? OR username_lower = ?').get(userId, String(userId || '').toLowerCase())
  if (!user) fail(404, 'user_not_found', 'Account not found.')

  const threshold = getIntSetting('second_approval_threshold_centavos', 0)
  const requiresSecond = threshold > 0 && amountCentavos >= threshold

  if (requiresSecond) {
    const payload = { userId: user.id, wallet, direction, amount_centavos: amountCentavos, reason: String(reason).trim(), note: String(note).trim(), reference: reference || null }
    const existing = db.prepare("SELECT * FROM approvals WHERE kind = 'adjustment' AND subject_type = 'user' AND subject_id = ? AND status = 'pending'").get(user.id)
    if (existing) fail(409, 'approval_pending', 'A second approval is already pending for this account.')

    const approvalId = id('apr')
    db.prepare(`
      INSERT INTO approvals (id, kind, subject_type, subject_id, requested_by, requested_by_name, requested_at, payload, status)
      VALUES (?,'adjustment','user',?,?,?,?,?,'pending')
    `).run(approvalId, user.id, req.admin.id, req.admin.display_name, now(), JSON.stringify(payload))

    audit.record(req, {
      action: 'adjustment.second_approval_requested',
      targetType: 'user', targetId: user.id,
      reason: String(reason).trim(),
      after: payload,
    })
    return res.status(202).json({
      status: 'pending_second_approval',
      approval_id: approvalId,
      message: `Adjustments of ${(threshold / 100).toLocaleString('en-PH', { minimumFractionDigits: 2 })} or more need a second administrator to approve them. Nothing has been credited yet.`,
    })
  }

  const result = ledger.post({
    userId: user.id,
    wallet,
    direction: direction === 'Credit' ? 'credit' : 'debit',
    amountCentavos,
    kind: 'manual_adjustment',
    status: 'completed',
    reason: String(reason).trim(),
    note: String(note).trim(),
    idempotencyKey: req.get('x-idempotency-key') || null,
    correlationId: req.correlationId,
    actor: adminActor(req),
  })

  audit.record(req, {
    action: 'adjustment.posted',
    targetType: 'user', targetId: user.id,
    reason: String(reason).trim(),
    before: { balance_centavos: result.entry.balance_before_centavos },
    after: { balance_centavos: result.entry.balance_after_centavos },
    transactionReference: reference || result.entry.reference,
  })
  return res.status(201).json({ entry: result.entry, wallet: result.wallet })
}))

router.get('/approvals', auth.requireAdmin('ledger.adjust'), asyncRoute((req, res) => {
  const status = req.query.status ? String(req.query.status) : null
  const params = { limit: Math.min(Number(req.query.limit) || 50, 200), offset: Math.max(Number(req.query.offset) || 0, 0) }
  const where = status ? 'WHERE status = @status' : ''
  if (status) params.status = status
  const total = db.prepare(`SELECT COUNT(*) c FROM approvals ${where}`).get(params).c
  const rows = db.prepare(`SELECT * FROM approvals ${where} ORDER BY requested_at DESC LIMIT @limit OFFSET @offset`).all(params)
  return res.json({ total, rows: rows.map((r) => ({ ...r, payload: JSON.parse(r.payload) })) })
}))

router.post('/approvals/:id/decision', auth.requireAdmin('ledger.adjust'), asyncRoute((req, res) => {
  const { decision, note } = req.body || {}
  const approval = db.prepare("SELECT * FROM approvals WHERE id = ? AND status = 'pending'").get(req.params.id)
  if (!approval) fail(404, 'approval_not_found', 'No pending approval with that reference.')
  if (approval.requested_by === req.admin.id) fail(409, 'self_approval', 'A second administrator must approve this request.')
  if (!['approve', 'reject'].includes(decision)) fail(400, 'invalid_decision', 'Choose approve or reject.')
  if (decision === 'reject' && (!note || String(note).trim().length < 4)) fail(400, 'reason_required', 'Record why this request is rejected.')

  const payload = JSON.parse(approval.payload)
  let entry = null

  if (decision === 'approve') {
    entry = ledger.post({
      userId: payload.userId,
      wallet: payload.wallet,
      direction: payload.direction === 'Credit' ? 'credit' : 'debit',
      amountCentavos: payload.amount_centavos,
      kind: 'manual_adjustment',
      status: 'completed',
      reason: payload.reason,
      note: `${payload.note} (second approval by ${req.admin.display_name})`,
      idempotencyKey: `adjustment-approval:${approval.id}`,
      correlationId: req.correlationId,
      actor: adminActor(req),
    })
  }

  db.prepare(`
    UPDATE approvals SET status = ?, decided_by = ?, decided_by_name = ?, decision = ?, decided_at = ?, note = ? WHERE id = ?
  `).run(decision === 'approve' ? 'approved' : 'rejected', req.admin.id, req.admin.display_name, decision, now(), note || null, approval.id)

  audit.record(req, {
    action: `adjustment.second_approval_${decision}`,
    targetType: 'user', targetId: payload.userId,
    reason: note || payload.reason,
    after: payload,
    transactionReference: entry?.reference || null,
  })
  res.json({ status: decision, entry })
}))

/* ----------------------------------------------------------------- ledger */

router.get('/transactions', auth.requireAdmin('ledger.read'), asyncRoute((req, res) => {
  const clauses = []
  const params = { limit: Math.min(Number(req.query.limit) || 50, 200), offset: Math.max(Number(req.query.offset) || 0, 0) }
  if (req.query.userId) { clauses.push('l.user_id = @user_id'); params.user_id = req.query.userId }
  if (req.query.kind) { clauses.push('l.kind = @kind'); params.kind = req.query.kind }
  if (req.query.wallet) { clauses.push('l.wallet = @wallet'); params.wallet = req.query.wallet }
  if (req.query.status) { clauses.push('l.status = @status'); params.status = req.query.status }
  if (req.query.from) { clauses.push('l.created_at >= @from'); params.from = req.query.from }
  if (req.query.to) { clauses.push('l.created_at <= @to'); params.to = req.query.to }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : ''
  const total = db.prepare(`SELECT COUNT(*) c FROM ledger_entries l ${where}`).get(params).c
  const rows = db.prepare(`
    SELECT l.*, u.username, a.display_name AS actor_name
    FROM ledger_entries l
    LEFT JOIN users u ON u.id = l.user_id
    LEFT JOIN admin_users a ON a.id = l.actor_id
    ${where} ORDER BY l.created_at DESC LIMIT @limit OFFSET @offset
  `).all(params)
  res.json({ total, limit: params.limit, offset: params.offset, rows })
}))

router.post('/transactions/:id/reverse', auth.requireAdmin('ledger.adjust'), asyncRoute((req, res) => {
  const reason = String(req.body?.reason || '').trim()
  if (reason.length < 8) fail(400, 'reason_required', 'Explain why this entry is being reversed.')
  const original = db.prepare('SELECT * FROM ledger_entries WHERE id = ?').get(req.params.id)
  if (!original) fail(404, 'entry_not_found', 'Ledger entry not found.')
  if (original.kind === 'welcome_reward') {
    fail(409, 'welcome_reward_protected', 'Welcome rewards are corrected through a dedicated audited adjustment, not a reversal here.')
  }
  const result = ledger.reverse(original.id, { actor: adminActor(req), reason, correlationId: req.correlationId })
  audit.record(req, {
    action: 'ledger.reversed',
    targetType: 'ledger_entry', targetId: original.id,
    reason,
    before: { amount_centavos: original.amount_centavos, direction: original.direction, reference: original.reference },
    after: { reversal_reference: result.entry.reference },
    transactionReference: result.entry.reference,
  })
  res.json({ entry: result.entry })
}))

/* --------------------------------------------------------------- deposits */

router.get('/deposits', auth.requireAdmin('deposits.review'), asyncRoute((req, res) => {
  const { total, rows } = deposits.listDeposits({
    status: req.query.status ? String(req.query.status) : undefined,
    from: req.query.from, to: req.query.to,
    limit: Math.min(Number(req.query.limit) || 50, 200),
    offset: Math.max(Number(req.query.offset) || 0, 0),
  })
  res.json({ total, rows, providers: payments.catalogue() })
}))

router.post('/deposits/:id/review', auth.requireAdmin('deposits.review'), asyncRoute(async (req, res) => {
  const { action, reason } = req.body || {}
  const depositId = req.params.id

  if (action === 'under_review') {
    const updated = deposits.markUnderReview(depositId, { actor: adminActor(req) })
    audit.record(req, { action: 'deposit.under_review', targetType: 'deposit', targetId: depositId, reason: reason || null })
    return res.json({ deposit: updated })
  }

  if (action === 'reject') {
    const updated = deposits.rejectDeposit(depositId, { reason, actor: adminActor(req), correlationId: req.correlationId })
    audit.record(req, {
      action: 'deposit.rejected', targetType: 'deposit', targetId: depositId,
      reason: String(reason).trim(),
      before: { status: 'pending' }, after: { status: 'rejected', reference: updated.reference },
      transactionReference: updated.reference,
    })
    return res.json({ deposit: updated })
  }

  if (action === 'verify') {
    const deposit = db.prepare('SELECT * FROM deposits WHERE id = ?').get(depositId)
    if (!deposit) fail(404, 'deposit_not_found', 'Deposit request not found.')
    const result = await payments.reconcileDeposit(deposit)
    if (!result.verified) fail(409, 'verification_failed', result.detail)
    const settled = deposits.settleDeposit(depositId, {
      verificationState: 'provider_api',
      detail: result.detail,
      providerReference: result.providerReference,
      correlationId: req.correlationId,
      actor: adminActor(req),
    })
    audit.record(req, {
      action: 'deposit.verified',
      targetType: 'deposit', targetId: depositId,
      reason: result.detail,
      after: { status: 'approved', verification_state: 'provider_api' },
      transactionReference: settled.entry?.reference || deposit.reference,
    })
    return res.json({ deposit: settled.deposit, entry: settled.entry })
  }

  return fail(400, 'invalid_action', 'Unknown deposit action.')
}))

router.get('/payment-events', auth.requireAdmin('deposits.review'), asyncRoute((req, res) => {
  res.json(db.prepare('SELECT * FROM payment_provider_events ORDER BY received_at DESC LIMIT 100').all())
}))

/* ------------------------------------------------------------ withdrawals */

router.get('/withdrawals', auth.requireAdmin('withdrawals.review'), asyncRoute((req, res) => {
  const { total, rows } = withdrawals.listWithdrawals({
    status: req.query.status ? String(req.query.status) : undefined,
    from: req.query.from, to: req.query.to,
    limit: Math.min(Number(req.query.limit) || 50, 200),
    offset: Math.max(Number(req.query.offset) || 0, 0),
  })
  res.json({
    total,
    rows: rows.map((r) => ({ ...r, reviews: withdrawals.reviewsFor(r.id) })),
    second_approval_threshold_centavos: getIntSetting('second_approval_threshold_centavos', 0),
  })
}))

router.post('/withdrawals/:id/decision', auth.requireAdmin('withdrawals.review'), financeMutation, asyncRoute((req, res) => {
  const { action, reason, payoutReference, proof } = req.body || {}
  const id_ = req.params.id

  if (action === 'approve') {
    const result = withdrawals.approve(id_, { admin: req.admin, reason, correlationId: req.correlationId })
    audit.record(req, {
      action: 'withdrawal.approved',
      targetType: 'withdrawal', targetId: id_,
      reason: String(reason).trim(),
      after: { status: result.withdrawal.status, needs_second_approval: result.needsSecondApproval },
      transactionReference: result.withdrawal.reference,
    })
    return res.json({ withdrawal: result.withdrawal, needs_second_approval: result.needsSecondApproval })
  }

  if (action === 'reject') {
    const result = withdrawals.reject(id_, { admin: req.admin, reason, correlationId: req.correlationId })
    audit.record(req, {
      action: 'withdrawal.rejected',
      targetType: 'withdrawal', targetId: id_,
      reason: String(reason).trim(),
      after: { status: 'rejected', released_centavos: result.withdrawal.amount_centavos },
      transactionReference: result.withdrawal.reference,
    })
    return res.json({ withdrawal: result.withdrawal })
  }

  if (action === 'mark_paid') {
    const result = withdrawals.markPaid(id_, { admin: req.admin, payoutReference, proof, correlationId: req.correlationId })
    audit.record(req, {
      action: 'withdrawal.paid',
      targetType: 'withdrawal', targetId: id_,
      reason: proof,
      after: { status: 'completed', payout_reference: payoutReference, net_centavos: result.withdrawal.net_centavos },
      transactionReference: result.entry?.reference || result.withdrawal.reference,
    })
    return res.json({ withdrawal: result.withdrawal, entry: result.entry })
  }

  if (action === 'mark_failed') {
    const result = withdrawals.markFailed(id_, { admin: req.admin, reason })
    audit.record(req, {
      action: 'withdrawal.failed',
      targetType: 'withdrawal', targetId: id_,
      reason: String(reason).trim(),
      after: { status: 'failed' },
      transactionReference: result.withdrawal.reference,
    })
    return res.json({ withdrawal: result.withdrawal })
  }

  return fail(400, 'invalid_action', 'Unknown withdrawal action.')
}))

/* ------------------------------------------------------------------ plans */

router.get('/plans', auth.requireAdmin('plans.manage'), asyncRoute((req, res) => {
  res.json(plans.listAll())
}))

router.get('/plans/:id/versions', auth.requireAdmin('plans.manage'), asyncRoute((req, res) => {
  res.json(plans.versions(req.params.id).map((v) => ({ ...v, snapshot: JSON.parse(v.snapshot) })))
}))

router.post('/plans', auth.requireAdmin('plans.manage'), asyncRoute((req, res) => {
  const b = req.body || {}
  if (!b.name) fail(400, 'invalid_plan', 'Give the product a name.')
  // The panel sends peso strings under the short names; the explicit
  // *_centavos spelling is accepted too. Reading only one of them meant a plan
  // created from the panel silently stored a zero daily income.
  const dailyRaw = b.projected_daily ?? b.projected_daily_centavos
  const plan = plans.create({
    name: String(b.name).trim(),
    category: b.category === 'vip' ? 'vip' : 'daily',
    description: b.description || null,
    terms: b.terms || 'Daily income is credited to your earnings wallet once every completed 24-hour period, for the number of days purchased. It is a fixed platform credit, not interest on your deposit, and it does not grow.',
    eligibility: b.eligibility || 'Open to all active accounts.',
    image_url: b.image_url || null,
    price_centavos: toCentavos(b.price),
    duration_days: Number(b.duration_days) || 30,
    projected_daily_centavos: dailyRaw ? toCentavos(dailyRaw) : 0,
    slots_total: Number(b.slots_total) || 0,
    active: b.active !== false,
  }, { admin: req.admin, reason: b.reason || 'Product created' })
  audit.record(req, { action: 'plan.created', targetType: 'plan', targetId: plan.id, reason: b.reason || 'Product created', after: plan })
  res.status(201).json({ plan })
}))

router.patch('/plans/:id', auth.requireAdmin('plans.manage'), asyncRoute((req, res) => {
  const b = req.body || {}
  const before = db.prepare('SELECT * FROM plans WHERE id = ?').get(req.params.id)
  if (!before) fail(404, 'plan_not_found', 'Product not found.')
  const patch = {}
  if (b.name !== undefined) patch.name = String(b.name)
  if (b.category !== undefined) patch.category = b.category === 'vip' ? 'vip' : 'daily'
  if (b.description !== undefined) patch.description = b.description
  if (b.terms !== undefined) patch.terms = b.terms
  if (b.eligibility !== undefined) patch.eligibility = b.eligibility
  if (b.image_url !== undefined) patch.image_url = b.image_url
  if (b.price !== undefined) patch.price_centavos = toCentavos(b.price)
  if (b.duration_days !== undefined) patch.duration_days = Number(b.duration_days)
  const dailyPatch = b.projected_daily ?? b.projected_daily_centavos
  if (dailyPatch !== undefined) patch.projected_daily_centavos = toCentavos(dailyPatch)
  if (b.slots_total !== undefined) patch.slots_total = Number(b.slots_total)
  if (b.active !== undefined) patch.active = !!b.active
  if (b.archived !== undefined) patch.archived = !!b.archived

  const plan = plans.update(before.id, patch, { admin: req.admin, reason: b.reason })
  audit.record(req, {
    action: 'plan.updated', targetType: 'plan', targetId: plan.id,
    reason: b.reason || 'Product updated',
    before, after: plan,
  })
  res.json({ plan })
}))

router.get('/plan-settlements', auth.requireAdmin('plans.manage'), asyncRoute((req, res) => {
  const limit = Math.min(Number(req.query.limit) || 100, 500)
  const rows = db.prepare(`
    SELECT s.*, up.plan_name, u.username, l.reference
    FROM plan_settlements s
    JOIN user_plans up ON up.id = s.user_plan_id
    JOIN users u ON u.id = s.user_id
    JOIN ledger_entries l ON l.id = s.ledger_entry_id
    ORDER BY s.settled_at DESC LIMIT ?
  `).all(limit)
  const summary = db.prepare('SELECT COUNT(*) c, COALESCE(SUM(amount_centavos),0) s FROM plan_settlements').get()
  return res.json({ total: summary.c, value_centavos: summary.s, rows })
}))

router.post('/plan-assignments', auth.requireAdmin('plans.assign'), asyncRoute((req, res) => {
  const { userId, planId, reason, debitCustomer, startDate } = req.body || {}
  const user = db.prepare('SELECT id, username FROM users WHERE id = ? OR username_lower = ?').get(userId, String(userId || '').toLowerCase())
  if (!user) fail(404, 'user_not_found', 'Account not found.')
  const plan = db.prepare('SELECT * FROM plans WHERE id = ?').get(planId)
  if (!plan) fail(404, 'plan_not_found', 'Product not found.')

  const assignment = userPlans.assign({
    userId: user.id,
    planId,
    reason,
    debitCustomer: !!debitCustomer,
    startDate,
    admin: req.admin,
    correlationId: req.correlationId,
  })
  audit.record(req, {
    action: 'plan.assigned', targetType: 'user', targetId: user.id,
    reason: String(reason).trim(),
    after: { plan_id: planId, plan_name: plan.name, amount_centavos: assignment.amount_centavos, start: assignment.start_date, end: assignment.end_date, debited: !!debitCustomer },
  })
  res.status(201).json({ assignment })
}))

router.get('/plan-assignments', auth.requireAdmin('plans.manage'), asyncRoute((req, res) => {
  const { total, rows } = userPlans.listAll({
    status: req.query.status ? String(req.query.status) : undefined,
    limit: Math.min(Number(req.query.limit) || 50, 200),
    offset: Math.max(Number(req.query.offset) || 0, 0),
  })
  res.json({ total, rows })
}))

router.post('/plan-assignments/:id/status', auth.requireAdmin('plans.manage'), asyncRoute((req, res) => {
  const { status, reason } = req.body || {}
  if (!reason || String(reason).trim().length < 4) fail(400, 'reason_required', 'Record why this plan status is changing.')
  const before = db.prepare('SELECT * FROM user_plans WHERE id = ?').get(req.params.id)
  const updated = userPlans.setStatus(req.params.id, status, { reason })
  audit.record(req, {
    action: 'plan.status_changed', targetType: 'user_plan', targetId: req.params.id,
    reason: String(reason).trim(),
    before: before ? { status: before.status } : null, after: { status: updated.status },
  })
  res.json({ assignment: updated })
}))

/* ---------------------------------------------------------------- rewards */

router.get('/welcome-rewards', auth.requireAdmin('ledger.read'), asyncRoute((req, res) => {
  const limit = Math.min(Number(req.query.limit) || 50, 200)
  const offset = Math.max(Number(req.query.offset) || 0, 0)
  const total = db.prepare('SELECT COUNT(*) c FROM welcome_rewards').get().c
  const rows = db.prepare(`
    SELECT wr.*, u.username, l.reference AS transaction_reference, l.status AS ledger_status
    FROM welcome_rewards wr
    JOIN users u ON u.id = wr.user_id
    JOIN ledger_entries l ON l.id = wr.ledger_entry_id
    ORDER BY wr.issued_at DESC LIMIT ? OFFSET ?
  `).all(limit, offset)
  const summary = db.prepare('SELECT COUNT(*) c, COALESCE(SUM(amount_centavos),0) s FROM welcome_rewards').get()
  res.json({
    total, limit, offset, rows,
    summary: { issued: summary.c, value_centavos: summary.s, per_account_centavos: getIntSetting('welcome_reward_centavos', 5000) },
  })
}))

router.get('/rewards/tasks', auth.requireAdmin('rewards.manage'), asyncRoute((req, res) => {
  const tasks = db.prepare('SELECT * FROM tasks ORDER BY sort_order ASC').all()
  const claims = db.prepare('SELECT task_id, COUNT(*) c FROM task_claims GROUP BY task_id').all()
  const counts = Object.fromEntries(claims.map((c) => [c.task_id, c.c]))
  res.json(tasks.map((t) => ({ ...t, claims: counts[t.id] || 0 })))
}))

router.post('/rewards/tasks', auth.requireAdmin('rewards.manage'), asyncRoute((req, res) => {
  const b = req.body || {}
  if (!b.title) fail(400, 'invalid_task', 'Give the task a title.')
  const taskId = id('tsk')
  db.prepare(`
    INSERT INTO tasks (id, title, description, reward_points, action_url, recurring, active, sort_order, created_at)
    VALUES (?,?,?,?,?,?,?,?,?)
  `).run(
    // Tasks pay the withdrawable earnings wallet. The form sends a peso string, so
// it is converted to centavos here. Number('2.50') would have silently made a
// ₱2.50 task pay 2 centavos.
taskId, String(b.title).trim(), b.description || null, toCentavos(b.reward_points),
    b.action_url || null, b.recurring === 'once' ? 'once' : 'daily', b.active === false ? 0 : 1,
    Number(b.sort_order) || 0, now(),
  )
  audit.record(req, { action: 'task.created', targetType: 'task', targetId: taskId, reason: b.title, after: b })
  res.status(201).json({ task: db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId) })
}))

router.patch('/rewards/tasks/:id', auth.requireAdmin('rewards.manage'), asyncRoute((req, res) => {
  const before = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id)
  if (!before) fail(404, 'task_not_found', 'Task not found.')
  const b = req.body || {}
  db.prepare(`
    UPDATE tasks SET title = ?, description = ?, reward_points = ?, action_url = ?, recurring = ?, active = ?, sort_order = ?
    WHERE id = ?
  `).run(
    // Same peso-to-centavos conversion as create. Passing through an unchanged value
// is safe because it is already an integer centavos amount.
b.title ?? before.title, b.description ?? before.description,
    b.reward_points === undefined ? before.reward_points : toCentavos(b.reward_points),
    b.action_url ?? before.action_url, b.recurring ?? before.recurring,
    b.active === undefined ? before.active : (b.active ? 1 : 0), Number(b.sort_order ?? before.sort_order),
    req.params.id,
  )
  const after = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id)
  audit.record(req, { action: 'task.updated', targetType: 'task', targetId: req.params.id, reason: b.reason || 'Task updated', before, after })
  res.json({ task: after })
}))

router.get('/rewards/codes', auth.requireAdmin('rewards.manage'), asyncRoute((req, res) => {
  const codes = engagement.listRedemptionCodes()
  const usage = db.prepare('SELECT code, COUNT(*) c FROM redemptions GROUP BY code').all()
  const counts = Object.fromEntries(usage.map((u) => [u.code, u.c]))
  res.json(codes.map((c) => ({ ...c, redeemed: counts[c.code] || 0 })))
}))

router.post('/rewards/codes', auth.requireAdmin('rewards.manage'), asyncRoute((req, res) => {
  const b = req.body || {}
  const record = engagement.createRedemptionCode({
    code: b.code,
    label: b.label,
    wallet: b.wallet === 'recharge' ? 'recharge' : b.wallet === 'earnings' ? 'earnings' : 'points',
    value: Math.trunc(Number(b.value)),
    max_redemptions: Math.max(Number(b.max_redemptions) || 1, 1),
    per_user_limit: Math.max(Number(b.per_user_limit) || 1, 1),
    starts_at: b.starts_at || null,
    expires_at: b.expires_at || null,
    active: b.active !== false,
  }, { admin: req.admin })
  audit.record(req, { action: 'redemption_code.created', targetType: 'redemption_code', targetId: record.code, after: record })
  res.status(201).json({ code: record })
}))

router.patch('/rewards/codes/:code', auth.requireAdmin('rewards.manage'), asyncRoute((req, res) => {
  const before = db.prepare('SELECT * FROM redemption_codes WHERE code = ?').get(req.params.code)
  if (!before) fail(404, 'code_not_found', 'Redemption code not found.')
  const active = req.body?.active === undefined ? before.active : (req.body.active ? 1 : 0)
  db.prepare('UPDATE redemption_codes SET active = ?, expires_at = COALESCE(?, expires_at) WHERE code = ?')
    .run(active, req.body?.expires_at || null, req.params.code)
  const after = db.prepare('SELECT * FROM redemption_codes WHERE code = ?').get(req.params.code)
  audit.record(req, { action: 'redemption_code.updated', targetType: 'redemption_code', targetId: after.code, before, after })
  res.json({ code: after })
}))

/* -------------------------------------------------------------- referrals */

router.get('/referrals', auth.requireAdmin('ledger.read'), asyncRoute((req, res) => {
  const limit = Math.min(Number(req.query.limit) || 100, 500)
  const rows = db.prepare(`
    SELECT r.*, ru.username AS referrer_username, u.username AS referred_username
    FROM referrals r
    JOIN users ru ON ru.id = r.referrer_id
    JOIN users u ON u.id = r.referred_id
    ORDER BY r.created_at DESC LIMIT ?
  `).all(limit)
  const summary = db.prepare('SELECT COUNT(*) c, COALESCE(SUM(reward_centavos),0) s FROM referrals').get()
  res.json({ total: summary.c, bonus_points_centavos: summary.s, rows })
}))

/* ---------------------------------------------- notifications & support */

router.get('/notifications', auth.requireAdmin('support.manage'), asyncRoute((req, res) => {
  res.json(db.prepare(`
    SELECT n.*, u.username FROM notifications n
    LEFT JOIN users u ON u.id = n.user_id
    ORDER BY n.created_at DESC LIMIT 100
  `).all())
}))

router.post('/notifications', auth.requireAdmin('support.manage'), asyncRoute((req, res) => {
  const { userId, audience, title, body, severity, actionUrl } = req.body || {}
  if (!title || !body) fail(400, 'invalid_notification', 'A notification needs a title and a message.')
  if (userId) {
    const user = db.prepare('SELECT id FROM users WHERE id = ? OR username_lower = ?').get(userId, String(userId).toLowerCase())
    if (!user) fail(404, 'user_not_found', 'Account not found.')
  }
  engagement.publishNotification({
    userId: userId || null, audience: userId ? 'user' : (audience || 'broadcast'),
    title: String(title).trim(), body: String(body).trim(),
    severity: severity || 'info', actionUrl: actionUrl || null, admin: req.admin,
  })
  audit.record(req, { action: 'notification.sent', targetType: userId ? 'user' : 'broadcast', targetId: userId || null, reason: title, after: { title, body, audience } })
  res.status(201).json({ ok: true })
}))

router.get('/tickets', auth.requireAdmin('support.manage'), asyncRoute((req, res) => {
  const tickets = engagement.listTickets({ status: req.query.status ? String(req.query.status) : undefined })
  res.json(tickets.map((t) => ({ ...t, message_count: db.prepare('SELECT COUNT(*) c FROM support_messages WHERE ticket_id = ?').get(t.id).c })))
}))

router.get('/tickets/:id', auth.requireAdmin('support.manage'), asyncRoute((req, res) => {
  const ticket = db.prepare('SELECT * FROM support_tickets WHERE id = ?').get(req.params.id)
  if (!ticket) fail(404, 'ticket_not_found', 'Support ticket not found.')
  res.json({ ticket, messages: engagement.ticketMessages(ticket.id) })
}))

router.post('/tickets/:id/reply', auth.requireAdmin('support.manage'), asyncRoute((req, res) => {
  const body = String(req.body?.body || '').trim()
  if (body.length < 2) fail(400, 'invalid_body', 'Write a reply.')
  const status = req.body?.status
  const ticket = engagement.replyToTicket(req.params.id, {
    authorType: 'admin', authorId: req.admin.id, body, status,
  })
  audit.record(req, { action: 'ticket.replied', targetType: 'ticket', targetId: ticket.id, reason: body.slice(0, 200), after: { status: ticket.status } })
  res.json({ ticket })
}))

/* ---------------------------------------------------------------- reports */

function reportRows(kind, params) {
  switch (kind) {
    case 'deposits':
      return db.prepare(`
        SELECT d.reference, u.username, d.amount_centavos, d.currency, d.method, d.provider_reference,
          d.verification_state, d.status, d.submitted_at, d.reviewed_at, d.reviewer_name
        FROM deposits d LEFT JOIN users u ON u.id = d.user_id
        WHERE (@from IS NULL OR d.submitted_at >= @from) AND (@to IS NULL OR d.submitted_at <= @to)
        ORDER BY d.submitted_at DESC
      `).all(params)
    case 'withdrawals':
      return db.prepare(`
        SELECT w.reference, u.username, w.amount_centavos, w.fee_centavos, w.net_centavos,
          w.destination_masked, w.status, w.created_at, w.paid_at, w.payout_reference
        FROM withdrawals w LEFT JOIN users u ON u.id = w.user_id
        WHERE (@from IS NULL OR w.created_at >= @from) AND (@to IS NULL OR w.created_at <= @to)
        ORDER BY w.created_at DESC
      `).all(params)
    case 'liabilities':
      return db.prepare(`
        SELECT u.id, u.username, w.recharge_centavos, w.earnings_centavos, w.reserved_centavos,
          (w.earnings_centavos - w.reserved_centavos) AS available_centavos, w.points, w.updated_at
        FROM wallets w JOIN users u ON u.id = w.user_id
        WHERE (@from IS NULL OR w.updated_at >= @from) AND (@to IS NULL OR w.updated_at <= @to)
        ORDER BY (w.recharge_centavos + w.earnings_centavos) DESC
      `).all(params)
    case 'plans':
      return db.prepare(`
        SELECT up.id, u.username, up.plan_name, up.amount_centavos, up.status, up.start_date, up.end_date, up.source
        FROM user_plans up LEFT JOIN users u ON u.id = up.user_id
        WHERE (@from IS NULL OR up.created_at >= @from) AND (@to IS NULL OR up.created_at <= @to)
        ORDER BY up.created_at DESC
      `).all(params)
    case 'welcome_rewards':
      return db.prepare(`
        SELECT wr.user_id, u.username, wr.amount_centavos, wr.issued_at, wr.status, l.reference AS transaction_reference
        FROM welcome_rewards wr
        JOIN users u ON u.id = wr.user_id
        JOIN ledger_entries l ON l.id = wr.ledger_entry_id
        WHERE (@from IS NULL OR wr.issued_at >= @from) AND (@to IS NULL OR wr.issued_at <= @to)
        ORDER BY wr.issued_at DESC
      `).all(params)
    case 'failures':
      return db.prepare(`
        SELECT l.reference, l.kind, l.wallet, l.amount_centavos, l.status, u.username, l.created_at
        FROM ledger_entries l LEFT JOIN users u ON u.id = l.user_id
        WHERE l.status IN ('failed','reversed')
          AND (@from IS NULL OR l.created_at >= @from) AND (@to IS NULL OR l.created_at <= @to)
        ORDER BY l.created_at DESC
      `).all(params)
    case 'adjustments':
      return db.prepare(`
        SELECT l.reference, u.username, l.wallet, l.direction, l.amount_centavos,
          l.balance_before_centavos, l.balance_after_centavos, l.reason, l.note, l.actor_name, l.created_at
        FROM ledger_entries l LEFT JOIN users u ON u.id = l.user_id
        WHERE l.kind LIKE 'manual_adjustment%'
          AND (@from IS NULL OR l.created_at >= @from) AND (@to IS NULL OR l.created_at <= @to)
        ORDER BY l.created_at DESC
      `).all(params)
    case 'provider_reconciliation':
      return db.prepare(`
        SELECT d.reference, u.username, d.method, d.provider_reference, d.verification_state, d.verification_detail,
          d.status, d.submitted_at, d.reviewed_at
        FROM deposits d LEFT JOIN users u ON u.id = d.user_id
        WHERE (@from IS NULL OR d.submitted_at >= @from) AND (@to IS NULL OR d.submitted_at <= @to)
        ORDER BY d.submitted_at DESC
      `).all(params)
    case 'admin_activity':
      return db.prepare(`
        SELECT a.reference, a.actor_name, a.action, a.target_type, a.target_id, a.reason, a.created_at
        FROM audit_logs a
        WHERE (@from IS NULL OR a.created_at >= @from) AND (@to IS NULL OR a.created_at <= @to)
        ORDER BY a.created_at DESC
      `).all(params)
    default:
      return fail(400, 'unknown_report', 'Unknown report type.')
  }
}

router.get('/reports/:kind', auth.requireAdmin('ledger.read'), asyncRoute((req, res) => {
  const params = { from: req.query.from || null, to: req.query.to || null }
  const rows = reportRows(req.params.kind, params)
  res.json({ kind: req.params.kind, from: params.from, to: params.to, count: rows.length, rows })
}))

router.get('/reports/:kind/export.csv', auth.requireAdmin('ledger.read'), asyncRoute((req, res) => {
  const params = { from: req.query.from || null, to: req.query.to || null }
  const rows = reportRows(req.params.kind, params)
  if (rows.length === 0) {
    return res.status(404).json({ error: { code: 'empty_report', message: 'No records match this report for the selected dates.' } })
  }
  const headers = Object.keys(rows[0])
  const escape = (value) => {
    if (value === null || value === undefined) return ''
    const s = String(value)
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
  }
  const csv = [headers.join(','), ...rows.map((r) => headers.map((h) => escape(r[h])).join(','))].join('\n')
  audit.record(req, { action: 'report.exported', targetType: 'report', targetId: req.params.kind, reason: `${rows.length} rows exported` })
  res.setHeader('Content-Type', 'text/csv; charset=utf-8')
  res.setHeader('Content-Disposition', `attachment; filename="drivevest-${req.params.kind}-${today()}.csv"`)
  return res.send(csv)
}))

/* ------------------------------------------------------------------ audit */

router.get('/audit', auth.requireAdmin('audit.read'), asyncRoute((req, res) => {
  const { total, rows } = audit.query({
    actorId: req.query.actorId || undefined,
    action: req.query.action || undefined,
    targetType: req.query.targetType || undefined,
    targetId: req.query.targetId || undefined,
    from: req.query.from || undefined,
    to: req.query.to || undefined,
    limit: Math.min(Number(req.query.limit) || 50, 200),
    offset: Math.max(Number(req.query.offset) || 0, 0),
  })
  res.json({ total, rows: rows.map((r) => ({ ...r, before_json: r.before_json ? JSON.parse(r.before_json) : null, after_json: r.after_json ? JSON.parse(r.after_json) : null })) })
}))

/* ------------------------------------------------------ administrators */

router.get('/administrators', auth.requireAdmin('admin.manage'), asyncRoute((req, res) => {
  const admins = db.prepare('SELECT id, username, role, display_name, status, created_at, last_login FROM admin_users ORDER BY created_at').all()
  res.json(admins.map((a) => ({ ...a, permissions: auth.permissionsForRole(a.role) })))
}))

router.post('/administrators', auth.requireAdmin('admin.manage'), asyncRoute((req, res) => {
  const { username, password, displayName, role } = req.body || {}
  const clean = auth.validateUsername(username)
  auth.validatePassword(password)
  if (!['SUPER_ADMIN', 'FINANCE_ADMIN', 'SUPPORT_ADMIN', 'PLAN_MANAGER', 'AUDITOR'].includes(role)) {
    fail(400, 'invalid_role', 'Choose a valid role.')
  }
  if (db.prepare('SELECT 1 FROM admin_users WHERE username_lower = ?').get(clean.toLowerCase())) {
    fail(409, 'username_taken', 'That administrator username already exists.')
  }
  const adminId = id('adm')
  db.prepare(`
    INSERT INTO admin_users (id, username, username_lower, password_hash, role, display_name, status, created_at, provisioned_by)
    VALUES (?,?,?,?,?,?, 'Active', ?, ?)
  `).run(adminId, clean, clean.toLowerCase(), auth.hashPassword(String(password)), role, String(displayName || clean).trim(), now(), req.admin.id)

  const created = db.prepare('SELECT id, username, role, display_name, status, created_at FROM admin_users WHERE id = ?').get(adminId)
  audit.record(req, {
    action: 'admin.created', targetType: 'admin', targetId: adminId,
    reason: b_reason(req), after: created,
  })
  res.status(201).json({ admin: created })
}))

function b_reason(req) {
  return String(req.body?.reason || 'Administrator provisioned').slice(0, 200)
}

router.patch('/administrators/:id', auth.requireAdmin('admin.manage'), asyncRoute((req, res) => {
  const target = db.prepare('SELECT * FROM admin_users WHERE id = ?').get(req.params.id)
  if (!target) fail(404, 'admin_not_found', 'Administrator not found.')
  const { role, status, displayName, password, reason } = req.body || {}
  if (!reason || String(reason).trim().length < 4) fail(400, 'reason_required', 'Record why this administrator is changing.')

  if (role && !['SUPER_ADMIN', 'FINANCE_ADMIN', 'SUPPORT_ADMIN', 'PLAN_MANAGER', 'AUDITOR'].includes(role)) {
    fail(400, 'invalid_role', 'Choose a valid role.')
  }
  if (target.role === 'SUPER_ADMIN' && (role && role !== 'SUPER_ADMIN' || status === 'Disabled')) {
    const remaining = db.prepare("SELECT COUNT(*) c FROM admin_users WHERE role = 'SUPER_ADMIN' AND status = 'Active' AND id != ?").get(target.id).c
    if (remaining === 0) fail(409, 'last_super_admin', 'At least one active super administrator must remain.')
  }
  if (target.id === req.admin.id && status === 'Disabled') fail(409, 'self_disable', 'You cannot disable your own account.')

  db.prepare(`
    UPDATE admin_users SET role = COALESCE(?, role), status = COALESCE(?, status), display_name = COALESCE(?, display_name) WHERE id = ?
  `).run(
    role || null, status || null, displayName ? String(displayName).trim() : null, target.id,
  )
  if (password) db.prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?').run(auth.hashPassword(auth.validatePassword(password)), target.id)
  if (status && status !== 'Active') auth.revokeAll('admin', target.id)

  const after = db.prepare('SELECT id, username, role, display_name, status FROM admin_users WHERE id = ?').get(target.id)
  audit.record(req, {
    action: 'admin.updated', targetType: 'admin', targetId: target.id,
    reason: String(reason).trim(),
    before: { role: target.role, status: target.status, display_name: target.display_name },
    after,
  })
  res.json({ admin: after })
}))

router.get('/roles', auth.requireAdmin('users.read'), asyncRoute((req, res) => {
  const roles = db.prepare('SELECT * FROM roles ORDER BY name').all()
  res.json(roles.map((r) => ({ ...r, permissions: auth.permissionsForRole(r.name) })))
}))

/* --------------------------------------------------------------- settings */

const EDITABLE_SETTINGS = new Set([
  'platform_name', 'platform_tagline', 'welcome_reward_centavos', 'welcome_reward_wallet',
  'welcome_reward_withdrawable', 'welcome_reward_note', 'welcome_reward_bonus_referral_centavos',
  'registration_open', 'maintenance_mode', 'maintenance_message',
  'min_deposit_centavos', 'max_deposit_centavos', 'min_withdrawal_centavos',
  'withdrawal_fee_centavos', 'withdrawal_fee_percent', 'daily_withdrawal_limit_centavos',
  'second_approval_threshold_centavos', 'checkin_points', 'checkin_reward_centavos',
  'plan_settlement_enabled', 'referral_enabled',
  'support_email', 'support_hours', 'currency', 'terms_version', 'referral_terms',
])

const INTEGER_SETTINGS = new Set([
  'welcome_reward_centavos', 'welcome_reward_bonus_referral_centavos', 'min_deposit_centavos',
  'max_deposit_centavos', 'min_withdrawal_centavos', 'withdrawal_fee_centavos',
  'withdrawal_fee_percent', 'daily_withdrawal_limit_centavos', 'second_approval_threshold_centavos',
  'checkin_points', 'checkin_reward_centavos',
])

router.get('/settings', auth.requireAdmin('users.read'), asyncRoute((req, res) => {
  res.json({
    settings: allSettings(),
    editable: [...EDITABLE_SETTINGS],
    payment_providers: payments.catalogue(),
  })
}))

router.patch('/settings', auth.requireAdmin('settings.manage'), asyncRoute((req, res) => {
  const { changes, reason } = req.body || {}
  if (!changes || typeof changes !== 'object') fail(400, 'invalid_settings', 'Send the settings to change.')
  if (!reason || String(reason).trim().length < 4) fail(400, 'reason_required', 'Record why these settings are changing.')

  const before = {}
  const after = {}
  for (const [key, raw] of Object.entries(changes)) {
    if (!EDITABLE_SETTINGS.has(key)) fail(400, 'unknown_setting', `Setting "${key}" cannot be changed here.`)
    let value = String(raw)
    if (INTEGER_SETTINGS.has(key)) {
      const n = Number(value)
      if (!Number.isFinite(n) || n < 0 || !Number.isInteger(n)) fail(400, 'invalid_setting', `Setting "${key}" must be a whole number.`)
      value = String(n)
    }
    before[key] = allSettings()[key]
    after[key] = value
  }

  const run = db.transaction(() => {
    for (const [key, value] of Object.entries(after)) setSetting(key, value, req.admin.id)
  })
  run()

  audit.record(req, { action: 'settings.updated', targetType: 'system', targetId: 'settings', reason: String(reason).trim(), before, after })
  res.json({ settings: allSettings() })
}))

/* ------------------------------------------------------------------ news */

router.get('/news', auth.requireAdmin('support.manage'), asyncRoute((req, res) => {
  res.json(db.prepare('SELECT * FROM news_articles ORDER BY published_at DESC').all())
}))

router.post('/news', auth.requireAdmin('support.manage'), asyncRoute((req, res) => {
  const { title, summary, body, category, imageUrl } = req.body || {}
  if (!title || !summary || !body) fail(400, 'invalid_article', 'An article needs a title, summary and body.')
  const articleId = id('art')
  db.prepare(`
    INSERT INTO news_articles (id, title, summary, body, category, image_url, published_at, pinned)
    VALUES (?,?,?,?,?,?,?,0)
  `).run(articleId, String(title).trim(), String(summary).trim(), String(body).trim(), category || 'Platform', imageUrl || null, now())
  audit.record(req, { action: 'news.published', targetType: 'news', targetId: articleId, reason: title })
  res.status(201).json({ article: db.prepare('SELECT * FROM news_articles WHERE id = ?').get(articleId) })
}))

module.exports = router