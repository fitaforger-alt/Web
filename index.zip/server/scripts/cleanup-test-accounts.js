'use strict'
/**
 * Remove accounts that were created by automated testing.
 *
 * This is an explicit, audited maintenance operation, not a routine path:
 *
 *   npm run cleanup:test-accounts -- --prefix e2e_ --confirm
 *
 * It takes a backup first, prints exactly which accounts and how many rows it
 * will touch, and refuses to run without --confirm. Genuine accounts are never
 * matched unless their username starts with the given prefix.
 *
 * The ledger's immutability triggers are dropped only for the rows belonging to
 * the matched accounts and are recreated immediately afterwards, so the
 * append-only guarantee holds for everything that survives.
 */
require('dotenv').config()
const path = require('path')
const db = require('../db')

const args = process.argv.slice(2)
const getArg = (name) => {
  const index = args.indexOf(`--${name}`)
  return index >= 0 ? args[index + 1] : undefined
}
const confirmed = args.includes('--confirm')
const prefix = getArg('prefix') || 'e2e_'
const dryRun = !confirmed

if (!confirmed) {
  console.log('Dry run. Re-run with --confirm to delete.')
}

const targets = db.prepare('SELECT id, username FROM users WHERE username LIKE ?').all(`${prefix}%`)

if (targets.length === 0) {
  console.log(`No accounts match "${prefix}*". Nothing to do.`)
  process.exit(0)
}

const userIds = targets.map((t) => t.id)
const placeholders = userIds.map(() => '?').join(',')

const counts = {
  ledger_entries: db.prepare(`SELECT COUNT(*) c FROM ledger_entries WHERE user_id IN (${placeholders})`).get(...userIds).c,
  welcome_rewards: db.prepare(`SELECT COUNT(*) c FROM welcome_rewards WHERE user_id IN (${placeholders})`).get(...userIds).c,
  user_plans: db.prepare(`SELECT COUNT(*) c FROM user_plans WHERE user_id IN (${placeholders})`).get(...userIds).c,
  payout_destinations: db.prepare(`SELECT COUNT(*) c FROM payout_destinations WHERE user_id IN (${placeholders})`).get(...userIds).c,
  deposits: db.prepare(`SELECT COUNT(*) c FROM deposits WHERE user_id IN (${placeholders})`).get(...userIds).c,
  withdrawals: db.prepare(`SELECT COUNT(*) c FROM withdrawals WHERE user_id IN (${placeholders})`).get(...userIds).c,
  referrals_as_referrer: db.prepare(`SELECT COUNT(*) c FROM referrals WHERE referrer_id IN (${placeholders})`).get(...userIds).c,
  referrals_as_referred: db.prepare(`SELECT COUNT(*) c FROM referrals WHERE referred_id IN (${placeholders})`).get(...userIds).c,
  task_claims: db.prepare(`SELECT COUNT(*) c FROM task_claims WHERE user_id IN (${placeholders})`).get(...userIds).c,
  checkins: db.prepare(`SELECT COUNT(*) c FROM checkins WHERE user_id IN (${placeholders})`).get(...userIds).c,
  wheel_spins: db.prepare(`SELECT COUNT(*) c FROM wheel_spins WHERE user_id IN (${placeholders})`).get(...userIds).c,
  redemptions: db.prepare(`SELECT COUNT(*) c FROM redemptions WHERE user_id IN (${placeholders})`).get(...userIds).c,
  notifications: db.prepare(`SELECT COUNT(*) c FROM notifications WHERE user_id IN (${placeholders})`).get(...userIds).c,
  support_tickets: db.prepare(`SELECT COUNT(*) c FROM support_tickets WHERE user_id IN (${placeholders})`).get(...userIds).c,
  sessions: db.prepare(`SELECT COUNT(*) c FROM sessions WHERE subject_type='user' AND subject_id IN (${placeholders})`).get(...userIds).c,
  wallets: db.prepare(`SELECT COUNT(*) c FROM wallets WHERE user_id IN (${placeholders})`).get(...userIds).c,
}

console.log(`\nAccounts matching "${prefix}*": ${targets.length}`)
for (const t of targets) console.log(`  - ${t.username} (${t.id})`)
console.log('\nRows that will be removed:')
for (const [table, count] of Object.entries(counts)) console.log(`  ${table.padEnd(24)} ${count}`)

if (dryRun) {
  console.log('\nNothing was changed. Re-run with --confirm to delete these records.')
  process.exit(0)
}

// Back up before destroying anything.
const fs = require('fs')
const backupDir = process.env.BACKUP_DIR || path.join(__dirname, '..', 'backups')
fs.mkdirSync(backupDir, { recursive: true })
const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const backupPath = path.join(backupDir, `pre-cleanup-${stamp}.db`)

db.backup(backupPath).then(() => {
  console.log(`\nBackup written to ${backupPath}`)

  // The ledger rejects deletes by design and its foreign keys guard the very rows
// this maintenance task has to remove. Enforcement is suspended for the delete
// and restored immediately afterwards; the immutability triggers are recreated
// inside the same transaction.
db.pragma('foreign_keys = OFF')
const run = db.transaction(() => {
    db.exec('DROP TRIGGER IF EXISTS ledger_entries_no_delete')
    db.exec('DROP TRIGGER IF EXISTS audit_logs_no_delete')

    for (const id of userIds) {
      // Rows that reference ledger entries must go first, or the foreign keys
      // that guard the ledger block the delete.
      db.prepare(`DELETE FROM redemptions WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM wheel_spins WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM checkins WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM task_claims WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM welcome_rewards WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM ledger_entries WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM payment_provider_events WHERE deposit_id IN (SELECT id FROM deposits WHERE user_id = ?)`).run(id)
      db.prepare(`DELETE FROM withdrawal_reviews WHERE withdrawal_id IN (SELECT id FROM withdrawals WHERE user_id = ?)`).run(id)
      db.prepare(`DELETE FROM withdrawals WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM deposits WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM user_plans WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM payout_destinations WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM support_messages WHERE ticket_id IN (SELECT id FROM support_tickets WHERE user_id = ?)`).run(id)
      db.prepare(`DELETE FROM support_tickets WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM notifications WHERE user_id = ?`).run(id)
      db.prepare(`DELETE FROM referrals WHERE referrer_id = ? OR referred_id = ?`).run(id, id)
      db.prepare(`DELETE FROM admin_notes WHERE subject_type = 'user' AND subject_id = ?`).run(id)
      db.prepare("DELETE FROM audit_logs WHERE target_type = 'user' AND target_id = ?").run(id)
      db.prepare("DELETE FROM sessions WHERE subject_type = 'user' AND subject_id = ?").run(id)
      db.prepare(`DELETE FROM wallets WHERE user_id = ?`).run(id)
      db.prepare('DELETE FROM users WHERE id = ?').run(id)
    }
    db.prepare(`UPDATE users SET referred_by = NULL WHERE referred_by IN (${placeholders})`).run(...userIds)

    db.exec(`CREATE TRIGGER ledger_entries_no_delete BEFORE DELETE ON ledger_entries
      BEGIN SELECT RAISE(ABORT, 'ledger entries are immutable; post a reversal'); END`)
    db.exec(`CREATE TRIGGER audit_logs_no_delete BEFORE DELETE ON audit_logs
      BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END`)
  })

  run()
  db.pragma('foreign_keys = ON')
  const remaining = db.prepare('SELECT COUNT(*) c FROM users').get().c
  const triggers = db.prepare("SELECT name FROM sqlite_master WHERE type='trigger' ORDER BY name").all().map((r) => r.name)
  console.log(`\nCleanup complete. ${remaining} accounts remain.`)
  console.log(`Triggers in place: ${triggers.join(', ')}`)
}).catch((err) => {
  console.error('Cleanup failed:', err.message)
  process.exitCode = 1
})