'use strict'
/** Print which migrations have been applied. */
const path = require('path')
const db = require('../db')

const applied = db.prepare('SELECT id, applied_at FROM schema_migrations ORDER BY id').all()
console.log(`Database: ${process.env.DATABASE_PATH || path.join(__dirname, '..', 'drivevest.db')}`)
console.log(`Applied migrations: ${applied.length}`)
for (const row of applied) console.log(`  ${row.id}  ${row.applied_at}`)

const counts = db.prepare(`
  SELECT
    (SELECT COUNT(*) FROM users) users,
    (SELECT COUNT(*) FROM wallets) wallets,
    (SELECT COUNT(*) FROM ledger_entries) ledger,
    (SELECT COUNT(*) FROM welcome_rewards) welcome_rewards,
    (SELECT COUNT(*) FROM plans) plans,
    (SELECT COUNT(*) FROM user_plans) user_plans,
    (SELECT COUNT(*) FROM deposits) deposits,
    (SELECT COUNT(*) FROM withdrawals) withdrawals,
    (SELECT COUNT(*) FROM admin_users) admins
`).get()
console.log('\nRow counts:', counts)