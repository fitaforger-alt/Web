'use strict'
/**
 * One-time administrator provisioning.
 *
 * There is no public administrator registration. The first super administrator
 * is created by this script on the server console:
 *
 *   npm run setup:admin -- --username olivia --password 'strong-pass-123' --name 'Olivia'
 *
 * A random password is generated and printed when --password is omitted.
 */
require('dotenv').config()
const db = require('../db')
const auth = require('../lib/auth')
const { now } = require('../lib/util')

const ROLES = ['SUPER_ADMIN', 'FINANCE_ADMIN', 'SUPPORT_ADMIN', 'PLAN_MANAGER', 'AUDITOR']

function parseArgs(argv) {
  const args = {}
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i]
    if (!token.startsWith('--')) continue
    const key = token.slice(2)
    const next = argv[i + 1]
    if (next && !next.startsWith('--')) { args[key] = next; i += 1 } else args[key] = true
  }
  return args
}

function main() {
  const args = parseArgs(process.argv.slice(2))
  const username = auth.validateUsername(args.username || 'admin')
  const displayName = String(args.name || username).trim()
  const role = String(args.role || 'SUPER_ADMIN').toUpperCase()
  if (!ROLES.includes(role)) {
    console.error(`Unknown role "${role}". Choose one of: ${ROLES.join(', ')}`)
    process.exit(1)
  }

  const existing = db.prepare('SELECT id FROM admin_users WHERE username_lower = ?').get(username.toLowerCase())
  if (existing) {
    console.error(`Administrator "${username}" already exists. Use the admin panel to change its role or reset its password.`)
    process.exit(1)
  }

  let password = args.password
  let generated = false
  if (!password) {
    password = auth.randomToken(12).replace(/[^A-Za-z0-9]/g, '') + '9a'
    generated = true
  }
  const clean = auth.validatePassword(password)

  const id = `adm_${require('crypto').randomBytes(8).toString('hex')}`
  db.prepare(`
    INSERT INTO admin_users (id, username, username_lower, password_hash, role, display_name, status, created_at, provisioned_by)
    VALUES (?,?,?,?,?,?, 'Active', ?, 'cli-setup')
  `).run(id, username, username.toLowerCase(), auth.hashPassword(clean), role, displayName, now())

  console.log('Administrator provisioned.')
  console.log(`  username: ${username}`)
  console.log(`  role:     ${role}`)
  if (generated) console.log(`  password: ${password}   (generated — store it now, it is not saved in readable form)`)
  console.log('\nSign in at /admin/login. Rotate this password from Administrators after the first sign-in.')
}

if (require.main === module) main()

module.exports = { main }