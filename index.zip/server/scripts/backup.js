'use strict'
/** Take a consistent online backup of the authoritative database. */
const fs = require('fs')
const path = require('path')

process.env.DATABASE_PATH = process.env.DATABASE_PATH || path.join(__dirname, '..', 'drivevest.db')
const db = require('../db')

const dir = process.env.BACKUP_DIR || path.join(__dirname, '..', 'backups')
fs.mkdirSync(dir, { recursive: true })
const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const dest = path.join(dir, `drivevest-${stamp}.db`)

db.backup(dest)
  .then(() => {
    const size = fs.statSync(dest).size
    console.log(`Backup written: ${dest} (${(size / 1024).toFixed(1)} KB)`)
  })
  .catch((err) => {
    console.error('Backup failed:', err.message)
    process.exitCode = 1
  })