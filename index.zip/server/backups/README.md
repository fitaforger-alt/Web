# Backups

Point-in-time snapshots taken by `npm run backup` and by
`npm run cleanup:test-accounts` before it deletes anything.

These files are ignored by git. They are kept locally so a bad maintenance run
can be undone by copying one back over `drivevest.db` while the server is
stopped.

Naming:
- `drivevest-<timestamp>.db` — routine backup.
- `pre-cleanup-<timestamp>.db` — snapshot taken immediately before a test-account
  cleanup, holding the exact state that existed before the deletion.