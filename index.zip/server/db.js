'use strict'
/**
 * DriveVest database layer.
 *
 * One SQLite file is the single authoritative store for both the customer site
 * and the admin panel. Schema changes ship as ordered migrations so an existing
 * database is upgraded in place instead of being replaced.
 *
 * Money is stored as integer centavos. No floating point arithmetic touches a
 * balance anywhere in this codebase.
 */
const path = require('path')
const fs = require('fs')
const Database = require('better-sqlite3')

const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, 'drivevest.db')
const BACKUP_DIR = path.join(__dirname, 'backups')

const db = new Database(DB_PATH)
db.pragma('journal_mode = WAL')
db.pragma('foreign_keys = ON')
db.pragma('busy_timeout = 5000')

/* ---------------------------------------------------------------- helpers */

function backupDatabase() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true })
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const dest = path.join(BACKUP_DIR, `drivevest-${stamp}.db`)
  db.backup(dest).catch((err) => {
    console.error('[db] backup failed:', err.message)
  })
  return dest
}

/* -------------------------------------------------------------- migrations */

const MIGRATIONS = [
  {
    id: '000_legacy_upgrade',
    up(db) {
      const hasTable = (name) =>
        !!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(name)
      const columns = (table) => {
        try {
          return db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name)
        } catch {
          return []
        }
      }

      // The original project shipped single-file tables that used peso integers,
      // synthetic emails and an auth role on admins. Rebuild them into the
      // authoritative schema, carrying every existing row across intact. This runs
      // before the core schema so the new indexes always see final columns.
      if (hasTable('users')) {
        const legacy = columns('users')
        if (!legacy.includes('username_lower')) {
          db.exec(`
            CREATE TABLE users_migrated (
              id TEXT PRIMARY KEY,
              username TEXT NOT NULL,
              username_lower TEXT NOT NULL UNIQUE,
              password_hash TEXT NOT NULL,
              status TEXT NOT NULL DEFAULT 'Active',
              membership TEXT NOT NULL DEFAULT 'Bronze',
              referral_code TEXT NOT NULL UNIQUE,
              referred_by TEXT REFERENCES users(id),
              phone TEXT,
              note TEXT,
              created_at TEXT NOT NULL,
              last_login TEXT
            );
          `)
          const existing = db.prepare('SELECT * FROM users').all()
          const insert = db.prepare(
            `INSERT INTO users_migrated (id, username, username_lower, password_hash, status, membership, referral_code, referred_by, phone, note, created_at, last_login)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          )
          for (const u of existing) {
            const code = u.referral_code || `DV-${String(u.id).replace(/-/g, '').slice(0, 8).toUpperCase()}`
            insert.run(
              u.id,
              u.username,
              String(u.username).toLowerCase(),
              u.password_hash,
              u.status || 'Active',
              u.membership || 'Bronze',
              code,
              u.referred_by || null,
              null,
              null,
              u.created_at,
              u.last_login || null,
            )
          }
          db.exec('DROP TABLE users; ALTER TABLE users_migrated RENAME TO users;')
        }
      }

      if (hasTable('wallets')) {
        const legacy = columns('wallets')
        if (!legacy.includes('recharge_centavos')) {
          db.exec(`
            CREATE TABLE wallets_migrated (
              user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
              recharge_centavos INTEGER NOT NULL DEFAULT 0,
              earnings_centavos INTEGER NOT NULL DEFAULT 0,
              points INTEGER NOT NULL DEFAULT 0,
              reserved_centavos INTEGER NOT NULL DEFAULT 0,
              updated_at TEXT NOT NULL
            );
          `)
          const rows = db.prepare('SELECT * FROM wallets').all()
          const insert = db.prepare(
            'INSERT INTO wallets_migrated (user_id, recharge_centavos, earnings_centavos, points, reserved_centavos, updated_at) VALUES (?,?,?,?,0,?)',
          )
          for (const w of rows) {
            insert.run(w.user_id, (w.recharge || 0) * 100, (w.earnings || 0) * 100, w.points || 0, new Date().toISOString())
          }
          db.exec('DROP TABLE wallets; ALTER TABLE wallets_migrated RENAME TO wallets;')
        }
      }

      if (hasTable('ledger')) {
        const legacy = columns('ledger')
        if (!legacy.includes('amount_centavos')) {
          db.exec(`
            CREATE TABLE ledger_entries_migrated (
              id TEXT PRIMARY KEY,
              reference TEXT NOT NULL UNIQUE,
              user_id TEXT NOT NULL REFERENCES users(id),
              kind TEXT NOT NULL,
              wallet TEXT NOT NULL,
              direction TEXT NOT NULL,
              amount_centavos INTEGER NOT NULL,
              balance_before_centavos INTEGER,
              balance_after_centavos INTEGER,
              status TEXT NOT NULL,
              reason TEXT,
              note TEXT,
              reversal_of TEXT,
              idempotency_key TEXT,
              correlation_id TEXT,
              actor_type TEXT NOT NULL DEFAULT 'system',
              actor_id TEXT,
              actor_name TEXT,
              created_at TEXT NOT NULL
            );
          `)
          const rows = db.prepare('SELECT * FROM ledger').all()
          const insert = db.prepare(
            `INSERT OR IGNORE INTO ledger_entries_migrated
              (id, reference, user_id, kind, wallet, direction, amount_centavos, status, reason, note, actor_type, actor_name, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,'user',?,?)`,
          )
          for (const l of rows) {
            const direction = String(l.direction).toLowerCase() === 'credit' ? 'credit' : 'debit'
            const amount = Math.abs(l.amount || 0) * 100
            if (amount === 0) continue
            insert.run(l.id, l.id, l.user_id, l.type, l.wallet, direction, amount, l.status, l.reason || null, null, l.actor || 'system', l.created_at)
          }
          db.exec('DROP TABLE ledger; DROP TABLE IF EXISTS ledger_entries; ALTER TABLE ledger_entries_migrated RENAME TO ledger_entries;')
        }
      }

      if (hasTable('welcome_rewards')) {
        const legacy = columns('welcome_rewards')
        if (!legacy.includes('amount_centavos')) {
          db.exec(`
            CREATE TABLE welcome_rewards_migrated (
              user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
              amount_centavos INTEGER NOT NULL,
              ledger_entry_id TEXT NOT NULL REFERENCES ledger_entries(id),
              status TEXT NOT NULL DEFAULT 'Issued',
              issued_at TEXT NOT NULL
            );
          `)
          const rows = db.prepare('SELECT * FROM welcome_rewards').all()
          const insert = db.prepare(
            'INSERT OR IGNORE INTO welcome_rewards_migrated (user_id, amount_centavos, ledger_entry_id, status, issued_at) VALUES (?,?,?,?,?)',
          )
          for (const r of rows) {
            const entry = db.prepare('SELECT id FROM ledger_entries WHERE id=?').get(r.transaction_id)
            if (!entry) continue
            insert.run(r.user_id, r.amount * 100, entry.id, 'Issued', r.issued_at)
          }
          db.exec('DROP TABLE welcome_rewards; ALTER TABLE welcome_rewards_migrated RENAME TO welcome_rewards;')
        }
      }

      if (hasTable('plans')) {
        const legacy = columns('plans')
        if (!legacy.includes('price_centavos')) {
          db.exec(`
            CREATE TABLE plans_migrated (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              category TEXT NOT NULL DEFAULT 'daily',
              description TEXT,
              terms TEXT,
              eligibility TEXT,
              image_url TEXT,
              price_centavos INTEGER NOT NULL,
              duration_days INTEGER NOT NULL,
              projected_daily_centavos INTEGER NOT NULL DEFAULT 0,
              slots_total INTEGER NOT NULL DEFAULT 0,
              slots_taken INTEGER NOT NULL DEFAULT 0,
              active INTEGER NOT NULL DEFAULT 1,
              archived INTEGER NOT NULL DEFAULT 0,
              current_version INTEGER NOT NULL DEFAULT 1,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );
          `)
          const images = {
            'PL-1': 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800&q=80',
            'PL-2': 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80',
            'PL-3': 'https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80',
            'PL-4': 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800&q=80',
            'PL-5': 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80',
          }
          const rows = db.prepare('SELECT * FROM plans').all()
          const insert = db.prepare(
            `INSERT INTO plans_migrated (id, name, category, description, terms, eligibility, image_url, price_centavos, duration_days, projected_daily_centavos, slots_total, slots_taken, active, archived, current_version, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,0,?,0,1,?,?)`,
          )
          const ts = new Date().toISOString()
          for (const p of rows) {
            insert.run(
              p.id,
              p.name,
              Number(String(p.id).replace(/\D/g, '')) >= 4 || p.price >= 3000 ? 'vip' : 'daily',
              `${p.name} plan`,
              'Projected reward is an estimate, not a guarantee of profit. Withdrawable balance accrues through daily settlement.',
              'Minimum membership: Bronze. One active plan of this tier per account.',
              images[p.id] || null,
              p.price * 100,
              p.duration,
              p.reward * 100,
              p.availability || 0,
              p.active,
              ts,
              ts,
            )
          }
          db.exec('DROP TABLE plans; ALTER TABLE plans_migrated RENAME TO plans;')
        }
      }

      if (hasTable('user_plans')) {
        const legacy = columns('user_plans')
        if (!legacy.includes('amount_centavos')) {
          db.exec(`
            CREATE TABLE user_plans_migrated (
              id TEXT PRIMARY KEY,
              user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
              plan_id TEXT REFERENCES plans(id),
              plan_name TEXT NOT NULL,
              plan_version INTEGER NOT NULL DEFAULT 1,
              terms_snapshot TEXT NOT NULL,
              amount_centavos INTEGER NOT NULL,
              projected_daily_centavos INTEGER NOT NULL DEFAULT 0,
              status TEXT NOT NULL DEFAULT 'active',
              source TEXT NOT NULL DEFAULT 'purchase',
              ledger_entry_id TEXT,
              start_date TEXT NOT NULL,
              end_date TEXT NOT NULL,
              days_completed INTEGER NOT NULL DEFAULT 0,
              settled_at TEXT,
              created_at TEXT NOT NULL
            );
          `)
          const rows = db.prepare('SELECT * FROM user_plans').all()
          const insert = db.prepare(
            `INSERT INTO user_plans_migrated (id, user_id, plan_id, plan_name, plan_version, terms_snapshot, amount_centavos, projected_daily_centavos, status, source, start_date, end_date, days_completed, settled_at, created_at)
             VALUES (?,?,?,?,1,?,?,?,?,'purchase',?,?,0,NULL,?)`,
          )
          for (const up of rows) {
            insert.run(
              up.id, up.user_id, up.plan_id, up.plan_name,
              'Migrated from the original plan record.',
              up.amount * 100, up.daily_reward * 100,
              String(up.status).toLowerCase(),
              up.start_date, up.end_date,
              up.start_date,
            )
          }
          db.exec('DROP TABLE user_plans; ALTER TABLE user_plans_migrated RENAME TO user_plans;')
        }
      }

      if (hasTable('bank_destinations')) {
        const legacy = columns('bank_destinations')
        if (!legacy.includes('masked')) {
          db.exec(`
            CREATE TABLE payout_destinations_migrated (
              id TEXT PRIMARY KEY,
              user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
              holder_name TEXT NOT NULL,
              provider TEXT NOT NULL,
              account_number TEXT NOT NULL,
              masked TEXT NOT NULL,
              verified INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL,
              UNIQUE (user_id, provider, account_number)
            );
          `)
          const rows = db.prepare('SELECT * FROM bank_destinations').all()
          const insert = db.prepare(
            'INSERT OR IGNORE INTO payout_destinations_migrated (id, user_id, holder_name, provider, account_number, masked, verified, created_at) VALUES (?,?,?,?,?,?,0,?)',
          )
          for (const b of rows) {
            insert.run(b.id, b.user_id, b.holder, b.provider, b.account, `${b.provider} ****${String(b.account).slice(-4)}`, new Date().toISOString())
          }
          db.exec('DROP TABLE bank_destinations; DROP TABLE IF EXISTS payout_destinations; ALTER TABLE payout_destinations_migrated RENAME TO payout_destinations;')
        }
      }

      if (hasTable('referrals')) {
        const legacy = columns('referrals')
        if (!legacy.includes('level')) {
          db.exec(`
            CREATE TABLE referrals_migrated (
              id TEXT PRIMARY KEY,
              referrer_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
              referred_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
              level INTEGER NOT NULL DEFAULT 1,
              code_used TEXT NOT NULL,
              reward_centavos INTEGER NOT NULL DEFAULT 0,
              reward_ledger_entry_id TEXT,
              status TEXT NOT NULL DEFAULT 'qualified',
              created_at TEXT NOT NULL
            );
          `)
          const rows = db.prepare('SELECT * FROM referrals').all()
          const insert = db.prepare(
            `INSERT OR IGNORE INTO referrals_migrated (id, referrer_id, referred_id, level, code_used, reward_centavos, status, created_at)
             VALUES (?,?,?,1,?,?, 'qualified', ?)`,
          )
          for (const r of rows) insert.run(r.id, r.referrer_id, r.referred_id, r.code, (r.commission || 0) * 100, r.created_at)
          db.exec('DROP TABLE referrals; ALTER TABLE referrals_migrated RENAME TO referrals;')
        }
      }

      if (hasTable('audit_logs')) {
        const legacy = columns('audit_logs')
        if (!legacy.includes('actor_type')) {
          db.exec(`
            CREATE TABLE audit_logs_migrated (
              id TEXT PRIMARY KEY,
              actor_type TEXT NOT NULL,
              actor_id TEXT,
              actor_name TEXT,
              action TEXT NOT NULL,
              target_type TEXT,
              target_id TEXT,
              reason TEXT,
              before_json TEXT,
              after_json TEXT,
              transaction_reference TEXT,
              correlation_id TEXT,
              ip TEXT,
              created_at TEXT NOT NULL
            );
          `)
          const rows = db.prepare('SELECT * FROM audit_logs').all()
          const insert = db.prepare(
            `INSERT OR IGNORE INTO audit_logs_migrated (id, actor_type, actor_id, action, target_type, target_id, reason, created_at)
             VALUES (?,'admin',?,?,?,?,?,?)`,
          )
          for (const a of rows) insert.run(a.id, a.admin_id, a.action, 'legacy', a.target, a.reason, a.created_at)
          db.exec('DROP TABLE audit_logs; ALTER TABLE audit_logs_migrated RENAME TO audit_logs;')
        }
      }

      if (hasTable('deposits')) {
        const legacy = columns('deposits')
        if (!legacy.includes('amount_centavos')) {
          db.exec(`
            CREATE TABLE deposits_migrated (
              id TEXT PRIMARY KEY,
              reference TEXT NOT NULL UNIQUE,
              user_id TEXT NOT NULL REFERENCES users(id),
              amount_centavos INTEGER NOT NULL,
              currency TEXT NOT NULL DEFAULT 'PHP',
              method TEXT NOT NULL,
              provider TEXT,
              provider_reference TEXT,
              verification_state TEXT NOT NULL DEFAULT 'unverified',
              verification_detail TEXT,
              status TEXT NOT NULL DEFAULT 'pending',
              submitted_at TEXT NOT NULL,
              reviewed_at TEXT,
              reviewer_id TEXT,
              reviewer_name TEXT,
              review_reason TEXT,
              credited_ledger_entry_id TEXT,
              idempotency_key TEXT
            );
          `)
          const rows = db.prepare('SELECT * FROM deposits').all()
          const insert = db.prepare(
            `INSERT OR IGNORE INTO deposits_migrated (id, reference, user_id, amount_centavos, method, provider_reference, status, submitted_at)
             VALUES (?,?,?,?,?,?,?,?)`,
          )
          for (const d of rows) {
            insert.run(
              d.id, d.id, d.user_id, (d.amount || 0) * 100, d.method, d.provider_ref || null,
              String(d.status).toLowerCase(), d.created_at,
            )
          }
          db.exec('DROP TABLE deposits; ALTER TABLE deposits_migrated RENAME TO deposits;')
        }
      }

      if (hasTable('withdrawals')) {
        const legacy = columns('withdrawals')
        if (!legacy.includes('amount_centavos')) {
          db.exec(`
            CREATE TABLE withdrawals_migrated (
              id TEXT PRIMARY KEY,
              reference TEXT NOT NULL UNIQUE,
              user_id TEXT NOT NULL REFERENCES users(id),
              destination_id TEXT,
              destination_masked TEXT NOT NULL,
              amount_centavos INTEGER NOT NULL,
              fee_centavos INTEGER NOT NULL DEFAULT 0,
              net_centavos INTEGER NOT NULL,
              status TEXT NOT NULL DEFAULT 'pending',
              requires_second_approval INTEGER NOT NULL DEFAULT 0,
              first_approval_id TEXT,
              second_approval_id TEXT,
              hold_ledger_entry_id TEXT,
              payout_reference TEXT,
              payout_proof TEXT,
              paid_at TEXT,
              paid_by TEXT,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              idempotency_key TEXT
            );
          `)
          const rows = db.prepare('SELECT * FROM withdrawals').all()
          const insert = db.prepare(
            `INSERT OR IGNORE INTO withdrawals_migrated (id, reference, user_id, destination_masked, amount_centavos, fee_centavos, net_centavos, status, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?)`,
          )
          for (const w of rows) {
            insert.run(
              w.id, w.id, w.user_id, w.destination || 'unknown',
              (w.amount || 0) * 100, (w.fee || 0) * 100, (w.net || 0) * 100,
              String(w.status).toLowerCase(), w.created_at, w.created_at,
            )
          }
          db.exec('DROP TABLE withdrawals; ALTER TABLE withdrawals_migrated RENAME TO withdrawals;')
        }
      }

      if (hasTable('admin_users')) {
        const legacy = columns('admin_users')
        if (!legacy.includes('username_lower')) {
          db.exec(`
            CREATE TABLE admin_users_migrated (
              id TEXT PRIMARY KEY,
              username TEXT NOT NULL UNIQUE,
              username_lower TEXT NOT NULL UNIQUE,
              password_hash TEXT NOT NULL,
              role TEXT NOT NULL,
              display_name TEXT NOT NULL,
              status TEXT NOT NULL DEFAULT 'Active',
              created_at TEXT NOT NULL,
              last_login TEXT,
              last_login_ip TEXT,
              provisioned_by TEXT
            );
          `)
          const rows = db.prepare('SELECT * FROM admin_users').all()
          const insert = db.prepare(
            `INSERT OR IGNORE INTO admin_users_migrated (id, username, username_lower, password_hash, role, display_name, status, created_at, last_login, provisioned_by)
             VALUES (?,?,?,?,?,?,'Active',?,NULL,'migration')`,
          )
          const ts = new Date().toISOString()
          for (const a of rows) {
            const role = a.role === 'SUPER_ADMIN' || a.role === 'FINANCE_ADMIN' ? a.role : 'AUDITOR'
            insert.run(a.id, a.username, String(a.username).toLowerCase(), a.password_hash, role, a.name || a.username, ts)
          }
          db.exec('DROP TABLE admin_users; ALTER TABLE admin_users_migrated RENAME TO admin_users;')
        }
      }
    },
  },
  {
    id: '001_core_schema',
    up(db) {
      db.exec(`
        CREATE TABLE IF NOT EXISTS schema_migrations (
          id TEXT PRIMARY KEY,
          applied_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS roles (
          name TEXT PRIMARY KEY,
          description TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS permissions (
          name TEXT PRIMARY KEY,
          description TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS role_permissions (
          role TEXT NOT NULL REFERENCES roles(name) ON DELETE CASCADE,
          permission TEXT NOT NULL REFERENCES permissions(name) ON DELETE CASCADE,
          PRIMARY KEY (role, permission)
        );

        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY,
          username TEXT NOT NULL,
          username_lower TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Active',
          membership TEXT NOT NULL DEFAULT 'Bronze',
          referral_code TEXT NOT NULL UNIQUE,
          referred_by TEXT REFERENCES users(id),
          phone TEXT,
          note TEXT,
          created_at TEXT NOT NULL,
          last_login TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code);

        CREATE TABLE IF NOT EXISTS sessions (
          id TEXT PRIMARY KEY,
          token_hash TEXT NOT NULL UNIQUE,
          subject_type TEXT NOT NULL,
          subject_id TEXT NOT NULL,
          csrf_token TEXT NOT NULL,
          created_at TEXT NOT NULL,
          last_seen_at TEXT NOT NULL,
          expires_at TEXT NOT NULL,
          revoked_at TEXT,
          ip TEXT,
          user_agent TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_sessions_subject ON sessions(subject_type, subject_id);

        CREATE TABLE IF NOT EXISTS wallets (
          user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
          recharge_centavos INTEGER NOT NULL DEFAULT 0,
          earnings_centavos INTEGER NOT NULL DEFAULT 0,
          points INTEGER NOT NULL DEFAULT 0,
          reserved_centavos INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL,
          CHECK (recharge_centavos >= 0),
          CHECK (earnings_centavos >= 0),
          CHECK (points >= 0),
          CHECK (reserved_centavos >= 0),
          CHECK (reserved_centavos <= earnings_centavos)
        );

        CREATE TABLE IF NOT EXISTS ledger_entries (
          id TEXT PRIMARY KEY,
          reference TEXT NOT NULL UNIQUE,
          user_id TEXT NOT NULL REFERENCES users(id),
          kind TEXT NOT NULL,
          wallet TEXT NOT NULL,
          direction TEXT NOT NULL,
          amount_centavos INTEGER NOT NULL CHECK (amount_centavos > 0),
          balance_before_centavos INTEGER,
          balance_after_centavos INTEGER,
          status TEXT NOT NULL,
          reason TEXT,
          note TEXT,
          reversal_of TEXT REFERENCES ledger_entries(id),
          idempotency_key TEXT UNIQUE,
          correlation_id TEXT,
          actor_type TEXT NOT NULL DEFAULT 'system',
          actor_id TEXT,
          actor_name TEXT,
          created_at TEXT NOT NULL,
          CHECK (direction IN ('credit','debit'))
        );
        CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger_entries(user_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_ledger_kind ON ledger_entries(kind, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_ledger_status ON ledger_entries(status);

        CREATE TABLE IF NOT EXISTS welcome_rewards (
          user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
          amount_centavos INTEGER NOT NULL,
          ledger_entry_id TEXT NOT NULL REFERENCES ledger_entries(id),
          status TEXT NOT NULL DEFAULT 'Issued',
          issued_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS plans (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          category TEXT NOT NULL DEFAULT 'daily',
          description TEXT,
          terms TEXT,
          eligibility TEXT,
          image_url TEXT,
          price_centavos INTEGER NOT NULL CHECK (price_centavos >= 0),
          duration_days INTEGER NOT NULL CHECK (duration_days > 0),
          projected_daily_centavos INTEGER NOT NULL DEFAULT 0,
          slots_total INTEGER NOT NULL DEFAULT 0,
          slots_taken INTEGER NOT NULL DEFAULT 0,
          active INTEGER NOT NULL DEFAULT 1,
          archived INTEGER NOT NULL DEFAULT 0,
          current_version INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS plan_versions (
          id TEXT PRIMARY KEY,
          plan_id TEXT NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
          version INTEGER NOT NULL,
          snapshot TEXT NOT NULL,
          change_reason TEXT,
          created_by TEXT,
          created_at TEXT NOT NULL,
          UNIQUE (plan_id, version)
        );

        CREATE TABLE IF NOT EXISTS user_plans (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          plan_id TEXT REFERENCES plans(id),
          plan_name TEXT NOT NULL,
          plan_version INTEGER NOT NULL DEFAULT 1,
          terms_snapshot TEXT NOT NULL,
          amount_centavos INTEGER NOT NULL,
          projected_daily_centavos INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'active',
          source TEXT NOT NULL DEFAULT 'purchase',
          ledger_entry_id TEXT,
          start_date TEXT NOT NULL,
          end_date TEXT NOT NULL,
          days_completed INTEGER NOT NULL DEFAULT 0,
          settled_at TEXT,
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_user_plans_user ON user_plans(user_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_user_plans_status ON user_plans(status, end_date);

        CREATE TABLE IF NOT EXISTS payout_destinations (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          holder_name TEXT NOT NULL,
          provider TEXT NOT NULL,
          account_number TEXT NOT NULL,
          masked TEXT NOT NULL,
          verified INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          UNIQUE (user_id, provider, account_number)
        );

        CREATE TABLE IF NOT EXISTS referrals (
          id TEXT PRIMARY KEY,
          referrer_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          referred_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
          level INTEGER NOT NULL DEFAULT 1,
          code_used TEXT NOT NULL,
          reward_centavos INTEGER NOT NULL DEFAULT 0,
          reward_ledger_entry_id TEXT,
          status TEXT NOT NULL DEFAULT 'qualified',
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS admin_users (
          id TEXT PRIMARY KEY,
          username TEXT NOT NULL UNIQUE,
          username_lower TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL REFERENCES roles(name),
          display_name TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Active',
          created_at TEXT NOT NULL,
          last_login TEXT,
          last_login_ip TEXT,
          provisioned_by TEXT
        );

        CREATE TABLE IF NOT EXISTS admin_notes (
          id TEXT PRIMARY KEY,
          subject_type TEXT NOT NULL,
          subject_id TEXT NOT NULL,
          body TEXT NOT NULL,
          author_id TEXT NOT NULL,
          author_name TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_admin_notes_subject ON admin_notes(subject_type, subject_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS audit_logs (
          id TEXT PRIMARY KEY,
          actor_type TEXT NOT NULL,
          actor_id TEXT,
          actor_name TEXT,
          action TEXT NOT NULL,
          target_type TEXT,
          target_id TEXT,
          reason TEXT,
          before_json TEXT,
          after_json TEXT,
          transaction_reference TEXT,
          correlation_id TEXT,
          ip TEXT,
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_logs(actor_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_audit_target ON audit_logs(target_type, target_id, created_at DESC);

        CREATE TRIGGER IF NOT EXISTS audit_logs_no_update
          BEFORE UPDATE ON audit_logs
          BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;
        CREATE TRIGGER IF NOT EXISTS audit_logs_no_delete
          BEFORE DELETE ON audit_logs
          BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;

        CREATE TRIGGER IF NOT EXISTS ledger_entries_no_update
          BEFORE UPDATE ON ledger_entries
          BEGIN SELECT RAISE(ABORT, 'ledger entries are immutable; post a reversal'); END;
        CREATE TRIGGER IF NOT EXISTS ledger_entries_no_delete
          BEFORE DELETE ON ledger_entries
          BEGIN SELECT RAISE(ABORT, 'ledger entries are immutable; post a reversal'); END;

        CREATE TABLE IF NOT EXISTS deposits (
          id TEXT PRIMARY KEY,
          reference TEXT NOT NULL UNIQUE,
          user_id TEXT NOT NULL REFERENCES users(id),
          amount_centavos INTEGER NOT NULL CHECK (amount_centavos > 0),
          currency TEXT NOT NULL DEFAULT 'PHP',
          method TEXT NOT NULL,
          provider TEXT,
          provider_reference TEXT,
          verification_state TEXT NOT NULL DEFAULT 'unverified',
          verification_detail TEXT,
          status TEXT NOT NULL DEFAULT 'pending',
          submitted_at TEXT NOT NULL,
          reviewed_at TEXT,
          reviewer_id TEXT,
          reviewer_name TEXT,
          review_reason TEXT,
          credited_ledger_entry_id TEXT,
          idempotency_key TEXT UNIQUE
        );
        CREATE INDEX IF NOT EXISTS idx_deposits_status ON deposits(status, submitted_at DESC);
        CREATE INDEX IF NOT EXISTS idx_deposits_user ON deposits(user_id, submitted_at DESC);

        CREATE TABLE IF NOT EXISTS payment_provider_events (
          id TEXT PRIMARY KEY,
          provider TEXT NOT NULL,
          provider_event_id TEXT NOT NULL,
          payload TEXT NOT NULL,
          signature_valid INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'received',
          deposit_id TEXT,
          error TEXT,
          received_at TEXT NOT NULL,
          processed_at TEXT,
          UNIQUE (provider, provider_event_id)
        );

        CREATE TABLE IF NOT EXISTS withdrawals (
          id TEXT PRIMARY KEY,
          reference TEXT NOT NULL UNIQUE,
          user_id TEXT NOT NULL REFERENCES users(id),
          destination_id TEXT REFERENCES payout_destinations(id),
          destination_masked TEXT NOT NULL,
          amount_centavos INTEGER NOT NULL CHECK (amount_centavos > 0),
          fee_centavos INTEGER NOT NULL DEFAULT 0,
          net_centavos INTEGER NOT NULL CHECK (net_centavos > 0),
          status TEXT NOT NULL DEFAULT 'pending',
          requires_second_approval INTEGER NOT NULL DEFAULT 0,
          first_approval_id TEXT,
          second_approval_id TEXT,
          hold_ledger_entry_id TEXT,
          payout_reference TEXT,
          payout_proof TEXT,
          paid_at TEXT,
          paid_by TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          idempotency_key TEXT UNIQUE
        );
        CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_withdrawals_user ON withdrawals(user_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS withdrawal_reviews (
          id TEXT PRIMARY KEY,
          withdrawal_id TEXT NOT NULL REFERENCES withdrawals(id) ON DELETE CASCADE,
          admin_id TEXT NOT NULL,
          admin_name TEXT NOT NULL,
          action TEXT NOT NULL,
          reason TEXT NOT NULL,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS approvals (
          id TEXT PRIMARY KEY,
          kind TEXT NOT NULL,
          subject_type TEXT NOT NULL,
          subject_id TEXT NOT NULL,
          requested_by TEXT NOT NULL,
          requested_by_name TEXT NOT NULL,
          requested_at TEXT NOT NULL,
          decided_by TEXT,
          decided_by_name TEXT,
          decision TEXT,
          decided_at TEXT,
          note TEXT,
          payload TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending',
          UNIQUE (kind, subject_type, subject_id, status)
        );

        CREATE TABLE IF NOT EXISTS tasks (
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          description TEXT,
          reward_points INTEGER NOT NULL DEFAULT 0,
          action_url TEXT,
          recurring TEXT NOT NULL DEFAULT 'daily',
          active INTEGER NOT NULL DEFAULT 1,
          sort_order INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS task_claims (
          id TEXT PRIMARY KEY,
          task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          claim_key TEXT NOT NULL,
          points INTEGER NOT NULL DEFAULT 0,
          ledger_entry_id TEXT,
          claimed_at TEXT NOT NULL,
          UNIQUE (user_id, task_id, claim_key)
        );

        CREATE TABLE IF NOT EXISTS checkins (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          checkin_date TEXT NOT NULL,
          streak INTEGER NOT NULL DEFAULT 1,
          points INTEGER NOT NULL DEFAULT 0,
          ledger_entry_id TEXT,
          created_at TEXT NOT NULL,
          UNIQUE (user_id, checkin_date)
        );

        CREATE TABLE IF NOT EXISTS wheel_spins (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          spin_date TEXT NOT NULL,
          outcome TEXT NOT NULL,
          points INTEGER NOT NULL DEFAULT 0,
          ledger_entry_id TEXT,
          created_at TEXT NOT NULL,
          UNIQUE (user_id, spin_date)
        );

        CREATE TABLE IF NOT EXISTS redemption_codes (
          code TEXT PRIMARY KEY,
          label TEXT,
          wallet TEXT NOT NULL DEFAULT 'points',
          value INTEGER NOT NULL CHECK (value > 0),
          max_redemptions INTEGER NOT NULL DEFAULT 1,
          per_user_limit INTEGER NOT NULL DEFAULT 1,
          starts_at TEXT,
          expires_at TEXT,
          active INTEGER NOT NULL DEFAULT 1,
          created_by TEXT,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS redemptions (
          id TEXT PRIMARY KEY,
          code TEXT NOT NULL REFERENCES redemption_codes(code),
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          wallet TEXT NOT NULL,
          value INTEGER NOT NULL,
          ledger_entry_id TEXT,
          created_at TEXT NOT NULL,
          UNIQUE (user_id, code)
        );

        CREATE TABLE IF NOT EXISTS notifications (
          id TEXT PRIMARY KEY,
          user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
          audience TEXT NOT NULL DEFAULT 'user',
          title TEXT NOT NULL,
          body TEXT NOT NULL,
          severity TEXT NOT NULL DEFAULT 'info',
          action_url TEXT,
          read_at TEXT,
          created_by TEXT,
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS support_tickets (
          id TEXT PRIMARY KEY,
          reference TEXT NOT NULL UNIQUE,
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          category TEXT NOT NULL,
          subject TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'open',
          priority TEXT NOT NULL DEFAULT 'normal',
          assignee_id TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS support_messages (
          id TEXT PRIMARY KEY,
          ticket_id TEXT NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
          author_type TEXT NOT NULL,
          author_id TEXT,
          body TEXT NOT NULL,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS news_articles (
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          summary TEXT NOT NULL,
          body TEXT NOT NULL,
          category TEXT NOT NULL,
          image_url TEXT,
          published_at TEXT NOT NULL,
          pinned INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS system_settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL,
          updated_by TEXT,
          updated_at TEXT NOT NULL
        );
      `)
    },
  },
  {
    id: '002_roles_and_permissions',
    up(db) {
      const insertRole = db.prepare('INSERT OR IGNORE INTO roles (name, description) VALUES (?, ?)')
      const roles = [
        ['SUPER_ADMIN', 'Full platform control including administrator accounts and roles.'],
        ['FINANCE_ADMIN', 'Reviews financial records, approves transactions, performs authorized adjustments.'],
        ['SUPPORT_ADMIN', 'Handles user support. No independent balance adjustment or payout approval.'],
        ['PLAN_MANAGER', 'Manages product definitions and plan settings.'],
        ['AUDITOR', 'Read-only access to financial records and audit history.'],
      ]
      for (const r of roles) insertRole.run(...r)

      const insertPerm = db.prepare('INSERT OR IGNORE INTO permissions (name, description) VALUES (?, ?)')
      const permissions = [
        ['admin.manage', 'Create, edit and disable administrator accounts.'],
        ['settings.manage', 'Change platform settings and thresholds.'],
        ['users.read', 'View customer accounts.'],
        ['users.manage', 'Suspend, restrict and annotate accounts.'],
        ['ledger.read', 'View the financial ledger and reports.'],
        ['ledger.adjust', 'Post manual balance adjustments.'],
        ['deposits.review', 'Verify and action deposit requests.'],
        ['withdrawals.review', 'Action withdrawal requests.'],
        ['plans.manage', 'Create, edit and archive product plans.'],
        ['plans.assign', 'Assign plans to customers.'],
        ['rewards.manage', 'Manage welcome rewards, tasks and redemption codes.'],
        ['support.manage', 'Handle support tickets and notifications.'],
        ['audit.read', 'Read the administrative audit trail.'],
      ]
      for (const p of permissions) insertPerm.run(...p)

      const grants = {
        SUPER_ADMIN: permissions.map((p) => p[0]),
        FINANCE_ADMIN: [
          'users.read', 'ledger.read', 'ledger.adjust', 'deposits.review', 'withdrawals.review',
          'support.manage', 'audit.read', 'plans.assign', 'settings.manage',
        ],
        SUPPORT_ADMIN: ['users.read', 'users.manage', 'support.manage'],
        PLAN_MANAGER: ['plans.manage', 'plans.assign', 'users.read', 'ledger.read'],
        AUDITOR: ['users.read', 'ledger.read', 'audit.read'],
      }
      const grant = db.prepare('INSERT OR IGNORE INTO role_permissions (role, permission) VALUES (?, ?)')
      for (const [role, perms] of Object.entries(grants)) {
        for (const perm of perms) grant.run(role, perm)
      }
    },
  },
  {
    id: '003_default_settings',
    up(db) {
      const defaults = {
        platform_name: 'DriveVest',
        platform_tagline: 'Drive Forward',
        welcome_reward_centavos: '5000',
        welcome_reward_wallet: 'earnings',
        welcome_reward_withdrawable: 'true',
        welcome_reward_note: 'One-time welcome reward credited on registration. Withdrawable once earned through published activity terms.',
        registration_open: 'true',
        maintenance_mode: 'false',
        maintenance_message: 'DriveVest is under maintenance. Please check back shortly.',
        min_deposit_centavos: '10000',
        max_deposit_centavos: '50000000',
        min_withdrawal_centavos: '10000',
        withdrawal_fee_centavos: '0',
        withdrawal_fee_percent: '0',
        daily_withdrawal_limit_centavos: '1000000',
        welcome_reward_bonus_referral_centavos: '1500',
        second_approval_threshold_centavos: '5000000',
        checkin_points: '20',
        daily_spin_limit: '1',
        referral_enabled: 'true',
        support_email: 'support@drivevest.example',
        support_hours: 'Mon-Fri 09:00-18:00 PHT',
        currency: 'PHP',
        terms_version: '1.0',
      }
      const stmt = db.prepare('INSERT OR IGNORE INTO system_settings (key, value, updated_by, updated_at) VALUES (?, ?, NULL, ?)')
      const ts = new Date().toISOString()
      for (const [k, v] of Object.entries(defaults)) stmt.run(k, v, ts)
    },
  },
  {
    id: '005_daily_income_settlement',
    up(db) {
      const has = (name) => !!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(name)
      const cols = (table) => {
        try { return db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name) } catch { return [] }
      }

      // Plan settlement needs to know when a term started, and which day it is
      // on. start_date is a calendar day; activated_at is the exact instant the
      // first 24-hour window begins.
      if (has('user_plans') && !cols('user_plans').includes('activated_at')) {
        db.exec(`
          ALTER TABLE user_plans ADD COLUMN activated_at TEXT;
          ALTER TABLE user_plans ADD COLUMN last_settled_at TEXT;
        `)
        // Existing plans anchor to the moment they were bought, not to midnight
        // of their start date, so "24 hours after buying" means exactly that.
        const rows = db.prepare('SELECT id, created_at FROM user_plans').all()
        const set = db.prepare('UPDATE user_plans SET activated_at = ?, last_settled_at = ? WHERE id = ?')
        for (const row of rows) {
          set.run(row.created_at, row.created_at, row.id)
        }
        db.exec('CREATE INDEX IF NOT EXISTS idx_user_plans_settlement ON user_plans(status, activated_at)')
      }

      // One ledger row per settled day, so a repeated sweep is detectable and
      // a customer's daily income is individually auditable.
      if (!has('plan_settlements')) {
        db.exec(`
          CREATE TABLE plan_settlements (
            id TEXT PRIMARY KEY,
            user_plan_id TEXT NOT NULL REFERENCES user_plans(id) ON DELETE CASCADE,
            user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            day_number INTEGER NOT NULL,
            amount_centavos INTEGER NOT NULL CHECK (amount_centavos > 0),
            ledger_entry_id TEXT NOT NULL REFERENCES ledger_entries(id),
            settled_at TEXT NOT NULL,
            UNIQUE (user_plan_id, day_number)
          );
          CREATE INDEX IF NOT EXISTS idx_plan_settlements_user ON plan_settlements(user_id, settled_at DESC);
        `)
      }

      // Check-in pays into the withdrawable wallet, so its reward is a peso
      // amount rather than a points count.
      if (!db.prepare("SELECT 1 FROM system_settings WHERE key = 'checkin_reward_centavos'").get()) {
        const legacy = Number(db.prepare("SELECT value FROM system_settings WHERE key = 'checkin_points'").get()?.value || 20)
        // A legacy 20 points becomes a sensible peso reward rather than ₱0.20.
        db.prepare('INSERT INTO system_settings (key, value, updated_by, updated_at) VALUES (?,?,?,?)')
          .run('checkin_reward_centavos', String(Math.max(100, legacy * 100)), null, new Date().toISOString())
      }

      if (has('checkins') && cols('checkins').includes('points') && !cols('checkins').includes('reward_centavos')) {
        db.exec('ALTER TABLE checkins ADD COLUMN reward_centavos INTEGER NOT NULL DEFAULT 0')
        db.exec('UPDATE checkins SET reward_centavos = points * 100')
      }

      db.prepare('INSERT OR IGNORE INTO system_settings (key, value, updated_by, updated_at) VALUES (?,?,?,?)')
        .run('plan_settlement_enabled', 'true', null, new Date().toISOString())

      // Daily income is now actually credited, so catalogue terms that called it
      // an estimate are wrong. Existing user_plans keep the snapshot they
      // accepted — a frozen snapshot must not be rewritten by a later upgrade.
      db.prepare("UPDATE plans SET terms = ?, updated_at = ? WHERE terms LIKE '%is an estimate%'")
        .run(
          'Daily income is credited to your earnings wallet once every completed 24-hour period, for the number of days purchased. It is a fixed platform credit, not interest on your deposit, and it does not grow.',
          new Date().toISOString(),
        )
    },
  },
  {
    id: '007_reanchor_activation',
    up(db) {
      // 005 anchored pre-existing plans to midnight of their start date, which
      // would pay the first day early for anyone who bought after midnight.
      // The signature of that backfill is activated_at == start_date at 00:00,
      // so only those rows are re-anchored to the real purchase instant.
      const rows = db.prepare(`
        SELECT id, created_at FROM user_plans
        WHERE activated_at = start_date || 'T00:00:00.000Z'
      `).all()
      if (rows.length === 0) return

      const set = db.prepare('UPDATE user_plans SET activated_at = ? WHERE id = ?')
      for (const row of rows) set.run(row.created_at, row.id)
    },
  },
  {
    id: '006_content_seed',
    up(db) {
      const now = new Date().toISOString()
      const ts = new Date().toISOString()

      const taskCount = db.prepare('SELECT COUNT(*) c FROM tasks').get().c
      if (taskCount === 0) {
        const insertTask = db.prepare(
          'INSERT INTO tasks (id, title, description, reward_points, action_url, recurring, active, sort_order, created_at) VALUES (?,?,?,?,?,?,1,?,?)',
        )
        insertTask.run('TASK-CHECKIN', 'Daily check-in', 'Check in once every day to build your streak.', 20, '/checkin', 'daily', 1, now)
        insertTask.run('TASK-NEWS', 'Read a news article', 'Read one DriveVest news article.', 10, '/news', 'daily', 2, now)
        insertTask.run('TASK-SHARE', 'Share your referral link', 'Share your referral link once per day.', 15, '/share', 'daily', 3, now)
        insertTask.run('TASK-PROFILE', 'Complete your profile', 'Save a payout destination on your wallet page.', 25, '/bank-card', 'once', 4, now)
      }

      const articleCount = db.prepare('SELECT COUNT(*) c FROM news_articles').get().c
      if (articleCount === 0) {
        const insertArticle = db.prepare(
          'INSERT INTO news_articles (id, title, summary, body, category, image_url, published_at, pinned) VALUES (?,?,?,?,?,?,?,?)',
        )
        const articles = [
          [
            'NEWS-1',
            'DriveVest launches the unified wallet and ledger',
            'Customer and admin balances now read from one authoritative ledger.',
            'DriveVest now runs a single financial ledger for customer wallets and the admin console. Every deposit, plan purchase, reward and adjustment is written as an immutable ledger entry, so the balance you see on your phone is the same figure the finance team sees in the admin panel. Corrections are posted as linked reversals instead of edits.',
            'Platform',
            'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=900&q=80',
            '2026-10-15T09:00:00.000Z',
            1,
          ],
          [
            'NEWS-2',
            'Withdrawals now require payout confirmation before completion',
            'Approved requests move to processing, and are only marked complete once a payout reference is recorded.',
            'Withdrawal requests now follow a tracked lifecycle. An approval reserves the funds and moves the request to processing. A request is only marked Completed once a payout reference and confirmation note are recorded, so the status always reflects real movement of funds.',
            'Payments',
            'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=900&q=80',
            '2026-10-14T09:00:00.000Z',
            0,
          ],
          [
            'NEWS-3',
            'Reading your plan terms before you activate',
            'Plan projections are estimates. Here is what is guaranteed and what is not.',
            'Every plan card shows its price, duration and published terms. The projected daily figure is an estimate of platform activity, not a promise of return, and platform earnings can differ from the projection. The terms you accept are stored with your plan and are never rewritten afterwards.',
            'Education',
            'https://images.unsplash.com/photo-1553440569-bcc63803a83d?w=900&q=80',
            '2026-10-13T09:00:00.000Z',
            0,
          ],
          [
            'NEWS-4',
            'Keeping your account secure',
            'Use a unique password and never share one-time codes with anyone.',
            'DriveVest staff will never ask for your password, one-time codes or payout PINs. Use a password you do not reuse elsewhere, sign out of devices you no longer use, and contact support through the in-app support page if something looks wrong.',
            'Security',
            'https://images.unsplash.com/photo-1502877338535-766e1452684f?w=900&q=80',
            '2026-10-12T09:00:00.000Z',
            0,
          ],
        ]
        for (const a of articles) insertArticle.run(...a)
      }

      const planCount = db.prepare('SELECT COUNT(*) c FROM plans').get().c
      if (planCount > 0) {
        const insertVersion = db.prepare(
          'INSERT OR IGNORE INTO plan_versions (id, plan_id, version, snapshot, change_reason, created_by, created_at) VALUES (?,?,?,?,?,?,?)',
        )
        for (const plan of db.prepare('SELECT * FROM plans').all()) {
          insertVersion.run(
            `${plan.id}-v${plan.current_version}`,
            plan.id,
            plan.current_version,
            JSON.stringify({
              name: plan.name,
              category: plan.category,
              price_centavos: plan.price_centavos,
              duration_days: plan.duration_days,
              projected_daily_centavos: plan.projected_daily_centavos,
              slots_total: plan.slots_total,
              terms: plan.terms,
              eligibility: plan.eligibility,
            }),
            'Imported from the original product catalogue.',
            'migration',
            ts,
          )
        }
      }
    },
  },
]

function appliedMigrations(db) {
  try {
    return new Set(db.prepare('SELECT id FROM schema_migrations').all().map((r) => r.id))
  } catch {
    return new Set()
  }
}

function migrate() {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (id TEXT PRIMARY KEY, applied_at TEXT NOT NULL)`)
  const done = appliedMigrations(db)
  const record = db.prepare('INSERT OR IGNORE INTO schema_migrations (id, applied_at) VALUES (?, ?)')
  // Legacy tables are rebuilt by swapping table names, which foreign keys
  // otherwise reject mid-transaction. Enforcement returns immediately after.
  db.pragma('foreign_keys = OFF')
  try {
    for (const m of MIGRATIONS) {
      if (done.has(m.id)) continue
      const apply = db.transaction(() => {
        m.up(db)
        record.run(m.id, new Date().toISOString())
      })
      apply()
    }
  } finally {
    db.pragma('foreign_keys = ON')
  }
}

migrate()

module.exports = db
module.exports.db = db
module.exports.backupDatabase = backupDatabase
module.exports.DB_PATH = DB_PATH