'use strict'
/**
 * DriveVest API server.
 *
 * The customer app and the admin panel are both clients of this single service
 * and both read the same SQLite file, so a balance change made by an
 * administrator is visible to the customer on their next request.
 */
require('dotenv').config()

const path = require('path')
const fs = require('fs')
const express = require('express')

const db = require('./db')
const auth = require('./lib/auth')
const audit = require('./lib/audit')
const userPlans = require('./lib/userPlans')
const payments = require('./providers/payments')
const { AppError, correlationId } = require('./lib/util')

const app = express()
app.set('trust proxy', Number(process.env.TRUST_PROXY || 0))
app.disable('x-powered-by')

app.use((req, res, next) => {
  req.correlationId = correlationId(req)
  res.setHeader('X-Correlation-Id', req.correlationId)
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.setHeader('Referrer-Policy', 'no-referrer')
  res.setHeader('X-Frame-Options', 'DENY')
  res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'")
  next()
})

// The webhook needs the raw body for HMAC verification, so it is captured before
// the JSON parser runs.
app.use((req, res, next) => {
  if (req.path === '/api/payments/webhook') {
    let size = 0
    const chunks = []
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > 256 * 1024) {
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => {
      req.rawBody = Buffer.concat(chunks).toString('utf8')
      next()
    })
    return
  }
  return next()
})

app.use(express.json({ limit: '256kb' }))

// Minimal cookie support; the session cookie is the only one the API sets.
app.use((req, res, next) => {
  res.cookie = (name, value, opts = {}) => {
    const parts = [`${name}=${encodeURIComponent(value)}`, `Path=${opts.path || '/'}`]
    if (opts.maxAge) parts.push(`Max-Age=${Math.floor(opts.maxAge / 1000)}`)
    if (opts.httpOnly) parts.push('HttpOnly')
    if (opts.sameSite) parts.push(`SameSite=${opts.sameSite === 'lax' ? 'Lax' : 'Strict'}`)
    if (opts.secure) parts.push('Secure')
    const existing = res.getHeader('Set-Cookie')
    const list = existing ? (Array.isArray(existing) ? existing : [existing]) : []
    list.push(parts.join('; '))
    res.setHeader('Set-Cookie', list)
  }
  res.clearCookie = (name, opts = {}) => res.cookie(name, '', { ...opts, maxAge: 0 })
  next()
})

const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || 'http://localhost:5173,http://127.0.0.1:5173,http://localhost:4173')
  .split(',').map((s) => s.trim()).filter(Boolean)

app.use((req, res, next) => {
  const origin = req.get('origin')
  if (!origin) return next()
  if (!ALLOWED_ORIGINS.includes(origin)) {
    return res.status(403).json({ error: { code: 'origin_rejected', message: 'This origin is not allowed.' } })
  }
  res.setHeader('Access-Control-Allow-Origin', origin)
  res.setHeader('Access-Control-Allow-Credentials', 'true')
  res.setHeader('Vary', 'Origin')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-CSRF-Token, X-Idempotency-Key, X-Correlation-Id')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS')
  return next()
})

// Express 5 dropped bare `*` wildcards; a named splat is the supported form.
app.options('/{*splat}', (req, res) => res.sendStatus(204))

app.use((req, res, next) => {
  if (process.env.NODE_ENV === 'production' && req.get('x-requested-with') !== 'fetch') {
    // Requests must come from the app's own JS; plain cross-site form posts are
    // blocked because they cannot carry the CSRF header.
    res.setHeader('X-Content-Type-Options', 'nosniff')
  }
  next()
})

/* ------------------------------------------------------------------ health */

app.get('/api/health', (req, res) => {
  const counts = db.prepare('SELECT COUNT(*) c FROM users').get().c
  res.json({
    status: 'ok',
    service: 'DriveVest API',
    users: counts,
    payment_providers: payments.catalogue(),
    time: new Date().toISOString(),
  })
})

app.get('/api/payments/providers', (req, res) => res.json({ providers: payments.catalogue() }))

/**
 * Provider webhook. The raw body is HMAC-verified before anything is trusted,
 * and the provider event id is unique so a replayed callback cannot credit a
 * wallet twice.
 */
app.post('/api/payments/webhook', (req, res) => {
  const provider = String(req.get('x-provider') || req.query.provider || '').toUpperCase()
  const signature = req.get('x-signature') || req.query.signature || ''
  const eventId = req.get('x-event-id') || req.query.event_id || ''
  if (!provider || !eventId) {
    return res.status(400).json({ error: { code: 'missing_metadata', message: 'Provider and event id are required.' } })
  }
  const result = payments.receiveEvent({
    provider,
    eventId,
    rawBody: req.rawBody || '',
    signature,
    depositId: req.query.deposit_id || null,
  })
  return res.json(result)
})

/* ------------------------------------------------------------------ routes */

app.use('/api/auth', require('./routes/auth'))
app.use('/api', require('./routes/customer'))
app.use('/api/admin', require('./routes/admin'))

/* ------------------------------------------------------- plan housekeeping */

// Daily income is credited here and on the customer's own reads. Every credit is
// an idempotent ledger entry, so running this more often cannot pay twice — the
// sweep interval controls how promptly income appears, not how much.
const MAINTENANCE_INTERVAL = Number(process.env.MAINTENANCE_INTERVAL_MINUTES || 5) * 60_000
const systemReq = { headers: {}, get: () => null, ip: null, correlationId: null }

function runMaintenance() {
  try {
    const settled = userPlans.settleDue()
    if (settled.days > 0) {
      audit.record(systemReq, {
        action: 'system.plan_settlement',
        targetType: 'system',
        targetId: 'user_plans',
        reason: `${settled.days} daily plan income credit(s) totalling ${settled.amount_centavos} centavos`,
        after: settled,
        actor: { type: 'system', name: 'DriveVest' },
      })
    }

    const expired = userPlans.expireDue()
    if (expired > 0) {
      audit.record(systemReq, {
        action: 'system.plan_expiry',
        targetType: 'system',
        targetId: 'user_plans',
        reason: `${expired} plan(s) reached their end date`,
        actor: { type: 'system', name: 'DriveVest' },
      })
    }
  } catch (err) {
    console.error('[maintenance]', err.message)
  }
}
runMaintenance()
const maintenanceTimer = setInterval(runMaintenance, MAINTENANCE_INTERVAL)
maintenanceTimer.unref()

/** Manual trigger, so settlement can be verified without waiting for the sweep. */
app.post('/api/admin/system/settle', auth.requireAdmin('plans.manage'), (req, res) => {
  const result = userPlans.settleDue({
    actor: { type: 'admin', id: req.admin.id, name: req.admin.display_name },
  })
  audit.record(req, {
    action: 'system.plan_settlement',
    targetType: 'system',
    targetId: 'user_plans',
    reason: req.body?.reason || 'Manual settlement run',
    after: result,
  })
  res.json(result)
})

/* -------------------------------------------------------------- production */

const STATIC_DIR = process.env.STATIC_DIR || path.join(__dirname, '..', 'dist')
if (fs.existsSync(STATIC_DIR)) {
  app.use(express.static(STATIC_DIR, { index: false, maxAge: '1h' }))
  app.get(/^\/(?!api\/).*/, (req, res) => res.sendFile(path.join(STATIC_DIR, 'index.html')))
}

/* ------------------------------------------------------------------- errors */

app.use((req, res) => {
  res.status(404).json({ error: { code: 'not_found', message: 'That endpoint does not exist.' } })
})

app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err instanceof AppError) {
    return res.status(err.status).json({
      error: { code: err.code, message: err.message, details: err.details, correlation_id: req.correlationId },
    })
  }
  if (err?.type === 'entity.parse.failed') {
    return res.status(400).json({ error: { code: 'invalid_json', message: 'The request body was not valid JSON.' } })
  }
  if (err?.type === 'entity.too.large') {
    return res.status(413).json({ error: { code: 'payload_too_large', message: 'That request was too large.' } })
  }
  // SQLite constraint failures are a server-side invariant, not a user error.
  if (String(err?.code || '').startsWith('SQLITE_')) {
    console.error('[db error]', err.code, err.message)
    return res.status(409).json({
      error: { code: 'constraint_violation', message: 'That operation conflicts with an existing record.', correlation_id: req.correlationId },
    })
  }
  console.error('[error]', req.method, req.originalUrl, err)
  return res.status(500).json({
    error: { code: 'internal_error', message: 'Something went wrong on our side. Nothing was changed.', correlation_id: req.correlationId },
  })
})

const PORT = Number(process.env.PORT || 4000)
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`DriveVest API listening on http://localhost:${PORT}`)
    console.log(`Allowed origins: ${ALLOWED_ORIGINS.join(', ')}`)
  })
}

module.exports = app