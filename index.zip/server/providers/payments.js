'use strict'
/**
 * Payment provider adapter.
 *
 * GCash / Maya are only offered in the customer UI when this module reports a
 * live, credentialed integration. Until a real provider key is configured the
 * catalogue reports `unavailable` and deposits cannot be submitted, so no
 * simulated confirmation can ever be mistaken for a real payment.
 *
 * Two independent paths credit a wallet:
 *   1. A signed webhook (providers receive + HMAC verification).
 *   2. An explicit reconciliation call against the provider API.
 * Screenshots and admin clicks never credit funds.
 */
const crypto = require('crypto')
const db = require('../db')
const { AppError, id, now, sha256, timingSafeEqual, reference } = require('../lib/util')

const SUPPORTED = ['GCASH', 'MAYA']

const configFor = (provider) => {
  const key = String(provider || '').toUpperCase()
  const secretKey = process.env[`${key}_SECRET_KEY`] || ''
  const clientKey = process.env[`${key}_CLIENT_KEY`] || ''
  const sandbox = process.env[`${key}_SANDBOX`] === 'true'
  return {
    provider: key,
    secretKey,
    clientKey,
    sandbox,
    live: Boolean(secretKey && clientKey),
    instructions: process.env[`${key}_INSTRUCTIONS`] || '',
    accountName: process.env[`${key}_ACCOUNT_NAME`] || '',
  }
}

/**
 * What the customer recharge screen may offer right now. A provider with no
 * credentials is reported as disabled so the UI cannot imply it works.
 */
function catalogue() {
  return SUPPORTED.map((provider) => {
    const cfg = configFor(provider)
    return {
      id: provider,
      label: provider === 'GCASH' ? 'GCash' : 'Maya',
      enabled: cfg.live,
      mode: cfg.live ? (cfg.sandbox ? 'sandbox' : 'live') : 'disabled',
      instructions: cfg.live ? cfg.instructions : '',
      reason: cfg.live ? null : `No ${provider} API credentials are configured on this server.`,
    }
  })
}

const isEnabled = (provider) => configFor(provider).live

function signPayload(rawBody, secretKey) {
  return crypto.createHmac('sha256', secretKey).update(rawBody).digest('hex')
}

function verifySignature(rawBody, signature, provider) {
  const cfg = configFor(provider)
  if (!cfg.live) return false
  const expected = signPayload(rawBody, cfg.secretKey)
  return timingSafeEqual(expected, String(signature || '').toLowerCase())
}

const recordEvent = db.prepare(`
  INSERT INTO payment_provider_events
    (id, provider, provider_event_id, payload, signature_valid, status, deposit_id, error, received_at)
  VALUES (@id, @provider, @provider_event_id, @payload, @signature_valid, @status, @deposit_id, @error, @received_at)
`)

const findEvent = db.prepare('SELECT * FROM payment_provider_events WHERE provider = ? AND provider_event_id = ?')
const markEventProcessed = db.prepare(
  "UPDATE payment_provider_events SET status = 'processed', processed_at = ?, deposit_id = ? WHERE id = ?",
)
const markEventRejected = db.prepare(
  "UPDATE payment_provider_events SET status = 'rejected', error = ? WHERE id = ?",
)
const findDepositByProviderRef = db.prepare(
  'SELECT * FROM deposits WHERE provider = ? AND provider_reference = ?',
)

/**
 * Accept a provider callback. Duplicate provider event ids are rejected so a
 * replayed webhook cannot credit a wallet twice.
 */
function receiveEvent({ provider, eventId, rawBody, signature, depositId = null }) {
  const cfg = configFor(provider)
  const valid = verifySignature(rawBody, signature, provider)
  const eventDbId = id('evt')

  if (!valid) {
    recordEvent.run({
      id: eventDbId,
      provider: cfg.provider,
      provider_event_id: String(eventId || `unverified-${eventDbId}`),
      payload: String(rawBody || '').slice(0, 4000),
      signature_valid: 0,
      status: 'rejected',
      deposit_id: depositId,
      error: 'Invalid signature',
      received_at: now(),
    })
    throw new AppError(401, 'invalid_signature', 'Provider signature verification failed.')
  }

  if (findEvent.get(cfg.provider, eventId)) {
    return { duplicate: true, credited: false }
  }

  recordEvent.run({
    id: eventDbId,
    provider: cfg.provider,
    provider_event_id: String(eventId),
    payload: String(rawBody || '').slice(0, 4000),
    signature_valid: 1,
    status: 'received',
    deposit_id: depositId,
    error: null,
    received_at: now(),
  })

  const payload = typeof rawBody === 'string' ? JSON.parse(rawBody || '{}') : (rawBody || {})
  const providerRef = payload.provider_reference || payload.reference || payload.reference_number
  const amountCentavos = payload.amount_centavos
  const status = String(payload.status || 'paid').toLowerCase()
  const deposit = depositId
    ? db.prepare('SELECT * FROM deposits WHERE id = ?').get(depositId)
    : providerRef ? findDepositByProviderRef.get(cfg.provider, providerRef) : null

  if (!deposit) {
    markEventRejected.run('No matching deposit request for this event', eventDbId)
    return { duplicate: false, credited: false, reason: 'unmatched_deposit' }
  }
  if (status !== 'paid' && status !== 'settled' && status !== 'success') {
    markEventProcessed.run(now(), deposit.id, eventDbId)
    return { duplicate: false, credited: false, reason: `provider_status_${status}` }
  }
  if (Number(amountCentavos) !== Number(deposit.amount_centavos)) {
    markEventRejected.run('Provider amount does not match the deposit request', eventDbId)
    throw new AppError(409, 'amount_mismatch', 'Provider amount does not match the deposit request.')
  }

  const { settleDeposit } = require('../lib/deposits')
  settleDeposit(deposit.id, {
    verificationState: 'provider_webhook',
    detail: `Provider event ${eventId}`,
    providerReference: providerRef || deposit.provider_reference,
    correlationId: null,
  })
  markEventProcessed.run(now(), deposit.id, eventDbId)
  return { duplicate: false, credited: true, depositId: deposit.id }
}

/**
 * Explicit reconciliation against the provider's API. Used when a webhook was
 * missed; the provider remains the source of truth and a failed lookup credits
 * nothing.
 */
async function reconcileDeposit(deposit) {
  const cfg = configFor(deposit.provider || deposit.method)
  if (!cfg.live) {
    throw new AppError(
      409,
      'provider_not_configured',
      `${cfg.provider} API credentials are not configured on this server, so this deposit cannot be verified.`,
    )
  }
  if (!deposit.provider_reference) {
    throw new AppError(409, 'missing_provider_reference', 'This deposit has no provider reference to reconcile.')
  }
  const endpoint = cfg.sandbox
    ? `https://sandbox-api.${cfg.provider.toLowerCase()}.example/v1/payments/${deposit.provider_reference}`
    : `https://api.${cfg.provider.toLowerCase()}.example/v1/payments/${deposit.provider_reference}`

  let body
  try {
    const res = await fetch(endpoint, {
      headers: {
        Authorization: `Basic ${Buffer.from(`${cfg.clientKey}:`).toString('base64')}`,
        Accept: 'application/json',
      },
    })
    body = await res.json()
  } catch (err) {
    throw new AppError(502, 'provider_unreachable', `Could not reach the ${cfg.provider} API: ${err.message}`)
  }

  const amount = Number(body?.amount?.value ?? body?.amount ?? 0)
  const amountCentavos = Math.round(amount * 100)
  const settled = ['paid', 'settled', 'success', 'completed'].includes(String(body?.status || '').toLowerCase())

  if (!settled) {
    return { verified: false, detail: `Provider reports status "${body?.status ?? 'unknown'}"` }
  }
  if (amountCentavos !== deposit.amount_centavos) {
    throw new AppError(409, 'amount_mismatch', 'Provider amount does not match the deposit request.')
  }
  return { verified: true, detail: `Confirmed via ${cfg.provider} API ${cfg.sandbox ? 'sandbox' : 'live'}`, providerReference: body.reference || deposit.provider_reference }
}

module.exports = {
  SUPPORTED, catalogue, isEnabled, configFor, receiveEvent, reconcileDeposit,
  verifySignature, signPayload, sha256, reference,
}