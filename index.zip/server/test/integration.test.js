'use strict'
/**
 * Integration tests.
 *
 * These run against a real temporary SQLite database and a real listening HTTP
 * server — no mocks, no in-memory stubs. Cookies are carried by hand the same
 * way a browser would, so session and CSRF handling is genuinely exercised.
 *
 *   npm test
 */
const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const crypto = require('node:crypto')

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'drivevest-test-'))
process.env.DATABASE_PATH = path.join(TMP, 'test.db')
process.env.NODE_ENV = 'test'
process.env.ALLOWED_ORIGINS = 'http://localhost:5173'
// A provider is configured so the verified-deposit path is testable; the values
// are test fixtures, never used against a live provider.
process.env.GCASH_SANDBOX = 'true'
process.env.GCASH_CLIENT_KEY = 'test-client-key'
process.env.GCASH_SECRET_KEY = 'test-secret-key'
// The suite creates many accounts and sessions from one address; the shipped
// production limits stay in the source and are only relaxed here.
process.env.REGISTER_RATE_LIMIT = '500'
process.env.LOGIN_RATE_LIMIT = '500'
process.env.ADMIN_LOGIN_RATE_LIMIT = '500'
process.env.BCRYPT_ROUNDS = '4'

const app = require('../index')
const db = require('../db')

let server
let baseUrl

/** Minimal cookie-aware HTTP client. */
function makeClient() {
  const cookies = new Map()
  let csrf = null

  async function request(method, url, body, extraHeaders = {}) {
      const headers = { Origin: 'http://localhost:5173', ...extraHeaders }
      if (body !== undefined) headers['Content-Type'] = 'application/json'
      if (csrf) headers['X-CSRF-Token'] = csrf
      if (cookies.size) headers.Cookie = [...cookies.entries()].map(([k, v]) => `${k}=${v}`).join('; ')
      const res = await fetch(baseUrl + url, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
      })
      for (const raw of res.headers.getSetCookie?.() || []) {
        const [pair] = raw.split(';')
        const idx = pair.indexOf('=')
        const name = pair.slice(0, idx).trim()
        const value = pair.slice(idx + 1).trim()
        if (value === '') cookies.delete(name)
        else cookies.set(name, value)
      }
      const text = await res.text()
      let json = null
      try { json = text ? JSON.parse(text) : null } catch { json = null }
      return { status: res.status, body: json, text }
  }

  // `get` is a reserved accessor keyword, so the verb helpers are plain properties.
  return {
    get csrf() { return csrf },
    get cookies() { return cookies },
    request,
    get: (url, headers) => request('GET', url, undefined, headers),
    post: (url, body, headers) => request('POST', url, body ?? {}, headers),
    patch: (url, body, headers) => request('PATCH', url, body ?? {}, headers),
    delete: (url, headers) => request('DELETE', url, undefined, headers),
    setCsrf(token) { csrf = token },
  }
}

/** Provision an administrator directly, mirroring the one-time CLI setup. */
function provisionAdmin(username, password, role = 'SUPER_ADMIN') {
  const auth = require('../lib/auth')
  const { now } = require('../lib/util')
  const id = `adm_test_${crypto.randomBytes(4).toString('hex')}`
  db.prepare(`
    INSERT INTO admin_users (id, username, username_lower, password_hash, role, display_name, status, created_at, provisioned_by)
    VALUES (?,?,?,?,?,?, 'Active', ?, 'test')
  `).run(id, username, username.toLowerCase(), auth.hashPassword(password), role, username, now())
  return { id, username, password, role }
}

async function adminClient(username = 'superadmin', password = 'setup-pass-123', role = 'SUPER_ADMIN') {
  provisionAdmin(username, password, role)
  const client = makeClient()
  const res = await client.post('/api/admin/login', { username, password })
  assert.equal(res.status, 200, `admin login failed: ${res.text}`)
  client.setCsrf(res.body.csrfToken)
  return client
}

async function registerClient({ username, password = 'valid-pass-123', referralCode } = {}) {
  const client = makeClient()
  const res = await client.post('/api/auth/register', { username, password, referralCode })
  if (res.body?.csrfToken) client.setCsrf(res.body.csrfToken)
  return { client, res }
}

test.before(async () => {
  await new Promise((resolve) => {
    server = app.listen(0, () => {
      baseUrl = `http://127.0.0.1:${server.address().port}`
      resolve()
    })
  })
})

test.after(() => {
  server?.close()
  db.close()
  fs.rmSync(TMP, { recursive: true, force: true })
})

/* ============================================================ registration */

test('registration accepts exactly username, password and referral code', async () => {
  const client = makeClient()
  const res = await client.post('/api/auth/register', { username: 'threefields', password: 'valid-pass-123' })
  assert.equal(res.status, 201, res.text)

  const stored = db.prepare('SELECT * FROM users WHERE id = ?').get(res.body.user.id)
  assert.equal(stored.username, 'threefields')
  assert.notEqual(stored.password_hash, 'valid-pass-123')
  assert.ok(stored.password_hash.startsWith('$2'), 'password must be hashed, never stored in plaintext')
  assert.equal(stored.status, 'Active')
  assert.equal(stored.membership, 'Bronze')
  assert.ok(stored.referral_code.startsWith('DV-'))

  // A registration body cannot set a balance, role, id or status.
  const injected = await client.post('/api/auth/register', {
    username: 'injector', password: 'valid-pass-123',
    id: 'usr_custom', status: 'Admin', membership: 'Platinum', balance: 999999, role: 'SUPER_ADMIN',
  })
  assert.equal(injected.status, 201, injected.text)
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(injected.body.user.id)
  assert.notEqual(row.id, 'usr_custom')
  assert.equal(row.status, 'Active')
  assert.equal(row.membership, 'Bronze')
  const wallet = db.prepare('SELECT * FROM wallets WHERE user_id = ?').get(row.id)
  assert.equal(wallet.recharge_centavos, 0)
  assert.equal(wallet.earnings_centavos, 5000, 'the only credit is the welcome reward')
  assert.equal(db.prepare("SELECT COUNT(*) c FROM admin_users WHERE username = 'injector'").get().c, 0)
})

test('registration issues exactly one 50 peso welcome reward', async () => {
  const { res } = await registerClient({ username: 'welcomeuser' })
  assert.equal(res.status, 201)
  assert.equal(res.body.welcomeReward.granted, true)
  assert.equal(res.body.welcomeReward.amount_centavos, 5000)
  assert.equal(res.body.wallet.earnings_centavos, 5000)

  const rewards = db.prepare('SELECT * FROM welcome_rewards WHERE user_id = ?').all(res.body.user.id)
  assert.equal(rewards.length, 1)
  assert.equal(rewards[0].amount_centavos, 5000)

  const entries = db.prepare("SELECT * FROM ledger_entries WHERE user_id = ? AND kind = 'welcome_reward'").all(res.body.user.id)
  assert.equal(entries.length, 1)
  assert.equal(entries[0].direction, 'credit')
  assert.equal(entries[0].balance_after_centavos, 5000)
})

test('the welcome reward is never issued twice, across logins and retries', async () => {
  const { client, res } = await registerClient({ username: 'onceonly' })
  const userId = res.body.user.id

  // Replaying the same registration payload must not create a second account
  // for the same username, and the reward total must stay at 50 pesos.
  const replay = await makeClient().post('/api/auth/register', { username: 'onceonly', password: 'valid-pass-123' })
  assert.equal(replay.status, 409)
  assert.equal(replay.body.error.code, 'username_taken')

  for (let i = 0; i < 3; i += 1) {
    const session = await client.get('/api/me')
    assert.equal(session.status, 200)
    assert.equal(session.body.wallet.earnings_centavos, 5000)
  }

  const fresh = makeClient()
  const login = await fresh.post('/api/auth/login', { username: 'onceonly', password: 'valid-pass-123' })
  assert.equal(login.status, 200)
  assert.equal(login.body.wallet.earnings_centavos, 5000)
  assert.equal(login.body.welcomeRewardIssued, true)

  const count = db.prepare('SELECT COUNT(*) c FROM welcome_rewards WHERE user_id = ?').get(userId).c
  assert.equal(count, 1)
})

test('existing accounts keep their original welcome reward after migration', () => {
  // The pre-upgrade database carried two real accounts with their rewards.
  const migrated = db.prepare('SELECT COUNT(*) c FROM welcome_rewards').get().c
  const users = db.prepare('SELECT COUNT(*) c FROM users').get().c
  const rewards = db.prepare('SELECT COUNT(*) c FROM welcome_rewards').get().c
  assert.equal(migrated, users, 'every account keeps exactly one welcome reward record')
  assert.ok(users >= 2)
  assert.equal(rewards, users)
})

test('invalid referral codes are rejected and valid ones link the real user', async () => {
  const bad = await registerClient({ username: 'badref', referralCode: 'DV-NOPE00' })
  assert.equal(bad.res.status, 400)
  assert.equal(bad.res.body.error.code, 'invalid_referral_code')
  assert.equal(db.prepare("SELECT COUNT(*) c FROM users WHERE username = 'badref'").get().c, 0)

  const referrer = await registerClient({ username: 'referrer1' })
  const code = referrer.res.body.user.referral_code

  const referred = await registerClient({ username: 'referred1', referralCode: code })
  assert.equal(referred.res.status, 201, referred.res.text)
  assert.equal(referred.res.body.user.referred_by, 'referrer1')

  const link = db.prepare('SELECT * FROM referrals WHERE referred_id = ?').get(referred.res.body.user.id)
  assert.equal(link.referrer_id, referrer.res.body.user.id)
  assert.equal(link.code_used, code)
})

/* ================================================================== login */

test('login takes username and password only and rejects bad credentials', async () => {
  await registerClient({ username: 'loginuser' })
  const client = makeClient()

  const bad = await client.post('/api/auth/login', { username: 'loginuser', password: 'wrong-pass-999' })
  assert.equal(bad.status, 401)
  assert.equal(bad.body.error.code, 'invalid_credentials')

  const ok = await client.post('/api/auth/login', { username: 'loginuser', password: 'valid-pass-123' })
  assert.equal(ok.status, 200)
  assert.equal(ok.body.user.username, 'loginuser')
  assert.ok(ok.body.csrfToken)

  // Email is not part of the login contract and is never required.
  const noEmail = await makeClient().post('/api/auth/login', { username: 'loginuser', password: 'valid-pass-123' })
  assert.equal(noEmail.status, 200)
})

test('login is rate limited', async () => {
  await registerClient({ username: 'ratelimituser' })
  const client = makeClient()
  let limited = false
  for (let i = 0; i < 12; i += 1) {
    const res = await client.post('/api/auth/login', { username: 'ratelimituser', password: `bad-${i}-pass` })
    if (res.status === 429) { limited = true; break }
  }
  assert.ok(limited, 'repeated failures must eventually be throttled')
})

test('a correct password never counts toward the sign-in limit', async () => {
  await registerClient({ username: 'repeatlogin', password: 'valid-pass-123' })

  // Sixty successful sign-ins, far beyond every limit in the system. Signing
  // in correctly is not an attack and must never lock anyone out — this is the
  // regression test for the IP-keyed middleware limiter that used to count
  // successes and refuse the 31st legitimate login.
  for (let i = 0; i < 60; i += 1) {
    const client = makeClient()
    const res = await client.post('/api/auth/login', { username: 'repeatlogin', password: 'valid-pass-123' })
    assert.equal(res.status, 200, `successful sign-in ${i + 1} was refused: ${res.text}`)
  }

  // The account is still locked out only by genuine wrong passwords.
  const attacker = makeClient()
  let limited = false
  for (let i = 0; i < 15; i += 1) {
    const res = await attacker.post('/api/auth/login', { username: 'repeatlogin', password: `guess-${i}` })
    if (res.status === 429) { limited = true; break }
    assert.equal(res.status, 401, `a wrong password must be rejected: ${res.text}`)
  }
  assert.ok(limited, 'wrong passwords are still throttled')

  // The lockout holds until the window expires, deliberately.
  const locked = await makeClient().post('/api/auth/login', { username: 'repeatlogin', password: 'valid-pass-123' })
  assert.equal(locked.status, 429, 'a lockout must hold until its window expires')
})

test('admin sign-in is never throttled by default', async () => {
  await adminClient('unthrottled_admin', 'unthrottled-pass-1', 'SUPER_ADMIN')
  assert.equal(process.env.ADMIN_LOGIN_MAX_FAILURES, undefined, 'the admin throttle must ship disabled')

  // Fifty wrong passwords in a row. The default posture is no lockout, so the
  // console never answers "too many attempts" and an operator who mistypes a
  // password is never locked out of the console that manages their money.
  for (let i = 0; i < 50; i += 1) {
    const res = await makeClient().post('/api/admin/login', { username: 'unthrottled_admin', password: `nope-${i}` })
    assert.equal(res.status, 401, `wrong password ${i + 1} must be rejected as invalid, not throttled: ${res.text}`)
  }

  // And the real password still works straight afterwards, with no waiting.
  const good = await makeClient().post('/api/admin/login', { username: 'unthrottled_admin', password: 'unthrottled-pass-1' })
  assert.equal(good.status, 200, `a correct password must work with no lockout: ${good.text}`)

  // Repeated correct sign-ins are equally unthrottled.
  for (let i = 0; i < 40; i += 1) {
    const res = await makeClient().post('/api/admin/login', { username: 'unthrottled_admin', password: 'unthrottled-pass-1' })
    assert.equal(res.status, 200, `successful admin sign-in ${i + 1} was refused: ${res.text}`)
  }
})

test('the admin throttle still works when an operator opts back in', async () => {
  process.env.ADMIN_LOGIN_MAX_FAILURES = '10'
  process.env.ADMIN_LOGIN_IP_MAX_FAILURES = '50'
  process.env.ADMIN_LOGIN_WINDOW_MINUTES = '15'
  try {
    await adminClient('optin_admin', 'optin-pass-1', 'SUPER_ADMIN')

    // Correct sign-ins never consume the budget.
    for (let i = 0; i < 40; i += 1) {
      const res = await makeClient().post('/api/admin/login', { username: 'optin_admin', password: 'optin-pass-1' })
      assert.equal(res.status, 200, `successful admin sign-in ${i + 1} was refused: ${res.text}`)
    }

    // Wrong passwords do.
    let limited = false
    for (let i = 0; i < 20; i += 1) {
      const res = await makeClient().post('/api/admin/login', { username: 'optin_admin', password: `nope-${i}` })
      if (res.status === 429) { limited = true; break }
      assert.equal(res.status, 401, `a wrong admin password must be rejected: ${res.text}`)
    }
    assert.ok(limited, 'the opt-in throttle must still throttle repeated failures')

    const locked = await makeClient().post('/api/admin/login', { username: 'optin_admin', password: 'optin-pass-1' })
    assert.equal(locked.status, 429, 'a lockout must hold until its window expires')

    // A different account is unaffected — buckets are per username+IP.
    await adminClient('optin_other', 'optin-other-1', 'AUDITOR')
    const fine = await makeClient().post('/api/admin/login', { username: 'optin_other', password: 'optin-other-1' })
    assert.equal(fine.status, 200, `an unrelated account must not be locked out: ${fine.text}`)
  } finally {
    delete process.env.ADMIN_LOGIN_MAX_FAILURES
    delete process.env.ADMIN_LOGIN_IP_MAX_FAILURES
    delete process.env.ADMIN_LOGIN_WINDOW_MINUTES
  }
})



test('mutating requests without a CSRF token are refused', async () => {
  const { client, res } = await registerClient({ username: 'csrfuser' })
  assert.equal(res.status, 201)
  const saved = client.csrf
  client.setCsrf('')
  const rejected = await client.post('/api/checkin', {})
  assert.equal(rejected.status, 403)
  assert.equal(rejected.body.error.code, 'csrf_failed')
  client.setCsrf(saved)
  const accepted = await client.post('/api/checkin', {})
  assert.equal(accepted.status, 200)
})

/* ================================================================ ledger */

test('balances are integers and every movement writes a ledger entry', async () => {
  const { client, res } = await registerClient({ username: 'ledgeruser' })
  const userId = res.body.user.id

  const admin = await adminClient('ledger_admin', 'ledger-admin-1')
  const credit = await admin.post('/api/admin/adjustments', {
    userId, wallet: 'recharge', direction: 'Credit', amount: '1234.56',
    reason: 'Test credit', note: 'Automated integration test credit', reference: 'TEST-REF-1',
  })
  assert.equal(credit.status, 201, credit.text)
  assert.equal(credit.body.entry.amount_centavos, 123456)
  // The welcome reward lands in the earnings wallet, so recharge starts at zero.
  assert.equal(credit.body.wallet.recharge_centavos, 123456)
  assert.equal(Number.isInteger(credit.body.wallet.recharge_centavos), true)

  const entries = await client.get('/api/transactions?wallet=recharge')
  assert.equal(entries.status, 200)
  const manual = entries.body.rows.find((r) => r.kind === 'manual_adjustment')
  assert.ok(manual)
  assert.equal(manual.balance_before_centavos, 0)
  assert.equal(manual.balance_after_centavos, 123456)
  assert.equal(manual.actor_name, 'ledger_admin')
})

test('a debit beyond the balance is refused and leaves the wallet untouched', async () => {
  const { res } = await registerClient({ username: 'brokeuser' })
  const userId = res.body.user.id
  const admin = await adminClient('debit_admin', 'debit-admin-1')
  const before = db.prepare('SELECT earnings_centavos FROM wallets WHERE user_id = ?').get(userId).earnings_centavos

  // Above the available balance but below the two-person approval threshold, so
  // the balance check is what refuses it.
  const attempt = await admin.post('/api/admin/adjustments', {
    userId, wallet: 'earnings', direction: 'Debit', amount: '1000',
    reason: 'Should fail', note: 'Automated integration test debit',
  })
  assert.equal(attempt.status, 409)
  assert.equal(attempt.body.error.code, 'insufficient_funds')
  assert.equal(db.prepare('SELECT earnings_centavos FROM wallets WHERE user_id = ?').get(userId).earnings_centavos, before)
})

test('ledger entries cannot be edited or deleted, only reversed', async () => {
  const admin = await adminClient('immut_admin', 'immut-admin-1')
  const { res } = await registerClient({ username: 'reverseme' })
  const userId = res.body.user.id

  // A deposit credit is reversible; a welcome reward is deliberately not,
  // because correcting one needs a dedicated audited adjustment.
  const credited = await admin.post('/api/admin/adjustments', {
    userId, wallet: 'recharge', direction: 'Credit', amount: '40',
    reason: 'Create a reversible credit', note: 'Automated integration test entry',
  })
  assert.equal(credited.status, 201, credited.text)
  const entryId = credited.body.entry.id

  assert.throws(() => db.prepare('UPDATE ledger_entries SET amount_centavos = 1 WHERE id = ?').run(entryId), /immutable/)
  assert.throws(() => db.prepare('DELETE FROM ledger_entries WHERE id = ?').run(entryId), /immutable/)

  const reversal = await admin.post(`/api/admin/transactions/${entryId}/reverse`, { reason: 'Automated integration test reversal' })
  assert.equal(reversal.status, 200, reversal.text)
  assert.equal(reversal.body.entry.direction, 'debit')
  assert.equal(reversal.body.entry.reversal_of, entryId)

  const original = db.prepare('SELECT * FROM ledger_entries WHERE id = ?').get(entryId)
  assert.equal(original.amount_centavos, 4000)
  assert.equal(original.balance_after_centavos, credited.body.entry.balance_after_centavos)

  const repeat = await admin.post(`/api/admin/transactions/${entryId}/reverse`, { reason: 'Should not reverse twice' })
  assert.equal(repeat.status, 409)

  const reward = db.prepare("SELECT * FROM ledger_entries WHERE kind = 'welcome_reward' LIMIT 1").get()
  const protectedReverse = await admin.post(`/api/admin/transactions/${reward.id}/reverse`, { reason: 'Attempt to reverse a welcome reward' })
  assert.equal(protectedReverse.status, 409)
  assert.equal(protectedReverse.body.error.code, 'welcome_reward_protected')
})

/* ================================================================= plans */

test('plan purchase debits the wallet and records the accepted terms', async () => {
  const { client, res } = await registerClient({ username: 'planbuyer' })
  const userId = res.body.user.id
  const admin = await adminClient('plan_admin', 'plan-admin-1')

  const created = await admin.post('/api/admin/plans', {
    name: 'Test Roadster', category: 'daily', price: '250.00', duration_days: 10,
    projected_daily: '3.00', slots_total: 2,
    terms: 'Projected reward is an estimate, not a guarantee.', reason: 'Integration test product',
  })
  assert.equal(created.status, 201, created.text)
  const planId = created.body.plan.id

  const fund = await admin.post('/api/admin/adjustments', {
    userId, wallet: 'recharge', direction: 'Credit', amount: '1000',
    reason: 'Fund the test buyer', note: 'Automated integration test funding',
  })
  assert.equal(fund.status, 201)

  const key = crypto.randomUUID()
  const buy = await client.post('/api/user-plans/purchase', { planId }, { 'X-Idempotency-Key': key })
  assert.equal(buy.status, 201, buy.text)
  assert.equal(buy.body.userPlan.amount_centavos, 25000)

  const replay = await client.post('/api/user-plans/purchase', { planId }, { 'X-Idempotency-Key': key })
  assert.equal(replay.status, 201)
  const purchases = db.prepare("SELECT COUNT(*) c FROM ledger_entries WHERE user_id = ? AND kind = 'plan_purchase'").get(userId).c
  assert.equal(purchases, 1, 'a repeated idempotency key must not buy twice')

  const wallet = await client.get('/api/wallet')
  assert.equal(wallet.body.recharge_centavos, 100000 - 25000)

  const stored = db.prepare('SELECT * FROM user_plans WHERE id = ?').get(buy.body.userPlan.id)
  const snapshot = JSON.parse(stored.terms_snapshot)
  assert.equal(snapshot.price_centavos, 25000)
  assert.equal(stored.plan_version, 1)

  // Terms are versioned: changing them creates version 2 and leaves version 1 intact.
  const updated = await admin.patch(`/api/admin/plans/${planId}`, { terms: 'Updated published terms.', reason: 'Integration test terms update' })
  assert.equal(updated.status, 200, updated.text)
  assert.equal(updated.body.plan.current_version, 2)

  const versions = await admin.get(`/api/admin/plans/${planId}/versions`)
  assert.equal(versions.body.length, 2)
  const v1 = versions.body.find((v) => v.version === 1)
  const v1Snapshot = typeof v1.snapshot === 'string' ? JSON.parse(v1.snapshot) : v1.snapshot
  assert.equal(v1Snapshot.terms, 'Projected reward is an estimate, not a guarantee.')
  assert.equal(snapshot.terms, 'Projected reward is an estimate, not a guarantee.', 'customer terms never change')
})

test('a plan cannot be purchased without sufficient balance', async () => {
  const { client } = await registerClient({ username: 'poorbuyer' })
  const plans = await client.get('/api/plans')
  const priciest = plans.body[plans.body.length - 1]
  const attempt = await client.post('/api/user-plans/purchase', { planId: priciest.id })
  assert.equal(attempt.status, 409)
})

/* ============================================================== deposits */

function gcashSignature(rawBody) {
  return crypto.createHmac('sha256', process.env.GCASH_SECRET_KEY).update(rawBody).digest('hex')
}

test('deposits credit only after a verified provider event', async () => {
  const { client } = await registerClient({ username: 'depositor' })
  const walletBefore = (await client.get('/api/wallet')).body.recharge_centavos

  const created = await client.post('/api/deposits', { amount: '750', method: 'GCASH', providerReference: 'GCASH-TEST-1' })
  assert.equal(created.status, 201, created.text)
  const depositId = created.body.deposit.id
  assert.equal(created.body.deposit.status, 'pending')
  assert.equal(created.body.deposit.verification_state, 'unverified')

  const stillUnchanged = (await client.get('/api/wallet')).body.recharge_centavos
  assert.equal(stillUnchanged, walletBefore, 'an unverified deposit must not move money')

  const admin = await adminClient('deposit_admin', 'deposit-admin-1')
  const premature = await admin.post(`/api/admin/deposits/${depositId}/review`, { action: 'approve' })
  assert.equal(premature.status, 400, 'there is no approve-without-verification action')

  const raw = JSON.stringify({
    reference: 'GCASH-TEST-1',
    amount_centavos: 75000,
    status: 'paid',
  })
  const eventId = crypto.randomUUID()
  const hook = await fetch(`${baseUrl}/api/payments/webhook`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Provider': 'GCASH',
      'X-Event-Id': eventId,
      'X-Signature': gcashSignature(raw),
    },
    body: raw,
  })
  const hookBody = await hook.json()
  assert.equal(hook.status, 200, JSON.stringify(hookBody))
  assert.equal(hookBody.credited, true)

  const after = (await client.get('/api/wallet')).body.recharge_centavos
  assert.equal(after, walletBefore + 75000)

  // Replaying the exact same provider event must not credit twice.
  const replayHook = await fetch(`${baseUrl}/api/payments/webhook`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Provider': 'GCASH',
      'X-Event-Id': eventId,
      'X-Signature': gcashSignature(raw),
    },
    body: raw,
  })
  const replayBody = await replayHook.json()
  assert.equal(replayBody.duplicate, true)
  assert.equal((await client.get('/api/wallet')).body.recharge_centavos, after)
})

test('an unsigned or mismatched webhook never credits a wallet', async () => {
  const { client } = await registerClient({ username: 'spoofvictim' })
  const before = (await client.get('/api/wallet')).body.recharge_centavos

  const request = await client.post('/api/deposits', { amount: '500', method: 'GCASH', providerReference: 'GCASH-SPOOF' })
  assert.equal(request.status, 201)

  const raw = JSON.stringify({ reference: 'GCASH-SPOOF', amount_centavos: 50000, status: 'paid' })
  const bad = await fetch(`${baseUrl}/api/payments/webhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Provider': 'GCASH', 'X-Event-Id': crypto.randomUUID(), 'X-Signature': 'deadbeef' },
    body: raw,
  })
  assert.equal(bad.status, 401)

  const mismatchRaw = JSON.stringify({ reference: 'GCASH-SPOOF', amount_centavos: 1, status: 'paid' })
  const mismatch = await fetch(`${baseUrl}/api/payments/webhook`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Provider': 'GCASH',
      'X-Event-Id': crypto.randomUUID(),
      'X-Signature': gcashSignature(mismatchRaw),
    },
    body: mismatchRaw,
  })
  assert.equal(mismatch.status, 409)

  assert.equal((await client.get('/api/wallet')).body.recharge_centavos, before)
})

test('a disabled provider cannot accept deposits at all', async () => {
  const { client } = await registerClient({ username: 'noprovider' })
  const res = await client.post('/api/deposits', { amount: '500', method: 'MAYA' })
  assert.equal(res.status, 409)
  assert.equal(res.body.error.code, 'provider_unavailable')
  assert.equal(db.prepare("SELECT COUNT(*) c FROM deposits WHERE user_id = (SELECT id FROM users WHERE username = 'noprovider')").get().c, 0)
})

/* =========================================================== withdrawals */

async function fundAndReserve(username, amount, { threshold = '5000000' } = {}) {
  const { setSetting } = require('../lib/util')
  const { client, res } = await registerClient({ username })
  const userId = res.body.user.id
  const admin = await adminClient(`fund_${username}`, 'funding-admin-1')

  // Funding runs with the threshold parked high so the credit posts immediately;
  // the threshold under test is applied only when the withdrawal is requested.
  setSetting('second_approval_threshold_centavos', '5000000', null)
  const fund = await admin.post('/api/admin/adjustments', {
    userId, wallet: 'earnings', direction: 'Credit', amount,
    reason: 'Fund for withdrawal test', note: 'Automated integration test funding',
  })
  assert.equal(fund.status, 201, fund.text)

  const dest = await client.post('/api/payout-destinations', {
    holderName: 'Test Holder', provider: 'GCash', accountNumber: '09171234567',
  })
  assert.equal(dest.status, 201, dest.text)

  setSetting('second_approval_threshold_centavos', threshold, null)
  const withdrawal = await client.post('/api/withdrawals', { amount, destinationId: dest.body.id })
  assert.equal(withdrawal.status, 201, withdrawal.text)
  return { client, userId, withdrawal: withdrawal.body.withdrawal, destId: dest.body.id }
}

test('withdrawal funds are reserved so the same money cannot be spent twice', async () => {
  const first = await fundAndReserve('reserveone', '400')
  const admin = await adminClient('reserve_admin', 'reserve-admin-1')

  // The account holds the ₱50 welcome reward plus the ₱400 test funding.
  const wallet = await first.client.get('/api/wallet')
  assert.equal(wallet.body.earnings_centavos, 45000)
  assert.equal(wallet.body.reserved_centavos, 40000)
  assert.equal(wallet.body.available_centavos, 5000, 'the held amount cannot be spent again')

  const second = await first.client.post('/api/withdrawals', { amount: '100', destinationId: first.destId })
  assert.equal(second.status, 409)
  assert.equal(second.body.error.code, 'insufficient_funds')

  const rejected = await admin.post(`/api/admin/withdrawals/${first.withdrawal.id}/decision`, {
    action: 'reject', reason: 'Automated integration test rejection',
  })
  assert.equal(rejected.status, 200, rejected.text)
  const restored = await first.client.get('/api/wallet')
  assert.equal(restored.body.reserved_centavos, 0)
  assert.equal(restored.body.earnings_centavos, 45000, 'the held amount returns in full')
})

test('a withdrawal is only completed after a recorded payout confirmation', async () => {
  const setup = await fundAndReserve('withdrawflow', '250')
  const admin = await adminClient('withdraw_admin', 'withdraw-admin-1')

  const approve = await admin.post(`/api/admin/withdrawals/${setup.withdrawal.id}/decision`, {
    action: 'approve', reason: 'Automated integration test approval',
  })
  assert.equal(approve.status, 200, approve.text)
  assert.equal(approve.body.withdrawal.status, 'processing')

  const noProof = await admin.post(`/api/admin/withdrawals/${setup.withdrawal.id}/decision`, {
    action: 'mark_paid', payoutReference: 'PAY-1',
  })
  assert.equal(noProof.status, 400)
  assert.equal(noProof.body.error.code, 'proof_required')

  // ₱250 funded plus the ₱50 welcome reward, with ₱250 held for this request.
  const beforePaid = await setup.client.get('/api/wallet')
  assert.equal(beforePaid.body.earnings_centavos, 30000)
  assert.equal(beforePaid.body.reserved_centavos, 25000)
  assert.equal(beforePaid.body.available_centavos, 5000, 'the held amount is unavailable until payout is confirmed')

  const paid = await admin.post(`/api/admin/withdrawals/${setup.withdrawal.id}/decision`, {
    action: 'mark_paid', payoutReference: 'PAY-1', proof: 'Confirmed against GCash remittance PAY-1',
  })
  assert.equal(paid.status, 200, paid.text)
  assert.equal(paid.body.withdrawal.status, 'completed')
  assert.equal(paid.body.withdrawal.payout_reference, 'PAY-1')

  const afterPaid = await setup.client.get('/api/wallet')
  assert.equal(afterPaid.body.earnings_centavos, 5000, 'only the confirmed payout left the wallet')
  assert.equal(afterPaid.body.reserved_centavos, 0)
  assert.ok(paid.body.entry?.reference, 'the payout posts its own ledger entry')
})

test('high value withdrawals need a second administrator', async () => {
  const setup = await fundAndReserve('bigwithdraw', '5000', { threshold: '10000' })
  const first = await adminClient('firstapprover', 'first-approve-1', 'FINANCE_ADMIN')

  const firstApproval = await first.post(`/api/admin/withdrawals/${setup.withdrawal.id}/decision`, {
    action: 'approve', reason: 'First approval for the two-person rule',
  })
  assert.equal(firstApproval.status, 200, firstApproval.text)
  assert.equal(firstApproval.body.needs_second_approval, true)
  assert.equal(firstApproval.body.withdrawal.status, 'under_review')

  const sameAdmin = await first.post(`/api/admin/withdrawals/${setup.withdrawal.id}/decision`, {
    action: 'approve', reason: 'Trying to approve my own request',
  })
  assert.equal(sameAdmin.status, 409)
  assert.equal(sameAdmin.body.error.code, 'self_approval')

  const second = await adminClient('secondapprover', 'second-approve-1', 'FINANCE_ADMIN')
  const secondApproval = await second.post(`/api/admin/withdrawals/${setup.withdrawal.id}/decision`, {
    action: 'approve', reason: 'Second approval for the two-person rule',
  })
  assert.equal(secondApproval.status, 200, secondApproval.text)
  assert.equal(secondApproval.body.withdrawal.status, 'processing')

  require('../lib/util').setSetting('second_approval_threshold_centavos', '5000000', null)
})

test('large adjustments require a second approver and nothing moves before then', async () => {
  require('../lib/util').setSetting('second_approval_threshold_centavos', '10000', null)
  const { res } = await registerClient({ username: 'bigadjust' })
  const userId = res.body.user.id
  const admin = await adminClient('adjust_requester', 'adjust-request-1', 'FINANCE_ADMIN')

  const requested = await admin.post('/api/admin/adjustments', {
    userId, wallet: 'recharge', direction: 'Credit', amount: '5000',
    reason: 'Large promotional credit', note: 'Requires a second administrator per policy',
  })
  assert.equal(requested.status, 202, requested.text)
  assert.equal(requested.body.status, 'pending_second_approval')
  assert.equal(db.prepare('SELECT recharge_centavos FROM wallets WHERE user_id = ?').get(userId).recharge_centavos, 0)

  const selfApprove = await admin.post(`/api/admin/approvals/${requested.body.approval_id}/decision`, { decision: 'approve' })
  assert.equal(selfApprove.status, 409)

  const reviewer = await adminClient('adjust_reviewer', 'adjust-review-1', 'FINANCE_ADMIN')
  const approved = await reviewer.post(`/api/admin/approvals/${requested.body.approval_id}/decision`, { decision: 'approve' })
  assert.equal(approved.status, 200, approved.text)
  assert.equal(db.prepare('SELECT recharge_centavos FROM wallets WHERE user_id = ?').get(userId).recharge_centavos, 500000)
  require('../lib/util').setSetting('second_approval_threshold_centavos', '5000000', null)
})

/* ========================================================== settlement */

test('check-in credits the withdrawable earnings wallet, not points', async () => {
  const { client } = await registerClient({ username: 'checkincash' })
  const before = await client.get('/api/wallet')
  const status = await client.get('/api/checkin')
  const reward = status.body.reward_centavos

  assert.equal(status.body.wallet, 'earnings')
  assert.ok(reward >= 100, 'check-in pays a peso amount')

  const result = await client.post('/api/checkin', {})
  assert.equal(result.status, 200, result.text)
  assert.equal(result.body.wallet, 'earnings')
  assert.equal(result.body.reward_centavos, reward)

  const after = await client.get('/api/wallet')
  assert.equal(after.body.earnings_centavos, before.body.earnings_centavos + reward)
  assert.equal(after.body.available_centavos, before.body.available_centavos + reward)
  assert.equal(after.body.points, before.body.points, 'points are untouched by check-in')

  // The credit lands in the same pool withdrawals draw from. The minimum
  // withdrawal is well above a single check-in, so top the wallet up to it and
  // withdraw the minimum — that proves check-in money is withdrawable.
  const admin = await adminClient('checkin_admin', 'checkin-admin-1')
  const topped = await admin.post('/api/admin/adjustments', {
    userId: (await client.get('/api/me')).body.user.id,
    wallet: 'earnings',
    direction: 'Credit',
    amount: '100.00',
    reason: 'Top up to the minimum withdrawal for the check-in test',
    note: 'Automated test funding',
  })
  assert.equal(topped.status, 201, topped.text)

  const dest = await client.post('/api/payout-destinations', {
    holderName: 'Settlement Tester', provider: 'GCash', accountNumber: '09170000001',
  })
  assert.equal(dest.status, 201, dest.text)

  const withdrawal = await client.post('/api/withdrawals', { amount: '100.00', destinationId: dest.body.id })
  assert.equal(withdrawal.status, 201, `check-in income can be withdrawn: ${withdrawal.text}`)

  // Reserved from the withdrawable balance, not from points.
  const reserved = await client.get('/api/wallet')
  assert.equal(reserved.body.reserved_centavos, 10000)
  assert.equal(reserved.body.points, before.body.points)

  const duplicate = await client.post('/api/checkin', {})
  assert.equal(duplicate.status, 409, 'still once per day')
})

test('daily plan income is credited after each completed 24-hour period', async () => {
  const { client, res } = await registerClient({ username: 'dailyincome' })
  const userId = res.body.user.id
  const admin = await adminClient('settle_admin', 'settle-admin-1', 'SUPER_ADMIN')

  const created = await admin.post('/api/admin/plans', {
    name: 'Settlement Test', category: 'daily', price: '100', duration_days: 5,
    projected_daily: '7.50', slots_total: 0, reason: 'Automated settlement test product',
  })
  assert.equal(created.status, 201, created.text)
  const planId = created.body.plan.id
  const daily = 750

  const fund = await admin.post('/api/admin/adjustments', {
    userId, wallet: 'recharge', direction: 'Credit', amount: '1000',
    reason: 'Fund the settlement test', note: 'Automated settlement test funding',
  })
  assert.equal(fund.status, 201, fund.text)

  const bought = await client.post('/api/user-plans/purchase', { planId })
  assert.equal(bought.status, 201, bought.text)
  const userPlanId = bought.body.userPlan.id

  const earningsBefore = (await client.get('/api/wallet')).body.earnings_centavos

  // Nothing is due immediately after purchase.
  const immediate = await client.get('/api/user-plans')
  assert.equal(immediate.status, 200)
  assert.equal(immediate.body.find((p) => p.id === userPlanId).days_completed, 0)

  // Rewind activation to simulate elapsed time, then sweep.
  const userPlans = require('../lib/userPlans')
  const DAY = 86_400_000
  const backdate = (days) => {
    const at = new Date(Date.now() - days * DAY).toISOString()
    db.prepare('UPDATE user_plans SET activated_at = ?, last_settled_at = ? WHERE id = ?').run(at, at, userPlanId)
  }

  // 25 hours elapsed: exactly one period is complete.
  backdate(25 / 24)
  let sweep = userPlans.settleDue()
  assert.equal(sweep.days, 1, 'one completed 24-hour period credits once')
  assert.equal(sweep.amount_centavos, daily)

  const afterOne = await client.get('/api/wallet')
  assert.equal(afterOne.body.earnings_centavos, earningsBefore + daily)

  // A second sweep must not pay again for the same day.
  const repeat = userPlans.settleDue()
  assert.equal(repeat.days, 0, 'a repeated sweep credits nothing new')

  // Three full days elapsed: days 2 and 3 are due.
  db.prepare('UPDATE user_plans SET last_settled_at = activated_at WHERE id = ?').run(userPlanId)
  db.prepare('UPDATE user_plans SET activated_at = ? WHERE id = ?').run(new Date(Date.now() - 3 * DAY).toISOString(), userPlanId)
  db.prepare("DELETE FROM plan_settlements WHERE user_plan_id = ? AND day_number > 1").run(userPlanId)

  sweep = userPlans.settleDue()
  assert.ok(sweep.days >= 2, `catch-up credits every due day, got ${sweep.days}`)

  const settled = db.prepare('SELECT * FROM plan_settlements WHERE user_plan_id = ? ORDER BY day_number').all(userPlanId)
  assert.equal(settled.length, 3, 'days 1 to 3 are each settled exactly once')
  assert.deepEqual(settled.map((s) => s.day_number), [1, 2, 3])
  for (const row of settled) {
    assert.equal(row.amount_centavos, daily)
    const entry = db.prepare('SELECT * FROM ledger_entries WHERE id = ?').get(row.ledger_entry_id)
    assert.equal(entry.wallet, 'earnings')
    assert.equal(entry.direction, 'credit')
    assert.equal(entry.kind, 'plan_daily_income')
    assert.equal(entry.amount_centavos, daily)
  }

  // The customer's own view shows the income with references.
  const detail = await client.get(`/api/user-plans/${userPlanId}/settlements`)
  assert.equal(detail.status, 200)
  assert.equal(detail.body.duration_days, 5)
  assert.ok(detail.body.days_completed >= 3)
  assert.ok(detail.body.total_income_centavos >= daily * 3)
  assert.equal(detail.body.rows.length, detail.body.days_completed)
  // The next credit is always exactly one 24-hour period after the last one
  // paid, so a customer can see when income lands instead of guessing.
  const lastSettled = db.prepare('SELECT settled_at FROM plan_settlements WHERE user_plan_id = ? ORDER BY day_number DESC LIMIT 1').get(userPlanId).settled_at
  assert.equal(
    new Date(detail.body.next_settlement_at).getTime(),
    new Date(lastSettled).getTime() + 86_400_000,
    'next credit is one day after the last settled day',
  )

  // A plan past its full term completes rather than accruing forever.
  db.prepare('UPDATE user_plans SET activated_at = ?, last_settled_at = ? WHERE id = ?')
    .run(new Date(Date.now() - 10 * DAY).toISOString(), new Date(Date.now() - 10 * DAY).toISOString(), userPlanId)
  const finalSweep = userPlans.settleDue()
  assert.equal(finalSweep.days, 2, 'only the two remaining days of a 5-day term settle')
  const finalPlan = db.prepare('SELECT * FROM user_plans WHERE id = ?').get(userPlanId)
  assert.equal(finalPlan.status, 'completed')
  assert.equal(finalPlan.days_completed, 5)

  const totalSettled = db.prepare('SELECT COALESCE(SUM(amount_centavos),0) s FROM plan_settlements WHERE user_plan_id = ?').get(userPlanId).s
  assert.equal(totalSettled, daily * 5, 'five days of a five-day term')
})

test('a concurrent settlement sweep cannot pay the same day twice', async () => {
  const { client, res } = await registerClient({ username: 'racysettle' })
  const userId = res.body.user.id
  const admin = await adminClient('race_admin', 'race-admin-1', 'SUPER_ADMIN')

  const created = await admin.post('/api/admin/plans', {
    name: 'Race Test', category: 'daily', price: '50', duration_days: 3,
    projected_daily: '2.00', slots_total: 0, reason: 'Automated concurrency test product',
  })
  const planId = created.body.plan.id
  await admin.post('/api/admin/adjustments', {
    userId, wallet: 'recharge', direction: 'Credit', amount: '500',
    reason: 'Fund the concurrency test', note: 'Automated concurrency test funding',
  })
  const bought = await client.post('/api/user-plans/purchase', { planId })
  const userPlanId = bought.body.userPlan.id

  const DAY = 86_400_000
  const at = new Date(Date.now() - 2 * DAY).toISOString()
  db.prepare('UPDATE user_plans SET activated_at = ?, last_settled_at = ? WHERE id = ?').run(at, at, userPlanId)

  const userPlans = require('../lib/userPlans')
  const results = await Promise.all([
    Promise.resolve().then(() => userPlans.settleDue()),
    Promise.resolve().then(() => userPlans.settleDue()),
    Promise.resolve().then(() => userPlans.settleDue()),
  ])
  const totalDays = results.reduce((sum, r) => sum + r.days, 0)
  assert.equal(totalDays, 2, `three sweeps over two due days credit exactly two days, got ${totalDays}`)

  const rows = db.prepare('SELECT * FROM plan_settlements WHERE user_plan_id = ?').all(userPlanId)
  assert.equal(rows.length, 2)
  const earnings = (await client.get('/api/wallet')).body.earnings_centavos
  const incomeCredits = earnings - 5000
  assert.equal(incomeCredits, 400, 'exactly two credits of 200 centavos reached the wallet')
})

test('settlement can be triggered manually and reports what it credited', async () => {
  const { client, res } = await registerClient({ username: 'manualsettle' })
  const userId = res.body.user.id
  const admin = await adminClient('manual_admin', 'manual-admin-1', 'SUPER_ADMIN')

  const created = await admin.post('/api/admin/plans', {
    name: 'Manual Settle Test', category: 'daily', price: '50', duration_days: 4,
    projected_daily: '1.00', slots_total: 0, reason: 'Automated manual settlement test product',
  })
  await admin.post('/api/admin/adjustments', {
    userId, wallet: 'recharge', direction: 'Credit', amount: '200',
    reason: 'Fund the manual settlement test', note: 'Automated manual settlement test funding',
  })
  const bought = await client.post('/api/user-plans/purchase', { planId: created.body.plan.id })
  const userPlanId = bought.body.userPlan.id

  const DAY = 86_400_000
  const at = new Date(Date.now() - 1.5 * DAY).toISOString()
  db.prepare('UPDATE user_plans SET activated_at = ?, last_settled_at = ? WHERE id = ?').run(at, at, userPlanId)

  const run = await admin.post('/api/admin/system/settle', { reason: 'Automated manual settlement check' })
  assert.equal(run.status, 200, run.text)
  assert.equal(run.body.days, 1)
  assert.equal(run.body.amount_centavos, 100)

  const listed = await admin.get('/api/admin/plan-settlements')
  assert.equal(listed.status, 200)
  assert.ok(listed.body.total >= 1)
  assert.ok(listed.body.rows.some((r) => r.user_plan_id === userPlanId && r.day_number === 1))

  const again = await admin.post('/api/admin/system/settle', { reason: 'Second run must be a no-op' })
  assert.equal(again.body.days, 0, 'a second manual run credits nothing new')
})

test('settlement cannot be run by a role without permission', async () => {
  const support = await adminClient('settle_support', 'settle-support-1', 'SUPPORT_ADMIN')
  const denied = await support.post('/api/admin/system/settle', { reason: 'Should be blocked' })
  assert.equal(denied.status, 403)
  assert.equal(denied.body.error.code, 'forbidden')
})

/* ================================================================ roles */

test('admin permissions are enforced on the server, not just in the UI', async () => {
  const { res: target } = await registerClient({ username: 'rolevictim' })
  const support = await adminClient('support_role', 'support-role-1', 'SUPPORT_ADMIN')

  const session = await support.get('/api/admin/session')
  assert.equal(session.body.admin.role, 'SUPPORT_ADMIN')

  const forbiddenAdjust = await support.post('/api/admin/adjustments', {
    userId: target.body.user.id, wallet: 'recharge', direction: 'Credit', amount: '100',
    reason: 'Should be blocked', note: 'Support admins cannot adjust balances',
  })
  assert.equal(forbiddenAdjust.status, 403)
  assert.equal(forbiddenAdjust.body.error.code, 'forbidden')

  const forbiddenDeposits = await support.get('/api/admin/deposits')
  assert.equal(forbiddenDeposits.status, 403)

  const allowedRead = await support.get('/api/admin/users')
  assert.equal(allowedRead.status, 200)

  const auditor = await adminClient('auditor_role', 'auditor-role-1', 'AUDITOR')
  assert.equal((await auditor.get('/api/admin/overview')).status, 200)
  assert.equal((await auditor.get('/api/admin/transactions')).status, 200)
  assert.equal((await auditor.get('/api/admin/audit')).status, 200)
  const auditorAdjust = await auditor.post('/api/admin/adjustments', {
    userId: target.body.user.id, wallet: 'recharge', direction: 'Credit', amount: '100',
    reason: 'Should be blocked', note: 'Auditors are read only',
  })
  assert.equal(auditorAdjust.status, 403)
})

test('there is no public administrator registration', async () => {
  const client = makeClient()
  for (const url of ['/api/admin/register', '/api/admin/signup', '/api/auth/admin']) {
    const res = await client.post(url, { username: 'sneaky', password: 'valid-pass-123', role: 'SUPER_ADMIN' })
    assert.equal(res.status, 404, `${url} must not exist`)
  }
})

/* ======================================================== empty states */

test('empty tables return honest empty results, not invented rows', async () => {
  const admin = await adminClient('empty_admin', 'empty-admin-1')
  const tickets = await admin.get('/api/admin/tickets')
  assert.equal(tickets.status, 200)
  assert.ok(Array.isArray(tickets.body))
})

test('reports export real rows and refuse to invent data', async () => {
  const admin = await adminClient('report_admin', 'report-admin-1')
  const report = await admin.get('/api/admin/reports/welcome_rewards')
  assert.equal(report.status, 200)
  assert.ok(report.body.count > 0)

  const csv = await admin.get('/api/admin/reports/welcome_rewards/export.csv')
  assert.equal(csv.status, 200)
  assert.ok(csv.text.split('\n')[0].includes('amount_centavos'))

  const liability = await admin.get('/api/admin/reports/liabilities')
  assert.equal(liability.status, 200)
  assert.ok(liability.body.rows.length > 0)

  const unknown = await admin.get('/api/admin/reports/not_a_report')
  assert.equal(unknown.status, 400)
})

test('audit trail records who did what and stays append-only', async () => {
  const admin = await adminClient('audit_admin', 'audit-admin-1')
  const { res } = await registerClient({ username: 'auditsubject' })
  const adjustment = await admin.post('/api/admin/adjustments', {
    userId: res.body.user.id, wallet: 'points', direction: 'Credit', amount: '25',
    reason: 'Audit trail check', note: 'Automated integration test audit entry', reference: 'AUDIT-TEST-1',
  })
  assert.equal(adjustment.status, 201)

  const trail = await admin.get(`/api/admin/audit?targetId=${res.body.user.id}`)
  assert.equal(trail.status, 200)
  const entry = trail.body.rows.find((r) => r.action === 'adjustment.posted')
  assert.ok(entry, 'the adjustment must be in the audit trail')
  assert.equal(entry.actor_name, 'audit_admin')
  assert.equal(entry.transaction_reference, 'AUDIT-TEST-1')
  assert.ok(entry.correlation_id)
  assert.ok(entry.before_json)
  assert.ok(entry.after_json)
  assert.equal(JSON.stringify(entry).includes(res.body.user.id), true)

  assert.throws(() => db.prepare('DELETE FROM audit_logs WHERE id = ?').run(entry.id), /append-only/)
})

test('adjustments never leak credentials into the audit trail', async () => {
  const { res } = await registerClient({ username: 'secrettest' })
  const admin = await adminClient('redact_admin', 'redact-admin-1')
  await admin.post('/api/admin/adjustments', {
    userId: res.body.user.id, wallet: 'points', direction: 'Credit', amount: '5',
    reason: 'Redaction check', note: 'Testing redaction', password: 'leaked-password-value',
  })
  const trail = await admin.get('/api/admin/audit?limit=10')
  assert.equal(trail.status, 200)
  assert.equal(trail.text.includes('leaked-password-value'), false, 'no credential may reach the audit trail')
  assert.equal(trail.text.includes('$2b$'), false, 'no password hash may reach the audit trail')

  // Redaction is applied to any value that looks like a credential, at any depth.
  const { redact } = require('../lib/audit')
  assert.deepEqual(redact({ note: 'ok', password: 'x', nested: { session_token: 'y' } }), {
    note: 'ok', password: '[redacted]', nested: { session_token: '[redacted]' },
  })
})

/* ============================================================ engagement */

test('check-in and tasks pay once per day and refuse duplicates', async () => {
  const { client } = await registerClient({ username: 'taskuser' })

  const first = await client.post('/api/checkin', {})
  assert.equal(first.status, 200)
  assert.equal(first.body.streak, 1)
  const repeat = await client.post('/api/checkin', {})
  assert.equal(repeat.status, 409)
  assert.equal(repeat.body.error.code, 'already_checked_in')

  const tasks = await client.get('/api/tasks')
  assert.equal(tasks.status, 200)
  assert.ok(tasks.body.length > 0)
  const daily = tasks.body.find((t) => t.recurring === 'daily')
  const claim = await client.post(`/api/tasks/${daily.id}/claim`, {})
  assert.equal(claim.status, 200, claim.text)
  const claimAgain = await client.post(`/api/tasks/${daily.id}/claim`, {})
  assert.equal(claimAgain.status, 409)
})

test('redemption codes honour limits and expiry', async () => {
  const admin = await adminClient('code_admin', 'code-admin-1')
  const created = await admin.post('/api/admin/rewards/codes', {
    code: 'TEST-CODE-1', label: 'Integration test code', value: 40,
    max_redemptions: 1, per_user_limit: 1,
  })
  assert.equal(created.status, 201, created.text)

  const { client } = await registerClient({ username: 'redeemer1' })
  const redeem = await client.post('/api/redemptions', { code: 'test-code-1' })
  assert.equal(redeem.status, 200, redeem.text)

  const exhausted = await client.post('/api/redemptions', { code: 'TEST-CODE-1' })
  assert.equal(exhausted.status, 409)
  assert.equal(exhausted.body.error.code, 'code_exhausted')

  await admin.post('/api/admin/rewards/codes', {
    code: 'TEST-CODE-EXPIRED', value: 10, max_redemptions: 5, expires_at: '2020-01-01T00:00:00.000Z',
  })
  const { client: late } = await registerClient({ username: 'redeemer2' })
  const expired = await late.post('/api/redemptions', { code: 'TEST-CODE-EXPIRED' })
  assert.equal(expired.status, 409)
  assert.equal(expired.body.error.code, 'code_expired')

  const bogus = await late.post('/api/redemptions', { code: 'NOT-A-CODE' })
  assert.equal(bogus.status, 404)
})

test('the wheel publishes its odds and pays cash into the withdrawable balance', async () => {
  const { client } = await registerClient({ username: 'wheeluser' })
  const rules = await client.get('/api/wheel')
  assert.equal(rules.status, 200)
  assert.ok(rules.body.rules.outcomes.length > 0)
  const totalProbability = rules.body.rules.outcomes.reduce((a, o) => a + o.probability, 0)
  assert.ok(Math.abs(totalProbability - 100) < 0.05, 'published probabilities must sum to 100')
  assert.match(rules.body.rules.currency_note, /withdrawable/i)
  assert.doesNotMatch(rules.body.rules.currency_note, /points are not cash/i)
  // Every winning outcome is a peso amount, not a points count.
  for (const outcome of rules.body.rules.outcomes) {
    assert.equal(typeof outcome.amountCentavos, 'number', `outcome ${outcome.label} must publish a peso amount`)
  }

  const walletBefore = (await client.get('/api/wallet')).body.earnings_centavos
  const pointsBefore = (await client.get('/api/wallet')).body.points

  const spin = await client.post('/api/wheel/spin', {})
  assert.equal(spin.status, 200)

  // Whatever was won lands in earnings and touches no points balance.
  const after = await client.get('/api/wallet')
  assert.equal(after.body.points, pointsBefore, 'the wheel must not award points')
  if (spin.body.entry) {
    assert.equal(spin.body.entry.wallet, 'earnings')
    assert.equal(spin.body.entry.kind, 'wheel_prize')
    assert.equal(after.body.earnings_centavos, walletBefore + spin.body.entry.amount_centavos)
  }

  const again = await client.post('/api/wheel/spin', {})
  assert.equal(again.status, 409)
})

test('tasks pay the withdrawable balance, not points', async () => {
  const { client } = await registerClient({ username: 'taskcashuser' })
  const admin = await adminClient('taskcash_admin', 'taskcash-admin-1', 'SUPER_ADMIN')

  const created = await admin.post('/api/admin/rewards/tasks', {
    title: 'Cash task',
    description: 'Pays real money',
    reward_points: '2.50',
    recurring: 'once',
    active: true,
  })
  assert.equal(created.status, 201, created.text)
  assert.equal(created.body.task.reward_points, 250, '₱2.50 must be stored as 250 centavos')

  const before = await client.get('/api/wallet')
  const claimed = await client.post(`/api/tasks/${created.body.task.id}/claim`, {})
  assert.equal(claimed.status, 200, claimed.text)
  assert.equal(claimed.body.entry.wallet, 'earnings', 'task rewards go to the withdrawable wallet')
  assert.equal(claimed.body.entry.amount_centavos, 250)

  const after = await client.get('/api/wallet')
  assert.equal(after.body.earnings_centavos, before.body.earnings_centavos + 250)
  assert.equal(after.body.available_centavos, before.body.available_centavos + 250)
  assert.equal(after.body.points, before.body.points, 'task rewards must not award points')
})

test('a referral bonus is credited once and is visible to the referrer', async () => {
  const referrer = await registerClient({ username: 'bigreferrer' })
  const code = referrer.res.body.user.referral_code

  // Captured BEFORE the referral happens, so the delta is the bonus itself.
  const beforeWallet = await referrer.client.get('/api/wallet')
  const before = beforeWallet.body.earnings_centavos
  const pointsBefore = beforeWallet.body.points

  const referred = await registerClient({ username: 'smallreferred', referralCode: code })
  assert.equal(referred.res.status, 201)

  const list = await referrer.client.get('/api/referrals')
  assert.equal(list.status, 200)
  assert.equal(list.body.total, 1)
  assert.equal(list.body.rows[0].username, 'smallreferred')
  assert.ok(list.body.bonus_earned_centavos > 0, 'the bonus must be reported to the referrer')

  const afterBonus = (await referrer.client.get('/api/wallet')).body.earnings_centavos
  assert.equal(afterBonus - before, list.body.bonus_earned_centavos, 'the bonus lands in the withdrawable balance')
  assert.equal((await referrer.client.get('/api/wallet')).body.points, pointsBefore, 'referral bonuses must not award points')

  const another = await registerClient({ username: 'smallreferred', referralCode: code })
  assert.equal(another.res.status, 409)
})

/* ============================================================== settings */

test('settings changes require a reason and are audited', async () => {
  const admin = await adminClient('settings_admin', 'settings-admin-1')
  const noReason = await admin.patch('/api/admin/settings', { changes: { min_withdrawal_centavos: '20000' } })
  assert.equal(noReason.status, 400)

  const notAllowed = await admin.patch('/api/admin/settings', { changes: { something_secret: '1' }, reason: 'Testing unknown keys' })
  assert.equal(notAllowed.status, 400)
  assert.equal(notAllowed.body.error.code, 'unknown_setting')

  const applied = await admin.patch('/api/admin/settings', {
    changes: { min_withdrawal_centavos: '20000' }, reason: 'Integration test threshold change',
  })
  assert.equal(applied.status, 200, applied.text)
  assert.equal(applied.body.settings.min_withdrawal_centavos, '20000')

  const support = await adminClient('settings_support', 'settings-support-1', 'SUPPORT_ADMIN')
  const denied = await support.patch('/api/admin/settings', { changes: { min_withdrawal_centavos: '1' }, reason: 'Should be blocked' })
  assert.equal(denied.status, 403)
})

test('administrator accounts can only be provisioned with permission', async () => {
  const admin = await adminClient('adminroot', 'adminroot-pass-1')
  const created = await admin.post('/api/admin/administrators', {
    username: 'newauditor', password: 'auditor-pass-1', displayName: 'New Auditor', role: 'AUDITOR',
  })
  assert.equal(created.status, 201, created.text)
  assert.equal(created.body.admin.role, 'AUDITOR')
  assert.equal(db.prepare('SELECT COUNT(*) c FROM admin_users WHERE username = ?').get('newauditor').c, 1)

  const planManager = await adminClient('pm_role', 'pm-role-pass-1', 'PLAN_MANAGER')
  const denied = await planManager.post('/api/admin/administrators', {
    username: 'nope', password: 'nope-pass-1', role: 'SUPER_ADMIN',
  })
  assert.equal(denied.status, 403)

  const removed = await admin.patch(`/api/admin/administrators/${created.body.admin.id}`, {
    status: 'Disabled', reason: 'Integration test disable',
  })
  assert.equal(removed.status, 200)
})

test('an admin session is required for every admin route', async () => {
  const anon = makeClient()
  for (const url of ['/api/admin/overview', '/api/admin/users', '/api/admin/transactions', '/api/admin/audit', '/api/admin/settings']) {
    const res = await anon.get(url)
    assert.equal(res.status, 401, `${url} must require authentication`)
  }
})

test('a customer session cannot reach the admin API', async () => {
  const { client } = await registerClient({ username: 'nosyuser' })
  const res = await client.get('/api/admin/users')
  assert.equal(res.status, 401)
})

test('logout destroys the session server-side', async () => {
  const { client } = await registerClient({ username: 'logoutuser' })
  assert.equal((await client.get('/api/me')).status, 200)
  assert.equal((await client.post('/api/auth/logout', {})).status, 200)
  assert.equal((await client.get('/api/me')).status, 401)
})

test('changing a password signs out other sessions', async () => {
  const { client } = await registerClient({ username: 'pwchangeuser' })
  const other = makeClient()
  const login = await other.post('/api/auth/login', { username: 'pwchangeuser', password: 'valid-pass-123' })
  assert.equal(login.status, 200)
  other.setCsrf(login.body.csrfToken)

  const changed = await client.post('/api/auth/password', { currentPassword: 'valid-pass-123', newPassword: 'brand-new-pass-9' })
  assert.equal(changed.status, 200, changed.text)
  assert.equal((await other.get('/api/me')).status, 401)
  assert.equal((await other.post('/api/auth/login', { username: 'pwchangeuser', password: 'valid-pass-123' })).status, 401)
  const relogin = await makeClient().post('/api/auth/login', { username: 'pwchangeuser', password: 'brand-new-pass-9' })
  assert.equal(relogin.status, 200)
})

test('registration rejects weak passwords and bad usernames', async () => {
  const short = await makeClient().post('/api/auth/register', { username: 'weakpass', password: 'abc' })
  assert.equal(short.status, 400)
  assert.equal(short.body.error.code, 'invalid_password')

  const noNumber = await makeClient().post('/api/auth/register', { username: 'weakpass', password: 'onlyletters' })
  assert.equal(noNumber.status, 400)

  const badChars = await makeClient().post('/api/auth/register', { username: 'bad name!', password: 'valid-pass-123' })
  assert.equal(badChars.status, 400)
  assert.equal(badChars.body.error.code, 'invalid_username')

  const tooShort = await makeClient().post('/api/auth/register', { username: 'ab', password: 'valid-pass-123' })
  assert.equal(tooShort.status, 400)
})

test('unknown endpoints return a clean 404 without leaking internals', async () => {
  const res = await makeClient().get('/api/definitely-not-here')
  assert.equal(res.status, 404)
  assert.equal(res.body.error.code, 'not_found')
})

test('cross-origin requests from an unlisted origin are blocked', async () => {
  const res = await fetch(`${baseUrl}/api/health`, { headers: { Origin: 'https://evil.example' } })
  assert.equal(res.status, 403)
})

test('admin overview figures come from the database', async () => {
  const admin = await adminClient('overview_admin', 'overview-pass-1')
  const res = await admin.get('/api/admin/overview')
  assert.equal(res.status, 200)
  const cards = res.body.cards
  assert.equal(cards.users, db.prepare('SELECT COUNT(*) c FROM users').get().c)
  assert.equal(cards.active_plans, db.prepare("SELECT COUNT(*) c FROM user_plans WHERE status = 'active'").get().c)
  assert.equal(cards.welcome_rewards_issued, db.prepare('SELECT COUNT(*) c FROM welcome_rewards').get().c)
  assert.ok(cards.wallet_liabilities_centavos >= 0)
})